/* Shared destination + preference data. Used by register.js and dashboard.js.
   Replace PLACES with records from your destinations table. */
// Sample data. Replace with records from your destinations table.
// "view" = sunrise on east-facing coasts (Leyte Gulf side), sunset on west-facing coasts (Ormoc Bay / Camotes Sea side).
const PLACES = [
  { name: 'Kalanggaman Island', feeAmt: 150, stay: ['full', 'overnight'], town: 'Palompon', cats: ['beach', 'nature'], area: 'rural', time: ['morning', 'afternoon'], view: 'sunset', fee: '₱150 environmental fee', hours: '6:00 AM – 5:00 PM', facilities: ['Cottages', 'Restrooms', 'Boat landing'], weather: { condition: 'sunny', tempC: 31, tip: 'Great beach weather. Bring sunscreen and plenty of water.' },
    about: "Kalanggaman is a small uninhabited island off Palompon, famous for the two sandbars that stretch out from either end into clear turquoise water. The local government manages visits to protect the island, so it stays clean and uncrowded.", highlights: ["Twin sandbars that change shape with the tide", "Swimming and snorkeling in clear shallow water", "Picnic and cottage area under the trees", "Sunset views over the Camotes Sea"], best: "March to May, when the sea is usually calm. Arrive early for the best light and fewer people.", getThere: "Take a boat from the Palompon port. The crossing depends on sea conditions, so book through the tourism office.", tip: "Bring your own food and water, and take your trash back with you. Daily visitor numbers are managed, so book ahead.",
    blurb: 'A long white sandbar with clear water on both sides.' },
  { name: 'Cuatro Islas', feeAmt: 100, stay: ['full', 'overnight'], town: 'Inopacan', cats: ['beach', 'nature'], area: 'rural', time: ['morning', 'afternoon'], view: 'sunset', fee: '₱100 environmental fee', hours: '6:00 AM – 5:00 PM', facilities: ['Boat landing', 'Cottages'], weather: { condition: 'partly', tempC: 30, tip: 'Good conditions for island hopping.' },
    about: "Cuatro Islas is a group of four islands off Inopacan (Himokilan, Mahaba, Apid and Digyo), each with its own character. Expect white sand, rock formations, clear water and quiet coves ideal for island hopping.", highlights: ["Island hopping between the four islands", "Snorkeling over coral and clear shallows", "White sand coves for swimming and picnics", "Rock formations and photo spots"], best: "Dry, calm months (roughly March to May). Go in the morning when the water is flat.", getThere: "Travel to Inopacan, then take a boat from the town's landing point. Boats and guides can be arranged locally.", tip: "Bring sun protection and cash for boat rental and fees. Ask your boatman about weather before setting out.",
    blurb: 'Small islands with white sand and calm coves for a day trip.' },
  { name: 'Lake Danao Natural Park', feeAmt: 50, stay: ['half', 'full'], town: 'Ormoc City', cats: ['nature'], area: 'rural', time: ['morning', 'afternoon'], view: null, fee: '₱50 entrance fee', hours: '6:00 AM – 5:00 PM', facilities: ['Kayak rental', 'Cottages', 'Parking'], weather: { condition: 'cloudy', tempC: 24, tip: 'Cool and misty. Bring a light jacket.' },
    about: "Lake Danao sits high in the mountains above Ormoc and is known for its guitar shape. The park is cool, quiet and green, with a calm lake surrounded by forest.", highlights: ["Kayaking and bamboo raft rides on the lake", "Short forest walks and lakeside picnics", "Cool mountain air and morning mist", "Good for photography at sunrise"], best: "Morning, before the mist clears. Dry months give the most reliable weather.", getThere: "Travel from Ormoc City by road up into the mountains. Motorbikes, vans and hired vehicles make the trip.", tip: "It gets cool and damp, so bring a light jacket. Weekdays are quieter than weekends.",
    blurb: 'A guitar-shaped mountain lake with cool air and morning mist.' },
  { name: 'Mahagnao Volcano Natural Park', feeAmt: 60, stay: ['full', 'overnight'], town: 'Burauen', cats: ['nature'], area: 'rural', time: ['morning'], view: null, fee: '₱60 entrance fee', hours: '6:00 AM – 4:00 PM', facilities: ['Guides available', 'Camping area'], weather: { condition: 'rain', tempC: 23, tip: 'Trails may be slippery. Check conditions before hiking.' },
    about: "Mahagnao is a protected natural park around a dormant volcano in Burauen, with a crater lake and forest trails. It suits hikers and campers who want a quiet, green escape.", highlights: ["Trail through mossy mountain forest", "Crater lake views", "Camping area for overnight stays", "Guides available on site"], best: "Morning, in the dry months. Trails can be slippery after rain.", getThere: "Travel to Burauen by road, then continue to the park entrance. Ask the park office about guides.", tip: "Wear shoes with good grip and register at the entrance. Start early so you finish before dark.",
    blurb: 'Forest trails around a crater lake.' },
  { name: 'Mount Pangasugan', feeAmt: 50, stay: ['full', 'overnight'], town: 'Baybay City', cats: ['nature'], area: 'rural', time: ['morning'], view: null, fee: '₱50 registration fee', hours: '6:00 AM – 3:00 PM', facilities: ['Guides required', 'Camping area'], weather: { condition: 'cloudy', tempC: 24, tip: 'Overcast with cooler air on the trail.' },
    about: "Mount Pangasugan rises above Baybay City in the Leyte mountain range. It is a popular hiking destination with forested slopes and cool air.", highlights: ["Forest hiking trails", "Cooler mountain air", "Views over the surrounding countryside", "Camping for overnight trips"], best: "Early morning start in dry weather, so you are off the trail before afternoon rain.", getThere: "Travel to Baybay City, then continue to the trailhead with a local guide.", tip: "A guide is required. Bring water, rain protection and a headlamp if you plan to camp.",
    blurb: 'A forested mountain in the Leyte range, known for hiking trails.' },
  { name: 'San Juanico Bridge', feeAmt: 0, stay: ['half'], town: 'Tacloban City', cats: ['landmark'], area: 'urban', time: ['morning', 'afternoon'], view: 'sunrise', fee: 'Free', hours: 'Open 24 hours', facilities: ['Viewing deck', 'Parking'], weather: { condition: 'sunny', tempC: 29, tip: 'Clear skies, good visibility for photos.' },
    about: "San Juanico Bridge crosses the San Juanico Strait between Leyte and Samar. At over two kilometers long, it is among the longest bridges in the Philippines and one of the region's best-known landmarks.", highlights: ["Long crossing between Leyte and Samar", "Sunrise photos over the strait", "Viewing deck near the Tacloban side", "Free to visit at any hour"], best: "Sunrise or late afternoon, when the light is soft and the heat is lower.", getThere: "Take a jeepney, tricycle or taxi from Tacloban City toward the bridge. Parking is available near the viewing deck.", tip: "Take care near the road and watch for traffic. Go at first light for the best photos.",
    blurb: 'The long bridge linking Leyte and Samar, best at first light.' },
  { name: 'MacArthur Landing Memorial National Park', feeAmt: 20, stay: ['half'], town: 'Palo', cats: ['history', 'landmark'], area: 'urban', time: ['morning', 'afternoon'], view: 'sunrise', fee: '₱20 entrance fee', hours: '8:00 AM – 5:00 PM', facilities: ['Parking', 'Restrooms', 'Souvenir shops'], weather: { condition: 'sunny', tempC: 30, tip: 'Warm and clear, good for a morning visit.' },
    about: "This park in Palo marks the place where General Douglas MacArthur and Philippine leaders waded ashore on October 20, 1944, starting the liberation of the country. Life-size statues show the moment on the shore of Leyte Gulf.", highlights: ["Life-size statues of the 1944 landing", "Shoreline views over Leyte Gulf", "Historical markers and souvenir shops", "Close to Palo Metropolitan Cathedral"], best: "Morning, before the heat builds. October 20 is the anniversary of the landing.", getThere: "Palo is a short ride south of Tacloban City by jeepney, van or tricycle.", tip: "Pair it with Palo Metropolitan Cathedral for a half-day history trip.",
    blurb: 'Statues on the shore of Leyte Gulf mark the 1944 landing.' },
  { name: 'Palo Metropolitan Cathedral', feeAmt: 0, stay: ['half'], town: 'Palo', cats: ['history'], area: 'urban', time: ['morning', 'afternoon'], view: null, fee: 'Free', hours: '6:00 AM – 6:00 PM', facilities: ['Parking', 'Restrooms'], weather: { condition: 'sunny', tempC: 30, tip: 'Pleasant for a walk around the plaza.' },
    about: "Palo Metropolitan Cathedral is a centuries-old church at the center of Palo. It was used as a field hospital during the 1944 Leyte campaign and remains an active place of worship.", highlights: ["Historic church with a long local history", "Plaza for a slow walk", "Links to the 1944 Leyte campaign", "Near the MacArthur Landing memorial"], best: "Morning or late afternoon. Check mass times if you want to see the interior quietly.", getThere: "In Palo town center, a short ride from Tacloban City by jeepney or tricycle.", tip: "Dress modestly and keep quiet during services.",
    blurb: 'A centuries-old church in Palo, close to the landing memorial.' },
  { name: 'Santo Niño Shrine and Heritage Museum', feeAmt: 75, stay: ['half'], town: 'Tacloban City', cats: ['history'], area: 'urban', time: ['morning', 'afternoon'], view: null, fee: '₱75 entrance fee', hours: '9:00 AM – 5:00 PM, closed Mondays', facilities: ['Guided tours', 'Restrooms', 'Gift shop'], weather: { condition: 'partly', tempC: 29, tip: 'Comfortable for walking between the shrine and museum.' },
    about: "This grand building in Tacloban City houses a museum of art, antiques and heritage displays, along with a collection of Santo Niño images. It is known for its large, ornate interiors.", highlights: ["Grand interiors and chandeliers", "Art and antique displays", "Santo Niño collection", "Guided tours"], best: "Weekday mornings for a quieter visit. The museum is closed on Mondays.", getThere: "In Tacloban City, reachable by tricycle or taxi from the city center.", tip: "Ask for a guided tour to get the stories behind the collection.",
    blurb: 'A heritage museum and shrine in the city center.' },
  { name: 'Price Mansion', feeAmt: 50, stay: ['half'], town: 'Tacloban City', cats: ['history'], area: 'urban', time: ['morning', 'afternoon'], view: null, fee: '₱50 entrance fee', hours: '9:00 AM – 5:00 PM, closed Mondays', facilities: ['Guided tours', 'Restrooms'], weather: { condition: 'partly', tempC: 29, tip: 'Fine conditions for a short visit.' },
    about: "Price Mansion is a historic house in Tacloban City built in the early 1900s. It is linked to the 1944 Leyte campaign, when American forces used it as a headquarters.", highlights: ["Early 20th century architecture", "Links to the 1944 liberation campaign", "Guided tours of the house", "Short visit close to other city sights"], best: "Weekday mornings. Closed on Mondays.", getThere: "In Tacloban City, a short tricycle or taxi ride from the center.", tip: "Combine it with the Santo Niño Shrine for a city heritage tour.",
    blurb: 'A historic mansion in Tacloban tied to the 1944 Leyte campaign.' },
  { name: 'Ormoc City Boulevard', feeAmt: 0, stay: ['half'], town: 'Ormoc City', cats: ['landmark'], area: 'urban', time: ['afternoon', 'evening'], view: 'sunset', fee: 'Free', hours: 'Open 24 hours', facilities: ['Food stalls', 'Parking', 'Benches'], weather: { condition: 'sunny', tempC: 28, tip: 'Clear skies expected toward sunset.' },
    about: "Ormoc City Boulevard is a seaside promenade along Ormoc Bay. Locals come here in the late afternoon to walk, eat street food and watch the sun set over the water.", highlights: ["Sunset views over Ormoc Bay", "Food stalls along the promenade", "Benches for a relaxed evening", "Free and open 24 hours"], best: "Late afternoon into evening, when the air cools and the sky turns gold.", getThere: "In Ormoc City, a short tricycle ride from the city center.", tip: "Bring small change for street food and arrive about an hour before sunset.",
    blurb: 'A seaside promenade on Ormoc Bay for an evening walk.' }
];

const CATS = [
  ['beach', 'bi-water', 'Beaches & islands'],
  ['nature', 'bi-tree', 'Nature & lakes'],
  ['history', 'bi-bank', 'Historical & cultural'],
  ['landmark', 'bi-geo-alt', 'Landmarks & viewpoints']
];
const AREAS = [
  ['urban', 'bi-buildings', 'Urban', 'City and town centers'],
  ['rural', 'bi-tree-fill', 'Rural', 'Countryside, islands, and mountains'],
  ['either', 'bi-shuffle', 'Either', 'Show me both']
];
const TIMES = [
  ['morning', 'bi-sunrise', 'Morning', 'Cooler air and sunrise views'],
  ['afternoon', 'bi-sun', 'Afternoon', 'Full daylight for touring'],
  ['evening', 'bi-sunset', 'Evening', 'Golden hour and sunset views']
];
const BUDGETS = [
  ['free', 'bi-gift', 'Free only', 'No entrance or environmental fee'],
  ['50', 'bi-cash', 'Up to ₱50', 'A small entrance fee, not free'],
  ['100', 'bi-cash-stack', 'Up to ₱100', 'Mid-range entrance fees'],
  ['any', 'bi-infinity', 'Any budget', 'Show me everything, priciest first']
];
const TRIPS = [
  ['half', 'bi-hourglass-split', 'Half day', 'A few hours at one or two stops'],
  ['full', 'bi-brightness-high', 'Full day', 'Spend the whole day out'],
  ['overnight', 'bi-moon-stars', 'Overnight', 'Camping or staying over']
];
// Each tier is its own price band, not a running maximum, so picking "Up to ₱50" shows places
// that actually cost something up to ₱50 rather than quietly including the free ones too.
const BUDGET_RANGE = { free: [0, 0], '50': [1, 50], '100': [51, 100], any: [0, Infinity] };
// Shared match helpers so register.js and dashboard.js score the same way.
const budgetOk = (p, budget) => {
  const [min, max] = BUDGET_RANGE[budget] ?? [0, Infinity];
  return p.feeAmt >= min && p.feeAmt <= max;
};
const tripOk = (p, trip) => p.stay.includes(trip);
const label = (list, v) => list.find(x => x[0] === v)[2];


// Photos are NOT hard-coded. api/place-images.php scans the images/places folder and returns every file it finds,
// and each place is matched to a photo by its name (e.g. "Price Mansion" -> price-mansion.jpg / .png / .webp).
// To add or change a photo, just drop a file in images/places/ named after the place. No code changes needed.
const placeSlug = p => p.name.toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/^-+|-+$/g, '');
let PLACE_IMAGES = {};   // { file-base-name: 'images/places/file.ext' }, filled in by loadPlaceImages()
async function loadPlaceImages() {
  try {
    const res = await api('place-images.php');
    if (res && res.ok) PLACE_IMAGES = res.images || {};
  } catch (e) {}
  return PLACE_IMAGES;
}
// Exact slug match first, then the closest file name that starts with (or is started by) the slug.
function placePhotoUrl(p) {
  const slug = placeSlug(p);
  if (PLACE_IMAGES[slug]) return PLACE_IMAGES[slug];
  const key = Object.keys(PLACE_IMAGES).find(k => slug.startsWith(k) || k.startsWith(slug));
  return key ? PLACE_IMAGES[key] : null;
}

// Thumbnail for a place: the real photo when one is found, otherwise the category-tinted icon tile.
function placeThumb(p, size) {
  const cat = p.cats[0];
  const icon = (CATS.find(c => c[0] === cat) || [,'bi-geo-alt'])[1];
  const cls = size === 'sm' ? 'place-thumb place-thumb-sm' : 'place-thumb';
  const url = placePhotoUrl(p);
  const photo = url ? `<img class="place-photo" src="${url}" alt="${p.name}" loading="lazy" decoding="async" onerror="this.remove()">` : '';
  return `<div class="${cls} cat-${cat}"><i class="bi ${icon}"></i>${photo}</div>`;
}

const WEATHER_ICONS = { sunny: 'bi-brightness-high-fill', partly: 'bi-cloud-sun-fill', cloudy: 'bi-cloud-fill', rain: 'bi-cloud-rain-fill' };
const WEATHER_LABELS = { sunny: 'Sunny', partly: 'Partly cloudy', cloudy: 'Cloudy', rain: 'Light rain' };