<?php
// Lists every photo in images/places so the dashboard can match photos to places without hard-coded file names.
require __DIR__ . '/../includes/bootstrap.php';
api_handle(function (array $in) {
    auth_require();
    $images = [];
    foreach (glob(__DIR__ . '/../images/places/*.{jpg,jpeg,png,webp,avif}', GLOB_BRACE) ?: [] as $file) {
        $name = basename($file);
        $base = strtolower(pathinfo($name, PATHINFO_FILENAME));
        $images[$base] = 'images/places/' . rawurlencode($name) . '?v=' . filemtime($file);
    }
    return ['images' => $images];
});
