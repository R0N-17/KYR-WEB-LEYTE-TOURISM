# Part 2: Admin Settings page

Only the missing Part 2 items were added. The admin layout, theme code, auth, CRUD, weather and public site are unchanged.

## Added
- `admin/settings.html`, `admin/js/settings.js`: the Settings page (same shell, cards and tokens as the dashboard).
- Settings CSS appended to `admin/css/admin.css` (`.ad-theme-choice*`, `.ad-info-grid`, `.ad-set-*`); no existing rule edited.
- `CHANGES-PART2.md` (this file).

## Modified
- `admin/js/admin.js`: "Settings" nav item (new "System" group, `bi-gear`) and breadcrumb title; after the existing account theme save it now also fires an `admin:theme-saved` event so the page can report the real result. Behaviour elsewhere is identical.
- `includes/auth.php`: `admin_public()` additionally returns `role` and, when the record has it, `created`. Still no password, id or token.
- `tools/selftest.php`: new checks (me.php 401/403, returns only the signed-in admin, no password hash, settings page served).

## Behaviour
- **Appearance:** Light / Dark buttons use the existing `data-theme-mode` hooks of `js/theme.js`, so there is one theme implementation, one `leyteTheme` key, and the same account save. The page states whether the account save succeeded. Auto (Day/Night) is not offered or claimed.
- **Account information:** read from `api/admin/me.php` (server session; 401 not signed in, 403 not an admin, both redirect to the sign-in page). Shows name, email, role and creation date when present; missing fields show "Not provided"; loading skeleton and an error with "Try again". Read-only: the backend has no account-edit endpoint. There is no username field in the data model, so none is shown.
- **Application information:** name, purpose, project type and proponents are taken from `terms.html` / `privacy.html`. Version is shown as "Not specified" because the project defines none.
