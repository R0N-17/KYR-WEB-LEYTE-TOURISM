# Admin panel redesign (visual layer only)

Scope: everything under `admin/`. No PHP, no public page, no public stylesheet and no data file was touched. Every element ID and every `api/admin/*` call the scripts rely on is unchanged, so authentication, role checks, CRUD, uploads and persistence behave exactly as before.

## Design
Calm, light, minimalist. Navy for primary actions (`#0F2447`), one blue accent (`#2563EB`) for focus, links and the active page, cool off-white page (`#F6F8FB`), white cards with thin `#E5E9F0` borders, 12 px card radius, 8 px controls, almost no shadow. Muted green / amber / red only for success / warnings / destructive actions. Font: Figtree (already self-hosted; Inter is not in the project and there is no network to add it). Icons: Bootstrap Icons (already in the project). All tokens are CSS variables at the top of `admin/css/admin.css`, so the palette can be changed in one place.

- **Sidebar:** white, sticky on desktop; groups Overview / Tourism management / Site; active page highlighted with `aria-current`; user card and a clear **Log out** button at the bottom. Phones: slide-in menu with a dimmed backdrop, closes on backdrop click, Escape or resize to desktop; the menu button reports `aria-expanded`.
- **Dashboard:** greeting with the admin's first name; four real metrics (destinations, categories, towns and cities, photo coverage); destinations by category; five most recently updated destinations with thumbnails; quick actions. Nothing is invented: numbers come from `api/admin/stats.php`, thumbnails from `api/admin/destinations.php`.
- **Destinations:** page header, search with icon, category filter, count, loading skeletons, empty / no-match / error states. Table on desktop; on phones each row becomes a stacked card. Consistent View / Edit / Delete actions with text labels or accessible names. A muted "No photo" tag appears only when a destination really has no photo.
- **Add/Edit modal:** sections (Basic information, Location, Categories, Visitor information, Visiting guidance, Destination details and tips, Photo; see FINAL-REVIEW.md for the later changes), required markers, inline validation messages, saved-photo / new-photo labels, a drag-and-drop upload area with preview, loading state, and a guard that ignores repeat submits. Header and footer stay fixed; only the body scrolls; the page behind is locked. Full screen on phones.
- **Categories:** same table language; add/edit modal with icon picker; delete modal that requires choosing where in-use destinations move.
- **Login:** minimal card, inline field errors, show-password toggle, loading state. Still self-contained (does not need Bootstrap).
- Focus rings on every control, `prefers-reduced-motion` respected, toasts reworked (icon, left colour bar, close button).

## Changed files (all under `leyte-tourisim-latest-beta-app/`)
- `admin/css/admin.css` (new design system, rewritten)
- `admin/css/login.css` (rewritten)
- `admin/index.html`, `admin/destinations.html`, `admin/categories.html`, `admin/login.html`
- `admin/js/admin.js` (sidebar, top bar, toasts)
- `admin/js/dashboard.js`, `admin/js/destinations.js`, `admin/js/categories.js`
- `ADMIN-REDESIGN.md` (this file)

No setup changes: unzip and run `php -S localhost:8000 router.php` as before. Hard-refresh (Ctrl+F5) once so the browser drops the old admin stylesheet.

## Tests
Performed (headless Chromium at 1440x900, 820x1100 and 390x844, against a Node stand-in for the admin endpoints because PHP is not installed in my environment):
- 78/78 checks on the redesigned admin: all pages with no horizontal overflow and no JS errors at all three sizes; real counts on the dashboard; sidebar groups, active state and log out; mobile menu open/close with Escape; stacked cards on phones; modal fits the viewport, only its body scrolls, page behind locked, wheel scroll reaches the bottom with the photo area and Save reachable (all three sizes); saved vs new photo labels; drag-and-drop of a non-image rejected; empty-submit inline validation; Save shows a loading state and three rapid submits send exactly one request; success toast; delete confirmation; category modal, duplicate name message and move-to prompt for an in-use category; login inline validation and show-password; log out then protected page redirects.
- Earlier suites re-run after the redesign: 43/43 public-site checks, 27/27 admin modal checks, register/login/forgot-password load clean.
- `node --check` on every JS file.

Not performed (needs PHP on your machine): everything that depends on the real backend: real admin login and 401/403, create/edit/delete persistence, real photo upload and replacement, category rename/delete against the files, real session invalidation on log out. The stand-in server only answers the endpoints the screens call and does no real validation, so these screens have not been proven against your PHP. Please run the checklists in `ADMIN-MODULE.md` and `SPRINT2.md`.

## Known limitations
- Inter was requested but is not bundled; Figtree is used.
- No Settings or profile page exists in the admin, so none was added (the Account group is just the user card and Log out).
- The dashboard has no activity feed or charts beyond what the existing stats endpoint provides.
- Tested in Chromium only (no Safari or Firefox here).
