# Part 3: final testing, confirmed fixes and release packaging

Parts 1 and 2 are unchanged. Only the defects below were fixed.

## Confirmed defects and fixes
| # | Defect (how it was confirmed) | Fix |
|---|---|---|
| 1 | **SCRUM-15.** With every preference unselected, `renderRecommended()` called `fallbackPlaces()` and filled the section with generic cards ("here are some places to explore"). Confirmed by reading the code path: `!hasPrefs()` -> `fallbackPlaces(all)`; the fix is verified by the browser tests in TEST-REPORT-PART3.md. | `js/dashboard.js`: nothing selected now shows **no cards** and the message "Select at least one preference to see recommendations." (with a Set preferences button). `fallbackPlaces()` was deleted, so nothing can repopulate the list. |
| 2 | **SCRUM-15.** Categories selected but nothing matching also showed `fallbackPlaces()` (unrelated cards). | Now a separate empty state: "No matching destinations. No destinations match … yet." No cards. |
| 3 | **SCRUM-15.** With no category but a setting / budget / trip length picked, places that did not fit were still listed (an under-specified selection behaved like "match everything"). | Without categories, only places that fit every picked setting / budget / trip length count as matches; if none fit, the no-match state is shown. |
| 4 | Save-preferences messages promised "general suggestions". | Now: "Preferences cleared. Select at least one preference to see recommendations." |
| 5 | **Test environment.** `tools/selftest.php` and `tools/weather-selftest.php` wrote their server log to a fixed file in the shared temp folder; if another user had created it, the log could not be opened (the permission error seen earlier). Application code was not involved. | Log file names are now unique per run. |
| 6 | **Missing `mbstring`.** The app uses `mb_*` functions; without the extension PHP died with a fatal error and the browser got no JSON. This is a server setup problem, not a code bug. | `includes/bootstrap.php` now answers with a clear JSON message when mbstring is missing; both self-tests stop with "ENVIRONMENT: ..." (exit 2) instead of failing mysteriously; the README lists the required extensions. |

## Deliberately unchanged
- The scoring algorithm and preference options. When some places do match the chosen categories but fewer than six, the list is still filled up with other places and says so ("Only N match, so we added other places to explore"). That is existing, labelled behaviour and is not the no-preference fallback; remove the padding line in `renderRecommended()` if you want matches only.
- Auto (Day/Night) is still not implemented and not claimed. Google Maps routing and SCRUM-17 are out of scope.

## Release packaging
- Removed from the package: `includes/config.local.php` (it held a real OpenWeather key), `data/users.txt` (a real account record) and the empty `*.lock` files. The app recreates what it needs.
- Safe `includes/config.local.example.php`, README setup/requirements, `.gitignore` entries for private files.
- Added: `CHANGES-PART3.md`, `TEST-REPORT-PART3.md`.

## Files modified
`js/dashboard.js`, `includes/bootstrap.php`, `tools/selftest.php`, `tools/weather-selftest.php`, `README.txt`, `.gitignore`.
