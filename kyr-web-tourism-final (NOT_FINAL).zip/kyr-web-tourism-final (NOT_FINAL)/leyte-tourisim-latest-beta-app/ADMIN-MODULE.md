# Admin module: SCRUM-16 Manage Local Tourism Data (CRUD)

The admin console lives in `admin/` and is separate from the public site (own pages, own CSS, own navigation).
Destinations are now stored in `data/destinations.json` and the public site reads them from `api/destinations.php`.
`js/data.js` no longer contains the places.

## Setup

1. Copy the files from this package over your project (same folder structure). Nothing is deleted; `data/users.txt` is untouched.
2. Start the site as before: `php -S localhost:8000 router.php` (PHP 8.1 or newer recommended; 8.0 works for the site, the CLI tool is written for 8.x).
3. Make yourself an admin (one of):
   - Promote an existing account: `php tools/make-admin.php promote you@example.com`
   - Create a new admin: `php tools/make-admin.php create you@example.com "First" "Last"` (it asks for a password)
   - Check who is an admin: `php tools/make-admin.php list`, remove rights: `php tools/make-admin.php demote you@example.com`
4. Open `http://localhost:8000/admin/login.html` and sign in.
5. The first time anything reads destinations, `data/destinations.json` is created from `includes/destinations.seed.json` (your original 11 places, with their weather coordinates). To start over from the originals, delete `data/destinations.json`.
6. Make sure `data/` and `images/places/` are writable by PHP. On Apache, `AllowOverride All` is needed for the `.htaccess` files (they are already in place for `data/`, `includes/`, `tools/` and `images/places/`).

## Files

New:
| File | Why |
|---|---|
| `includes/destinations.php` | The whole data layer: JSON storage with locking and atomic writes, validation, photo handling. **The only file to rewrite when moving to MySQL.** |
| `includes/destinations.seed.json` | The original 11 destinations, copied into storage on first use. |
| `api/destinations.php` | Public list used by the dashboard and sign-up questionnaire. Same shape as the old `PLACES`. |
| `api/admin/login.php`, `me.php` | Admin sign-in and "who am I" (401 = signed out, 403 = not an admin). |
| `api/admin/stats.php` | Dashboard numbers. |
| `api/admin/destinations.php` | Read: list with search text and category filter. |
| `api/admin/destination-save.php` | Create and Update, including the photo. |
| `api/admin/destination-delete.php` | Delete (photo is archived, not destroyed). |
| `admin/login.html`, `index.html`, `destinations.html` | The admin interface. |
| `admin/css/admin.css`, `admin/js/admin.js`, `dashboard.js`, `destinations.js` | Admin-only styling and scripts. |
| `tools/make-admin.php` | Command-line only way to create, promote or demote admins. |
| `tools/.htaccess`, `images/places/.htaccess`, `images/places/README.txt` | Block web access to tools; block running anything in the photo folder. |

Modified:
| File | Change |
|---|---|
| `includes/config.php` | New constants (storage paths, photo limits, allowed types). |
| `includes/bootstrap.php` | Loads `destinations.php`. |
| `includes/auth.php` | `role` on users (registration always sets `user`), `auth_require_admin()`, `auth_admin_login()`. |
| `includes/weather.php` | Weather coordinates now come from each destination instead of a hardcoded list. |
| `js/data.js` | `PLACES` starts empty and is filled by `loadPlaces()` from the server. Added `escHtml`. Categories, budgets etc. unchanged. |
| `js/dashboard.js` | Waits for the places before drawing, and escapes destination text in HTML templates (admin-entered text must never run as HTML). No visible change. |
| `js/register.js` | Escapes destination text in the questionnaire results. No visible change. |
| `router.php` | Also blocks `/tools`, and scripts inside `/images/places`. |
| `.gitignore` | Ignores the new lock/temp files. |

## How it behaves

- **Access control:** every `api/admin/*` endpoint except `login.php` calls `auth_require_admin()` on the server. A signed-out request gets 401, a signed-in ordinary user gets 403. The role is read from `users.txt` on every request, so demoting someone takes effect at once. Admin pages hide themselves until `me.php` confirms the role and redirect to `admin/login.html` otherwise. Public registration can only create `user` accounts, and there is no web endpoint that sets a role.
- **Photos (single source of truth):** one photo per destination, stored in the destination's own record as `image = {file, v}` and saved as `images/places/<destination-id>-<stamp>.<ext>`. `api/destinations.php` (public) and the admin endpoints both build the URL with `dest_image_url()` (`...?v=<version>`, so a replaced photo bypasses browser caches); `js/data.js` just uses `place.image`. `api/place-images.php` and name-based matching were removed. A replacement is written to a new file first, the record is updated, and only then is the old file removed (never if another destination still uses it). Photos that already existed in `images/places/` are linked to their destinations once, automatically. Uploads are accepted as JPG, PNG, WebP or AVIF only, up to 3 MB and 8000 px per side. The type is decided from the file's real contents (never the file name or the browser's claim), the saved name and extension are chosen by the server, files containing `<?php` are rejected, and the photo folder cannot run scripts. Renaming a destination does not touch its photo (it is tied to the id). Deleting a destination moves its photo to `data/deleted-photos/` (not reachable from the web).
- **Validation:** required fields, lengths, allowed values, numeric ranges and coordinates are checked on the server (the form also checks in the browser). Names must be unique (compared the same way photos are matched, so "Price Mansion" and "price  mansion" count as duplicates). `<` and `>` are rejected in all text fields.
- **Weather:** each place is cached separately with the coordinates it was fetched for. A new, renamed or moved place gets a live reading on the next request; other edits cost no OpenWeather calls.

## Testing checklist

Access
- [ ] `admin/index.html` while signed out redirects to `admin/login.html`.
- [ ] Sign in at `admin/login.html` with a normal (non-admin) account: refused with the "not an administrator" message.
- [ ] While signed in as a normal user on the public dashboard, open `admin/destinations.html`: redirected to the admin sign-in. In the browser console run `fetch('api/admin/destinations.php',{method:'POST',headers:{'Content-Type':'application/json'},body:'{}'}).then(r=>r.status)` and get `403`. Signed out, it returns `401`.
- [ ] Register a new account on the public site: it is not an admin (`php tools/make-admin.php list` does not show it).
- [ ] Promote your account with the tool, sign in at `admin/login.html`: you reach the dashboard. Demote it again: the next admin request is refused.
- [ ] `http://localhost:8000/tools/make-admin.php`, `/data/destinations.json` and `/includes/destinations.seed.json` all return 403.

Dashboard
- [ ] Shows 11 destinations right after first start, plus towns, photo counts and category bars. Numbers change after you add or delete.

Read, search, filter
- [ ] The table lists all 11 places. Search "palo" shows the two Palo places. Search a town name works. The category filter narrows the list, and Clear resets it.
- [ ] The eye button shows every field of a destination, including its photo if it has one.

Create
- [ ] Add a destination with every field and a photo: success message, it appears in the table, and on the public dashboard (search box and recommendations, details popup with its photo, fee, hours, facilities, highlights).
- [ ] Submit with required fields empty: a clear error, nothing saved. Leave no category ticked: clear error.
- [ ] Add a second destination with the same name (also with different capitals or spacing): "already exists" error.
- [ ] Enter `<b>x</b>` in a text field: rejected.

Update
- [ ] Edit text fields, fee, categories and coordinates: saved, and the public site shows them after a reload.
- [ ] Replace the photo: the new photo shows publicly. Tick "Remove the current photo": it falls back to the icon tile.
- [ ] Rename a destination that has a photo: the photo still shows.

Photo security
- [ ] Choose a `.pdf`, `.txt`, `.svg` or `.html` file: rejected. Rename a text file to `evil.jpg` and upload it: rejected (not a real image). A photo over 3 MB: rejected. Nothing odd appears in `images/places/`.

Delete
- [ ] Delete shows a confirmation naming the destination. "Keep it" does nothing. "Yes, delete" removes it from the table and from the public dashboard, and its photo moves to `data/deleted-photos/`.

Public site still works
- [ ] Register a new test account: the questionnaire shows its picks. Dashboard: recommendations, details popup, search, "Check weather", recently viewed, theme and preferences all behave as before. With an OpenWeather key set, weather appears for a destination you just added after the cache refreshes.

## Notes and limits

- The login and registration pages' background slideshow is decorative and is not part of the destination data, so it is not managed here.
- One photo per destination (that is what the public site displays).
- If a destination is renamed, anyone who had it in their "Recently viewed" list loses that entry (that list stores names).
- Writes are safe against two requests at once (locking + temp file and rename), but a JSON file is not meant for heavy traffic. That is the reason all access is in `includes/destinations.php`.


## Categories (managed, not fixed)

Categories are stored in `data/categories.json` (created from `includes/categories.seed.json` on first use: beach, nature, history, landmark, same keys as before) and managed at `admin/categories.html`. The destination form also has a **+ New category** shortcut.

- Each category has a **key** (made from the name when created, never changes), a **label**, an **icon** and an **outdoor** flag (rain / rough-sea warnings). Renaming only changes the label, so destinations and users' saved preferences stay linked.
- Duplicates are rejected on the server, ignoring capitals, spacing and punctuation ("Food & Markets" = "food   markets").
- **Delete:** a category still used by destinations can only be deleted by choosing another category to move them to. Visitors' saved preferences are migrated in the same request (deleted key replaced by the target, or removed). The category is removed last, so a failed delete can be repeated. The last remaining category can't be deleted.
- Public site: `api/categories.php` feeds the sign-up questionnaire, dashboard preferences, icons and recommendations. `js/data.js` no longer lists categories.
- Files: `includes/categories.php` (the data layer; rewrite this for MySQL), `api/categories.php`, `api/admin/categories.php`, `category-save.php`, `category-delete.php`, `admin/categories.html`, `admin/js/categories.js`.
- Lock order when several files are touched: categories, then destinations, then users.
- Known limit: the rough-sea wind warning in `js/weather.js` still looks for the category key `beach`; the rain warning uses the outdoor flag.
