<?php
// Settings only.
const DB_FILE       = __DIR__ . '/../data/users.txt';   // temporary "database"
const THEMES        = ['light', 'dark'];
const DEFAULT_THEME = 'light';   // only used when a sign-up sends no valid theme (the site sends the one on screen)
const REMEMBER_DAYS = 30;
const RECENT_MAX    = 6;    // how many "Recently viewed" places are kept per account

// Allowed answers for the travel-preference questionnaire (match js/data.js)
// Categories are no longer a fixed list: they live in data/categories.json and are managed from admin/categories.html (see includes/categories.php).
const PREF_AREAS   = ['urban', 'rural', 'either'];
const PREF_TIMES   = ['morning', 'afternoon', 'evening'];
const PREF_BUDGETS = ['free', '50', '100', 'any'];
const PREF_TRIPS   = ['half', 'full', 'overnight'];

// OpenWeather (https://openweathermap.org/api). The key is NEVER sent to the browser: api/weather.php calls OpenWeather for you.
// Set it in ONE of these ways:  1) environment variable OPENWEATHER_API_KEY   2) copy includes/config.local.example.php to includes/config.local.php
const WEATHER_TTL        = 600;                                   // seconds a fetched reading is reused (saves your free-plan quota)
const WEATHER_RETRY      = 60;                                    // after a failed refresh (network, outage), wait this long before asking OpenWeather again
const WEATHER_RETRY_LONG = 300;                                   // same, after the key was rejected or the rate limit was hit
const WEATHER_MAX_AGE    = 3 * 3600;                              // stale readings are only served while at least one is newer than this; the website labels anything older
const WEATHER_DROP_AFTER = 86400;                                 // readings older than a day are never sent to the browser
const WEATHER_CACHE_FILE = __DIR__ . '/../data/weather-cache.json';
const OWM_ENDPOINT       = 'https://api.openweathermap.org/data/2.5/weather';
// SCRUM-16: local tourism data, managed from the admin module (admin/).
const DEST_FILE       = __DIR__ . '/../data/destinations.json';   // every destination record
const DEST_SEED_FILE  = __DIR__ . '/destinations.seed.json';      // the original 11 places, copied into DEST_FILE the first time it is needed
const DEST_TRASH_DIR  = __DIR__ . '/../data/deleted-photos';      // photos of deleted destinations are moved here, not destroyed
const PLACE_IMG_DIR   = __DIR__ . '/../images/places';            // photos; each destination's record names its file (image = {file, v}), see includes/destinations.php
const IMG_MAX_BYTES   = 3 * 1024 * 1024;                          // largest photo the admin may upload
const IMG_MAX_SIDE    = 8000;                                     // widest or tallest photo, in pixels
const IMG_TYPES       = ['image/jpeg' => 'jpg', 'image/png' => 'png', 'image/webp' => 'webp', 'image/avif' => 'avif'];   // allowed content types -> file extension we choose
const CAT_FILE        = __DIR__ . '/../data/categories.json';     // every tourism category (key, label, icon)
const CAT_SEED_FILE   = __DIR__ . '/categories.seed.json';        // the original 4 categories, copied into CAT_FILE the first time it is needed
const CAT_MAX         = 30;                                       // most categories the admin may create
const DEST_AREAS      = ['urban', 'rural'];
const DEST_VIEWS      = ['sunrise', 'sunset'];

if (is_file(__DIR__ . '/config.local.php')) require __DIR__ . '/config.local.php';
