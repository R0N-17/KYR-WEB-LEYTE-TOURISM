<?php
// Copy this file to config.local.php and paste your OpenWeather key. config.local.php is blocked from the web.
const OPENWEATHER_API_KEY = '6ed6b70308f25ff3452706379c2e463e';
