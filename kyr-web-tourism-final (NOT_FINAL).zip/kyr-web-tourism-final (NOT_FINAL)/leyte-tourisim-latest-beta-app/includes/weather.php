<?php
// OpenWeather helper: one real reading per place, cached on disk so visitors never cost an API call each.
// Nothing here is ever invented: a reading exists only if OpenWeather returned it. When it can't (no key, bad key, network down,
// rate limit, place without coordinates) the place simply has no reading and the website says "unavailable".
//
// Cache file (data/weather-cache.json):
//   { "data":  { "<place name>": { ...reading..., "lat":.., "lng":.., "fetched": <unix time we asked OpenWeather> }, ... },
//     "retry": { "until": <unix time>, "status": 502, "message": "..." } }      <- only after a failed refresh
// Each place is refreshed on its own: a reading is reused for WEATHER_TTL seconds, and only while the place still has the same coordinates.
// A new, renamed or moved place gets a reading on the next request; saving unrelated edits in the admin costs no API calls at all.

// Coordinates are kept on the server so the browser can't ask for arbitrary locations with your key.
// They come from each destination's record (data/destinations.json), edited in the admin module.
// Names must match the destination names shown on the dashboard.
function weather_valid_coords($lat, $lng): bool {
    if (!is_numeric($lat) || !is_numeric($lng)) return false;
    $lat = (float)$lat; $lng = (float)$lng;
    return abs($lat) <= 90 && abs($lng) <= 180 && !($lat == 0.0 && $lng == 0.0);   // 0,0 is the "nothing entered" value, not a place in Leyte
}

// [placeName => [lat, lng]] for every destination that has usable coordinates, plus Tacloban City for the dashboard header.
function weather_spots(): array {
    $spots = [];
    foreach (dest_all() as $d)
        if (isset($d['name'], $d['lat'], $d['lng']) && weather_valid_coords($d['lat'], $d['lng']))
            $spots[(string)$d['name']] = [(float)$d['lat'], (float)$d['lng']];
    $spots['Tacloban City'] = [11.2444, 125.0048];   // dashboard header badge
    return $spots;
}

function weather_key(): string {
    $k = getenv('OPENWEATHER_API_KEY');
    if (!$k && defined('OPENWEATHER_API_KEY')) $k = OPENWEATHER_API_KEY;
    $k = trim((string)$k);
    return $k === 'PASTE_YOUR_KEY_HERE' ? '' : $k;
}

/* ======================= Cache ======================= */

// Always returns ['data' => [...], 'retry' => ?array]. Also understands the older file format ({time, data}).
function weather_cache_read(): array {
    $raw = @file_get_contents(WEATHER_CACHE_FILE);
    $c = $raw ? json_decode($raw, true) : null;
    $out = ['data' => [], 'retry' => null];
    if (!is_array($c) || !is_array($c['data'] ?? null)) return $out;
    foreach ($c['data'] as $name => $r) {
        if (!is_array($r) || !isset($r['tempC'], $r['id'])) continue;
        $r['fetched'] = (int)($r['fetched'] ?? $c['time'] ?? 0);
        $out['data'][(string)$name] = $r;
    }
    if (is_array($c['retry'] ?? null) && isset($c['retry']['until'], $c['retry']['message']))
        $out['retry'] = ['until' => (int)$c['retry']['until'], 'status' => (int)($c['retry']['status'] ?? 502), 'message' => (string)$c['retry']['message']];
    return $out;
}

function weather_cache_write(array $c): void {
    $json = json_encode($c);
    $tmp = WEATHER_CACHE_FILE . '.tmp' . getmypid();
    if (@file_put_contents($tmp, $json) === false || !@rename($tmp, WEATHER_CACHE_FILE)) {
        @unlink($tmp);
        if (@file_put_contents(WEATHER_CACHE_FILE, $json, LOCK_EX) === false)
            error_log('weather: could not write ' . basename(WEATHER_CACHE_FILE) . '; check that the data folder is writable');
    }
}

// Does this stored reading belong to these coordinates? (A place that was moved must not keep showing the old spot's weather.)
function weather_same_spot(array $r, float $lat, float $lng): bool {
    return isset($r['lat'], $r['lng']) && abs((float)$r['lat'] - $lat) < 1e-6 && abs((float)$r['lng'] - $lng) < 1e-6;
}

// Names of the places that need a fresh reading: none stored yet, moved, or older than WEATHER_TTL.
function weather_due(array $spots, array $cache, int $now): array {
    $due = [];
    foreach ($spots as $name => [$lat, $lng]) {
        $r = $cache['data'][$name] ?? null;
        if (!$r || !weather_same_spot($r, $lat, $lng) || $now - (int)$r['fetched'] >= WEATHER_TTL) $due[] = $name;
    }
    return $due;
}

// What the endpoint returns: only readings for places that exist now, with their current coordinates, and nothing ancient.
function weather_result(array $spots, array $cache, bool $stale, ?string $notice = null): array {
    $now = time(); $data = []; $updated = 0;
    foreach ($spots as $name => [$lat, $lng]) {
        $r = $cache['data'][$name] ?? null;
        if (!$r || !weather_same_spot($r, $lat, $lng) || $now - (int)($r['observed'] ?? 0) > WEATHER_DROP_AFTER) continue;
        if ($now - (int)$r['fetched'] >= WEATHER_TTL) $stale = true;
        $updated = max($updated, (int)$r['fetched']);
        unset($r['lat'], $r['lng'], $r['fetched']);   // internal bookkeeping, not for the browser
        $data[$name] = $r;
    }
    return ['data' => $data, 'time' => $updated, 'stale' => $stale, 'notice' => $stale ? $notice : null];
}

// A refresh was not possible. Keep serving what we have if something is still reasonably recent; otherwise say plainly that weather is unavailable.
function weather_fallback(array $spots, array $cache, int $status, string $message): array {
    $res = weather_result($spots, $cache, true, $message);
    $recent = array_filter($res['data'], fn($r) => time() - (int)($r['observed'] ?? 0) <= WEATHER_MAX_AGE);
    if (!$recent) throw new ApiError($message, $status);
    return $res;
}

/* ======================= OpenWeather ======================= */

// GETs several URLs at once. Returns [key => [httpStatus, body]].
function http_get_many(array $urls): array {
    $out = [];
    if (function_exists('curl_multi_init')) {
        $mh = curl_multi_init();
        $handles = [];
        foreach ($urls as $k => $u) {
            $ch = curl_init($u);
            curl_setopt_array($ch, [CURLOPT_RETURNTRANSFER => true, CURLOPT_TIMEOUT => 8, CURLOPT_CONNECTTIMEOUT => 4, CURLOPT_FOLLOWLOCATION => false]);
            curl_multi_add_handle($mh, $ch);
            $handles[$k] = $ch;
        }
        do {
            $st = curl_multi_exec($mh, $active);
            if ($active) curl_multi_select($mh, 1.0);
        } while ($active && $st === CURLM_OK);
        foreach ($handles as $k => $ch) {
            $out[$k] = [(int)curl_getinfo($ch, CURLINFO_RESPONSE_CODE), (string)curl_multi_getcontent($ch)];
            curl_multi_remove_handle($mh, $ch);
        }
        curl_multi_close($mh);
        return $out;
    }
    // No cURL extension: fall back to one request at a time.
    $ctx = stream_context_create(['http' => ['timeout' => 8, 'ignore_errors' => true]]);
    foreach ($urls as $k => $u) {
        $body = @file_get_contents($u, false, $ctx);
        $status = isset($http_response_header[0]) && preg_match('#\s(\d{3})\s#', $http_response_header[0], $m) ? (int)$m[1] : 0;
        $out[$k] = [$status, (string)$body];
    }
    return $out;
}

// Keeps only what the dashboard shows. Returns null unless OpenWeather really supplied a temperature, a condition and an observation time.
function weather_normalize(array $j): ?array {
    $w = $j['weather'][0] ?? null;
    if (!isset($j['main']['temp'], $j['dt']) || !is_numeric($j['main']['temp']) || !isset($w['id'])) return null;
    return [
        'tempC'    => (int)round($j['main']['temp']),
        'feelsC'   => (int)round($j['main']['feels_like'] ?? $j['main']['temp']),
        'humidity' => (int)($j['main']['humidity'] ?? 0),
        'windKph'  => (int)round(((float)($j['wind']['speed'] ?? 0)) * 3.6),   // OpenWeather gives m/s
        'rainMm'   => round((float)($j['rain']['1h'] ?? 0), 1),
        'clouds'   => (int)($j['clouds']['all'] ?? 0),
        'id'       => (int)$w['id'],                                          // OpenWeather condition code
        'desc'     => ucfirst((string)($w['description'] ?? '')),
        'night'    => str_ends_with((string)($w['icon'] ?? ''), 'n'),
        'observed' => (int)$j['dt'],
    ];
}

// Returns ['data' => [placeName => reading], 'time' => unixTime, 'stale' => bool, 'notice' => ?string].
// Throws ApiError (a readable message) when there is nothing usable to show.
function weather_get_all(): array {
    $spots = weather_spots();
    $cache = weather_cache_read();
    if (!weather_due($spots, $cache, time())) return weather_result($spots, $cache, false);

    // Only one request at a time talks to OpenWeather. The others wait, then find the fresh readings in the cache.
    $lock = @fopen(WEATHER_CACHE_FILE . '.lock', 'c');
    if ($lock) flock($lock, LOCK_EX);
    try {
        $cache = weather_cache_read();
        $now = time();
        $due = weather_due($spots, $cache, $now);
        if (!$due) return weather_result($spots, $cache, false);

        // A recent failure: don't ask again yet, so a bad key or an outage never turns every page view into API calls.
        if ($cache['retry'] && $cache['retry']['until'] > $now)
            return weather_fallback($spots, $cache, $cache['retry']['status'], $cache['retry']['message']);

        $key = weather_key();
        if ($key === '')
            return weather_fallback($spots, $cache, 503, 'Live weather is not set up yet. Add your OpenWeather API key (see README).');

        $urls = [];
        foreach ($due as $name) {
            [$lat, $lng] = $spots[$name];
            $urls[$name] = OWM_ENDPOINT . '?' . http_build_query(['lat' => $lat, 'lon' => $lng, 'units' => 'metric', 'appid' => $key]);
        }
        $got = 0; $unauthorized = 0; $limited = 0;
        foreach (http_get_many($urls) as $name => [$status, $body]) {
            if ($status === 401) { $unauthorized++; continue; }
            if ($status === 429) { $limited++; continue; }
            $reading = $status === 200 ? weather_normalize((array)json_decode($body, true)) : null;
            if (!$reading) continue;
            [$lat, $lng] = $spots[$name];
            $cache['data'][$name] = $reading + ['lat' => $lat, 'lng' => $lng, 'fetched' => $now];
            $got++;
        }
        foreach (array_keys($cache['data']) as $name)   // forget places that were deleted or renamed, and anything very old
            if (!isset($spots[$name]) || $now - (int)($cache['data'][$name]['observed'] ?? 0) > WEATHER_DROP_AFTER) unset($cache['data'][$name]);

        $failed = count($due) - $got;
        $cache['retry'] = null;
        $status = 502; $message = '';
        if ($failed > 0) {
            if ($got === 0 && $unauthorized === count($due)) { $status = 502; $message = 'OpenWeather rejected the API key. A brand-new key can take up to a couple of hours to start working.'; }
            elseif ($got === 0 && $limited > 0)              { $status = 503; $message = 'The weather service is busy right now. Try again in a few minutes.'; }
            else                                              { $status = 502; $message = 'The weather service is not reachable right now. Try again in a moment.'; }
            $wait = $unauthorized || $limited ? WEATHER_RETRY_LONG : WEATHER_RETRY;
            $cache['retry'] = ['until' => $now + $wait, 'status' => $status, 'message' => $message];
        }
        weather_cache_write($cache);

        return $failed > 0 ? weather_fallback_or_partial($spots, $cache, $got, $status, $message) : weather_result($spots, $cache, false);
    } finally {
        if ($lock) { flock($lock, LOCK_UN); fclose($lock); }
    }
}

// After a refresh in which some places failed: if some succeeded, send what we have (the rest simply have no reading); if none did, fall back.
function weather_fallback_or_partial(array $spots, array $cache, int $got, int $status, string $message): array {
    return $got > 0 ? weather_result($spots, $cache, true, $message) : weather_fallback($spots, $cache, $status, $message);
}
