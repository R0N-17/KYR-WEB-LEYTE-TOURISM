<?php
// SCRUM-16: the public list of destinations. The dashboard and the sign-up questionnaire load their places from here
// (it replaces the PLACES array that used to be written in js/data.js). No login needed: this is public tourism information.
require __DIR__ . '/../includes/bootstrap.php';
header('Cache-Control: no-store');   // always the current list, so a replaced photo's new URL reaches every page load
api_handle(fn() => ['places' => array_map('dest_public', array_values(dest_all()))]);
