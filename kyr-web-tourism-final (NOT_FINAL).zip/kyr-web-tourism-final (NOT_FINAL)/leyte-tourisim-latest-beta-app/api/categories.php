<?php
// The public list of tourism categories. The sign-up questionnaire, the dashboard preferences, icons and recommendations load it from here
// (it replaces the CATS array that used to be written in js/data.js). No login needed: it is the same public information as the destinations.
require __DIR__ . '/../includes/bootstrap.php';
api_handle(fn() => ['categories' => array_map('cat_public', cat_all())]);
