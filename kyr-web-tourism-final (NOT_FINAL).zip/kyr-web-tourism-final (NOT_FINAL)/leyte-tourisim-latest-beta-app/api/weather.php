<?php
// Live weather for every tourist spot (plus Tacloban for the header badge). Signed-in users only.
// Every failure (missing key, rejected key, outage, a damaged data file) comes back as a clean {ok:false, message}, never as a crash,
// and the weather endpoint is separate from destination browsing and the admin screens, so none of them depend on it.
require __DIR__ . '/../includes/bootstrap.php';
require __DIR__ . '/../includes/weather.php';
api_handle(function () {
    auth_require();
    session_write_close();   // don't hold the session lock while waiting on OpenWeather
    try {
        $w = weather_get_all();
    } catch (ApiError $e) {
        throw $e;
    } catch (Throwable $e) {
        error_log('weather: ' . get_class($e) . ': ' . $e->getMessage());   // the message never contains the API key (it is only ever in the request URL)
        throw new ApiError('Live weather is unavailable right now.', 502);
    }
    return ['weather' => $w['data'], 'updated' => $w['time'], 'stale' => $w['stale'], 'notice' => $w['notice']];
});
