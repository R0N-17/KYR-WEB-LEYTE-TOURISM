<?php
// KYR Web Tourism: integration self-test for the REAL PHP backend. Command line only.
//
//   php tools/selftest.php
//
// It never touches your real data. It copies the project into a temporary folder with EMPTY data (the app seeds its own
// destinations and categories from includes/*.seed.json), starts PHP's built-in web server on that copy, and exercises the real
// endpoints over HTTP: public reads, registration, sessions, admin authorization, destination create / update / delete,
// photo upload and rejection, category rules, logout. Needs PHP 8.1+ with the json, fileinfo and gd (or getimagesize) extensions the app already uses.
// Exit code 0 = everything passed.
if (PHP_SAPI !== 'cli') { http_response_code(403); exit('Command line only.'); }
// Environment preflight: a missing PHP extension is a server setup problem, not an application failure. Say so and stop before any test runs.
if (PHP_VERSION_ID < 80100) { fwrite(STDERR, "ENVIRONMENT: PHP 8.1 or newer is required (this is " . PHP_VERSION . "). No tests were run.\n"); exit(2); }
foreach (['json', 'mbstring', 'fileinfo'] as $__ext) if (!extension_loaded($__ext)) { fwrite(STDERR, "ENVIRONMENT: the PHP '$__ext' extension is not enabled, so the tests cannot run. This is not an application failure. Enable it and run again.\n"); exit(2); }

$src = realpath(__DIR__ . '/..');
$tmp = sys_get_temp_dir() . '/kyr-selftest-' . bin2hex(random_bytes(4));
$pass = 0; $fail = 0; $server = null;

function check(string $name, bool $ok, string $extra = ''): void {
    global $pass, $fail;
    if ($ok) { $pass++; echo "PASS  $name\n"; } else { $fail++; echo "FAIL  $name" . ($extra !== '' ? "  [$extra]" : '') . "\n"; }
}
function copy_tree(string $from, string $to): void {
    @mkdir($to, 0777, true);
    foreach (new DirectoryIterator($from) as $f) {
        if ($f->isDot()) continue;
        $name = $f->getFilename();
        if ($name === '.git') continue;
        $target = $to . '/' . $name;
        if ($f->isDir()) copy_tree($f->getPathname(), $target); else copy($f->getPathname(), $target);
    }
}
function rm_tree(string $dir): void {
    if (!is_dir($dir)) return;
    foreach (new DirectoryIterator($dir) as $f) {
        if ($f->isDot()) continue;
        $f->isDir() ? rm_tree($f->getPathname()) : @unlink($f->getPathname());
    }
    @rmdir($dir);
}
function cleanup(): void { global $server, $tmp; if (is_resource($server)) { proc_terminate($server); proc_close($server); } rm_tree($tmp); }
register_shutdown_function('cleanup');

// ---- set up the scratch copy: code + images, but no users and no data files ----
copy_tree($src, $tmp);
foreach (glob($tmp . '/data/*') ?: [] as $f) if (basename($f) !== '.htaccess') { is_dir($f) ? rm_tree($f) : @unlink($f); }
foreach (glob($tmp . '/images/places/*') ?: [] as $f) if (is_file($f)) @unlink($f);   // the seed's one photo is irrelevant to these tests

$port = random_int(20000, 40000);
$logFile = sys_get_temp_dir() . '/kyr-selftest-server-' . basename($tmp) . '.log';   // unique per run: a fixed name left behind by another user in a shared temp folder made the log unwritable
$desc = [1 => ['file', $logFile, 'w'], 2 => ['file', $logFile, 'a']];
$server = proc_open([PHP_BINARY, '-S', "127.0.0.1:$port", 'router.php'], $desc, $pipes, $tmp);
$base = "http://127.0.0.1:$port";
for ($i = 0; $i < 50; $i++) { if (@fsockopen('127.0.0.1', $port, $e, $s, 0.2)) break; usleep(100000); }

// ---- tiny HTTP client with a cookie jar per "browser" ----
function http(string $method, string $url, ?array $json, array &$jar, bool $raw = false): array {
    $headers = "Accept: application/json\r\n";
    if ($jar) $headers .= 'Cookie: ' . implode('; ', array_map(fn($k, $v) => "$k=$v", array_keys($jar), $jar)) . "\r\n";
    $opts = ['method' => $method, 'ignore_errors' => true, 'header' => $headers, 'follow_location' => 0];
    if ($json !== null) { $opts['content'] = json_encode($json); $opts['header'] .= "Content-Type: application/json\r\n"; }
    $body = @file_get_contents($url, false, stream_context_create(['http' => $opts]));
    $status = 0;
    foreach ($http_response_header ?? [] as $h) {
        if (preg_match('#^HTTP/\S+\s+(\d+)#', $h, $m)) $status = (int)$m[1];
        if (stripos($h, 'Set-Cookie:') === 0 && preg_match('/Set-Cookie:\s*([^=]+)=([^;]*)/i', $h, $m)) { if ($m[2] === 'deleted' || $m[2] === '') unset($jar[$m[1]]); else $jar[$m[1]] = $m[2]; }
    }
    return ['status' => $status, 'body' => $body === false ? '' : $body, 'json' => $raw ? null : json_decode((string)$body, true)];
}
function post(string $path, array $json, array &$jar): array { global $base; return http('POST', $base . $path, $json, $jar); }

$anon = []; $user = []; $admin = []; $other = [];

// ---- 1. public pages and public reads ----
check('login page is served', http('GET', "$base/login.html", null, $anon, true)['status'] === 200);
check('admin sign-in page is served', http('GET', "$base/admin/login.html", null, $anon, true)['status'] === 200);
check('data files are not downloadable', http('GET', "$base/data/users.txt", null, $anon, true)['status'] >= 400);
check('includes are not downloadable', http('GET', "$base/includes/config.php", null, $anon, true)['status'] >= 400);
$r = post('/api/destinations.php', [], $anon);
check('public destinations load from the real endpoint (seeded on first use)', ($r['json']['ok'] ?? false) && count($r['json']['places'] ?? []) >= 11, $r['body']);
$p0 = $r['json']['places'][0] ?? [];
check('public destination has the expected fields and NO manual weather', isset($p0['name'], $p0['town'], $p0['cats'], $p0['time'], $p0['stay']) && !array_key_exists('weather', $p0));
$r = post('/api/categories.php', [], $anon);
$catKeys = array_column($r['json']['categories'] ?? [], 'key');
check('categories load and are seeded', count($catKeys) >= 4, $r['body']);
check('weather endpoint refuses anonymous visitors', post('/api/weather.php', [], $anon)['status'] === 401);

// ---- 2. registration, sessions, ordinary user cannot use admin endpoints ----
$r = post('/api/register.php', ['first_name' => 'Test', 'last_name' => 'User', 'email' => 'user@example.com', 'password' => 'Passw0rd!x', 'role' => 'admin'], $user);
check('registration works', ($r['json']['ok'] ?? false) === true, $r['body']);
check('registration cannot grant admin (role field ignored)', ($r['json']['user']['role'] ?? 'user') !== 'admin');
check('ordinary user: a sign-up that sends no theme gets Light', ($r['json']['user']['theme'] ?? '') === 'light', $r['body']);
check('session works (me.php)', (post('/api/me.php', [], $user)['json']['ok'] ?? false) === true);
foreach (['admin/destinations.php', 'admin/destination-save.php', 'admin/destination-delete.php', 'admin/categories.php', 'admin/category-save.php', 'admin/category-delete.php', 'admin/stats.php', 'admin/me.php'] as $ep) {
    check("ordinary user gets 403 from api/$ep", post("/api/$ep", ['name' => 'x'], $user)['status'] === 403);
    check("anonymous visitor gets 401 from api/$ep", post("/api/$ep", ['name' => 'x'], $anon)['status'] === 401);
}
check('theme can be saved as "dark"', (post('/api/theme.php', ['theme' => 'dark'], $user)['json']['ok'] ?? false) === true);
check('"system" and "auto" are no longer accepted themes', (post('/api/theme.php', ['theme' => 'system'], $user)['json']['ok'] ?? true) === false && (post('/api/theme.php', ['theme' => 'auto'], $user)['json']['ok'] ?? true) === false);
check('an unknown theme is rejected', (post('/api/theme.php', ['theme' => 'neon'], $user)['json']['ok'] ?? true) === false);

// ---- 3. administrator (created the same way tools/make-admin.php does) ----
require $tmp . '/includes/config.php';
require $tmp . '/includes/response.php';
require $tmp . '/includes/db.php';
db_insert(['id' => 'selftestadmin0001', 'first_name' => 'Self', 'last_name' => 'Test', 'email' => 'admin@example.com',
           'password' => password_hash('Passw0rd!x', PASSWORD_DEFAULT), 'theme' => 'light', 'prefs' => null, 'recent' => [], 'role' => 'admin', 'created' => date('c')]);
check('admin sign-in rejects a wrong password', post('/api/admin/login.php', ['email' => 'admin@example.com', 'password' => 'wrong'], $other)['status'] === 401);
check('admin sign-in rejects an ordinary user', post('/api/admin/login.php', ['email' => 'user@example.com', 'password' => 'Passw0rd!x'], $other)['status'] === 401);
$r = post('/api/admin/login.php', ['email' => 'admin@example.com', 'password' => 'Passw0rd!x'], $admin);
check('admin sign-in works', ($r['json']['ok'] ?? false) === true, $r['body']);
check('admin sees the destination list', count(post('/api/admin/destinations.php', [], $admin)['json']['destinations'] ?? []) >= 11);
$r = post('/api/admin/stats.php', [], $admin);
check('admin stats are available', ($r['json']['ok'] ?? false) === true && isset($r['json']['stats']['cats']));
$r = post('/api/admin/me.php', [], $admin);   // Settings page: account information
check('settings: me.php returns the signed-in administrator only', ($r['json']['admin']['email'] ?? '') === 'admin@example.com' && ($r['json']['admin']['first_name'] ?? '') === 'Self');
check('settings: me.php never exposes the password hash or id', !isset($r['json']['admin']['password']) && !isset($r['json']['admin']['id']) && !str_contains($r['body'], '$2y$'));
check('settings page is served', http('GET', "$base/admin/settings.html", null, $anon, true)['status'] === 200);

// ---- 4. destination CRUD ----
$base_dest = ['name' => 'Selftest Cove', 'town' => 'Palo', 'blurb' => 'A test place.', 'about' => 'Created by tools/selftest.php.', 'hours' => '8:00 AM - 5:00 PM',
              'feeAmt' => 25, 'area' => 'rural', 'cats' => [$catKeys[0]], 'lat' => 11.15, 'lng' => 124.99, 'time' => [], 'stay' => ['overnight']];   // 'stay' is sent on purpose: the admin no longer edits it, so it must be ignored
$r = post('/api/admin/destination-save.php', $base_dest, $admin);
check('create destination with no suggested time (optional); a stray visit length is ignored', ($r['json']['ok'] ?? false) === true, $r['body']);
$id = $r['json']['destination']['id'] ?? '';
$pub = array_values(array_filter(post('/api/destinations.php', [], $anon)['json']['places'] ?? [], fn($p) => $p['name'] === 'Selftest Cove'));
check('new destination is visible to the public site at once', count($pub) === 1 && $pub[0]['time'] === [] && $pub[0]['stay'] === [], json_encode($pub));
check('the admin record has no visit length either', !isset($r['json']['destination']['stay']) || $r['json']['destination']['stay'] === [], $r['body']);
check('a duplicate name is rejected (409)', post('/api/admin/destination-save.php', $base_dest, $admin)['status'] === 409);
check('a request with only a name is rejected (required fields)', (post('/api/admin/destination-save.php', ['name' => 'Incomplete'], $admin)['json']['ok'] ?? true) === false);
$bad = $base_dest; $bad['name'] = 'Bad Coords'; $bad['lat'] = 123;
check('invalid latitude is rejected', (post('/api/admin/destination-save.php', $bad, $admin)['json']['ok'] ?? true) === false);
$bad = $base_dest; $bad['name'] = 'Bad Cat'; $bad['cats'] = ['no-such-category'];
check('an unknown category is rejected', (post('/api/admin/destination-save.php', $bad, $admin)['json']['ok'] ?? true) === false);
$upd = $base_dest; $upd['id'] = $id; $upd['blurb'] = 'Updated blurb.'; $upd['time'] = ['morning'];
$r = post('/api/admin/destination-save.php', $upd, $admin);
check('update destination', ($r['json']['ok'] ?? false) === true, $r['body']);
$pub = array_values(array_filter(post('/api/destinations.php', [], $anon)['json']['places'] ?? [], fn($p) => $p['name'] === 'Selftest Cove'));
check('update is visible publicly, including optional guidance', ($pub[0]['blurb'] ?? '') === 'Updated blurb.' && ($pub[0]['time'] ?? []) === ['morning']);
// Existing visit-length data must survive an admin edit (the form no longer shows it, but recommendations still use it).
$list = post('/api/admin/destinations.php', [], $admin)['json']['destinations'] ?? [];
$seeded = array_values(array_filter($list, fn($d) => !empty($d['stay'])))[0] ?? null;
check('seeded destinations still carry their stored visit length', $seeded !== null);
if ($seeded) {
    $form = array_intersect_key($seeded, array_flip(['id', 'name', 'town', 'area', 'view', 'hours', 'cats', 'time', 'feeAmt', 'fee', 'facilities', 'blurb', 'about', 'highlights', 'best', 'getThere', 'tip', 'lat', 'lng']));
    $form['blurb'] = 'Edited by the self-test.';
    $r = post('/api/admin/destination-save.php', $form, $admin);
    $pubSeed = array_values(array_filter(post('/api/destinations.php', [], $anon)['json']['places'] ?? [], fn($p) => $p['id'] === $seeded['id']))[0] ?? [];
    check('editing a destination in the admin keeps its stored visit length', ($r['json']['ok'] ?? false) && ($pubSeed['stay'] ?? null) === $seeded['stay'] && $pubSeed['blurb'] === 'Edited by the self-test.', $r['body']);
}
check('no destination carries sample weather (admin list)', !array_filter($list, fn($d) => array_key_exists('weather', $d)));
check('the destination data file is still valid JSON after writes', is_array(json_decode((string)file_get_contents($tmp . '/data/destinations.json'), true)));

// ---- 5. photo upload ----
$png = 'data:image/png;base64,' . base64_encode(base64_decode('iVBORw0KGgoAAAANSUhEUgAAAAgAAAAGCAYAAADQ5d+PAAAAJ0lEQVR4nGP8z8Dwn4EIwESMolGFxCs8Pn7+f2KsZGCgP0ymoYB4RQBe5g8JeGfcigAAAABJRU5ErkJggg=='));
$withPhoto = $upd; $withPhoto['photo'] = $png;
$r = post('/api/admin/destination-save.php', $withPhoto, $admin);
check('upload a real PNG photo', ($r['json']['ok'] ?? false) === true, $r['body']);
$img1 = $r['json']['destination']['image'] ?? null;
check('photo URL is versioned and the file exists', is_string($img1) && str_contains($img1, '?v=') && is_file($tmp . '/' . explode('?', $img1)[0]), (string)$img1);
$pub = array_values(array_filter(post('/api/destinations.php', [], $anon)['json']['places'] ?? [], fn($p) => $p['name'] === 'Selftest Cove'));
check('public site returns the same photo URL', ($pub[0]['image'] ?? null) === $img1);
foreach ([['text/plain', "<?php echo 'x';"], ['image/png', "GIF89a<?php system('id'); ?>"], ['image/jpeg', 'not an image at all']] as [$mime, $bytes]) {
    $evil = $upd; $evil['photo'] = "data:$mime;base64," . base64_encode($bytes);
    $r = post('/api/admin/destination-save.php', $evil, $admin);
    check("fake photo ($mime, " . substr($bytes, 0, 12) . '...) is rejected', ($r['json']['ok'] ?? true) === false, $r['body']);
}
$r = post('/api/destinations.php', [], $anon);
$pub = array_values(array_filter($r['json']['places'] ?? [], fn($p) => $p['name'] === 'Selftest Cove'));
check('a rejected upload leaves the existing photo untouched', ($pub[0]['image'] ?? null) === $img1);
$exe = glob($tmp . '/images/places/*.{php,phtml,html,js}', GLOB_BRACE) ?: [];
check('no executable file was written into images/places', count($exe) === 0, implode(',', $exe));
$withPhoto2 = $upd; $withPhoto2['photo'] = $png . '';
$r = post('/api/admin/destination-save.php', $withPhoto2, $admin);
$img2 = $r['json']['destination']['image'] ?? null;
check('replacing the photo changes the version/URL (cache busting)', is_string($img2) && $img2 !== $img1, "$img1 -> $img2");

// ---- 6. categories ----
$r = post('/api/admin/category-save.php', ['label' => 'Selftest Cat', 'icon' => 'bi-star'], $admin);
check('create category', ($r['json']['ok'] ?? false) === true, $r['body']);
$ckey = $r['json']['category']['key'] ?? '';
check('duplicate category rejected', post('/api/admin/category-save.php', ['label' => 'Selftest Cat', 'icon' => 'bi-star'], $admin)['status'] === 409);
check('duplicate category rejected, different capitals and spacing', post('/api/admin/category-save.php', ['label' => '  selftest   CAT ', 'icon' => 'bi-star'], $admin)['status'] === 409);
$assign = $upd; $assign['cats'] = [$catKeys[0], $ckey]; unset($assign['photo']);
post('/api/admin/destination-save.php', $assign, $admin);
check('deleting a category still in use is refused without a target', (post('/api/admin/category-delete.php', ['key' => $ckey], $admin)['json']['ok'] ?? true) === false);
$r = post('/api/admin/category-delete.php', ['key' => $ckey, 'move_to' => $catKeys[0]], $admin);
check('deleting with a target moves destinations', ($r['json']['ok'] ?? false) === true, $r['body']);
$r = post('/api/admin/category-save.php', ['label' => 'Unused', 'icon' => 'bi-x'], $admin);
check('an unused category deletes cleanly', (post('/api/admin/category-delete.php', ['key' => $r['json']['category']['key'] ?? ''], $admin)['json']['ok'] ?? false) === true);

// ---- 7. weather (works with or without an OpenWeather key) ----
$w = post('/api/weather.php', [], $user);
check('weather endpoint answers a signed-in user with ok:true or a clear message (never a crash)', isset($w['json']['ok']) && ($w['json']['ok'] === true || is_string($w['json']['message'] ?? null)), $w['body']);
$sv = post('/api/admin/destination-save.php', $upd, $admin);
check('saving a destination works whether or not the weather service is reachable', ($sv['json']['ok'] ?? false) === true);

// ---- 8. delete, logout ----
$r = post('/api/admin/destination-delete.php', ['id' => $id], $admin);
check('delete destination', ($r['json']['ok'] ?? false) === true, $r['body']);
$pub = array_values(array_filter(post('/api/destinations.php', [], $anon)['json']['places'] ?? [], fn($p) => $p['name'] === 'Selftest Cove'));
check('deleted destination is gone from the public site', count($pub) === 0);
post('/api/logout.php', [], $admin);
check('after logout the admin session no longer works (401)', post('/api/admin/destinations.php', [], $admin)['status'] === 401);
check('an ordinary user can still log in again', (post('/api/login.php', ['email' => 'user@example.com', 'password' => 'Passw0rd!x'], $other)['json']['ok'] ?? false) === true);

echo "\n$pass passed, $fail failed\n";
echo "(server log: $logFile)\n";
exit($fail ? 1 : 0);
