<?php
// KYR Web Tourism: weather self-test. Command line only.
//
//   php tools/weather-selftest.php
//
// Tests includes/weather.php and api/weather.php against a FAKE OpenWeather server that runs on 127.0.0.1 inside this test.
// It never contacts the real OpenWeather, never uses your real API key (the scratch copy has none) and never touches your data.
// What it proves: nothing is invented, failures show up as "unavailable", failures don't break destinations or the admin,
// the key never reaches the browser, and the number of calls to OpenWeather stays small.
// Needs PHP 8.1+ with the curl extension. Exit code 0 = everything passed.
if (PHP_SAPI !== 'cli') { http_response_code(403); exit('Command line only.'); }
// Environment preflight: a missing PHP extension is a server setup problem, not an application failure. Say so and stop before any test runs.
if (PHP_VERSION_ID < 80100) { fwrite(STDERR, "ENVIRONMENT: PHP 8.1 or newer is required (this is " . PHP_VERSION . "). No tests were run.\n"); exit(2); }
foreach (['json', 'mbstring', 'curl'] as $__ext) if (!extension_loaded($__ext)) { fwrite(STDERR, "ENVIRONMENT: the PHP '$__ext' extension is not enabled, so the tests cannot run. This is not an application failure. Enable it and run again.\n"); exit(2); }

$src = realpath(__DIR__ . '/..');
$tmp = sys_get_temp_dir() . '/kyr-wxtest-' . bin2hex(random_bytes(4));
$pass = 0; $fail = 0; $procs = [];
const TEST_KEY = 'TESTKEY0123456789abcdef0123456789';

function check(string $name, bool $ok, string $extra = ''): void {
    global $pass, $fail;
    if ($ok) { $pass++; echo "PASS  $name\n"; } else { $fail++; echo "FAIL  $name" . ($extra !== '' ? "  [$extra]" : '') . "\n"; }
}
function copy_tree(string $from, string $to): void {
    @mkdir($to, 0777, true);
    foreach (new DirectoryIterator($from) as $f) {
        if ($f->isDot() || $f->getFilename() === '.git') continue;
        $f->isDir() ? copy_tree($f->getPathname(), $to . '/' . $f->getFilename()) : copy($f->getPathname(), $to . '/' . $f->getFilename());
    }
}
function rm_tree(string $dir): void {
    if (!is_dir($dir)) return;
    foreach (new DirectoryIterator($dir) as $f) { if (!$f->isDot()) $f->isDir() ? rm_tree($f->getPathname()) : @unlink($f->getPathname()); }
    @rmdir($dir);
}
$ports = [];
// Stops a server and waits until its port really refuses connections (the built-in server's worker processes can outlive it for a moment).
function stop(string $name): void {
    global $procs, $ports;
    if (!isset($procs[$name])) return;
    proc_terminate($procs[$name]); proc_close($procs[$name]); unset($procs[$name]);
    for ($i = 0; $i < 100 && isset($ports[$name]) && ($c = @fsockopen('127.0.0.1', $ports[$name], $e, $s, 0.1)); $i++) { fclose($c); usleep(100000); }
}
function cleanup(): void { global $procs, $tmp; foreach (array_keys($procs) as $n) stop($n); rm_tree($tmp); }
register_shutdown_function('cleanup');

function serve(string $name, int $port, string $router, array $env = []): void {
    global $procs, $tmp, $ports;
    $ports[$name] = $port;
    $log = sys_get_temp_dir() . '/kyr-wxtest-' . basename($tmp) . '-' . $name . '.log';   // unique per run (a shared fixed name can be unwritable)
    $desc = [1 => ['file', $log, 'w'], 2 => ['file', $log, 'a']];
    $procs[$name] = proc_open([PHP_BINARY, '-S', "127.0.0.1:$port", $router], $desc, $pipes, $tmp, $env + ['PHP_CLI_SERVER_WORKERS' => '4', 'PATH' => getenv('PATH')]);
    for ($i = 0; $i < 60; $i++) { if (@fsockopen('127.0.0.1', $port, $e, $s, 0.2)) return; usleep(100000); }
}

// ---- scratch copy: the code, no data, NO api key, and the OpenWeather address pointed at the fake server ----
copy_tree($src, $tmp);
foreach (glob($tmp . '/data/*') ?: [] as $f) if (basename($f) !== '.htaccess') { is_dir($f) ? rm_tree($f) : @unlink($f); }
foreach (glob($tmp . '/images/places/*') ?: [] as $f) if (is_file($f)) @unlink($f);
@unlink($tmp . '/includes/config.local.php');
$owmPort = random_int(20000, 29999); $appPort = random_int(30000, 39999);
$cfg = file_get_contents($tmp . '/includes/config.php');
$cfg2 = str_replace('https://api.openweathermap.org/data/2.5/weather', "http://127.0.0.1:$owmPort/data/2.5/weather", $cfg);
if ($cfg === $cfg2) { echo "FAIL  could not point the scratch copy at the fake OpenWeather server\n"; exit(1); }
file_put_contents($tmp . '/includes/config.php', $cfg2);

// Fake OpenWeather: mode comes from mock-mode.txt, every request is logged to mock-log.txt (without the key).
file_put_contents($tmp . '/mock-owm.php', <<<'PHP'
<?php
$mode = trim((string)@file_get_contents(__DIR__ . '/mock-mode.txt')) ?: 'ok';
file_put_contents(__DIR__ . '/mock-log.txt', json_encode(['lat' => (float)($_GET['lat'] ?? 0), 'lon' => (float)($_GET['lon'] ?? 0), 'keyOk' => ($_GET['appid'] ?? '') === 'TESTKEY0123456789abcdef0123456789', 'mode' => $mode]) . "\n", FILE_APPEND | LOCK_EX);
if ($mode === '401') { http_response_code(401); echo '{"cod":401,"message":"Invalid API key"}'; return; }
if ($mode === '429') { http_response_code(429); echo '{"cod":429}'; return; }
if ($mode === '500') { http_response_code(500); echo 'oops'; return; }
if ($mode === 'garbage') { echo 'this is not json'; return; }
if ($mode === 'empty') { echo '{"main":{},"weather":[]}'; return; }
usleep(150000);   // a little latency, so parallel requests really overlap
$lat = (float)($_GET['lat'] ?? 0);
echo json_encode(['weather' => [['id' => 802, 'description' => 'scattered clouds', 'icon' => '03d']],
  'main' => ['temp' => 20 + fmod(abs($lat) * 10, 10), 'feels_like' => 25, 'humidity' => 70], 'wind' => ['speed' => 3], 'clouds' => ['all' => 40], 'dt' => time()]);
PHP);
function mock_mode(string $m): void { global $tmp; file_put_contents($tmp . '/mock-mode.txt', $m); }
function mock_calls(): int { global $tmp; return is_file($tmp . '/mock-log.txt') ? count(file($tmp . '/mock-log.txt', FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES)) : 0; }
function mock_log(): array { global $tmp; return array_map(fn($l) => json_decode($l, true), is_file($tmp . '/mock-log.txt') ? file($tmp . '/mock-log.txt', FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES) : []); }
function mock_reset(): void { global $tmp; @unlink($tmp . '/mock-log.txt'); @unlink($tmp . '/data/weather-cache.json'); mock_mode('ok'); }
function cache_file(): array { global $tmp; return json_decode((string)@file_get_contents($tmp . '/data/weather-cache.json'), true) ?: []; }
function cache_put(array $c): void { global $tmp; file_put_contents($tmp . '/data/weather-cache.json', json_encode($c)); }

serve('owm', $owmPort, 'mock-owm.php');
$base = "http://127.0.0.1:$appPort";

function http(string $url, array $body, array &$jar): array {
    $h = "Accept: application/json\r\nContent-Type: application/json\r\n";
    if ($jar) $h .= 'Cookie: ' . implode('; ', array_map(fn($k, $v) => "$k=$v", array_keys($jar), $jar)) . "\r\n";
    $res = @file_get_contents($url, false, stream_context_create(['http' => ['method' => 'POST', 'ignore_errors' => true, 'header' => $h, 'content' => json_encode($body), 'timeout' => 60]]));
    $status = 0;
    foreach ($http_response_header ?? [] as $x) {
        if (preg_match('#^HTTP/\S+\s+(\d+)#', $x, $m)) $status = (int)$m[1];
        if (stripos($x, 'Set-Cookie:') === 0 && preg_match('/Set-Cookie:\s*([^=]+)=([^;]*)/i', $x, $m)) { if ($m[2] === 'deleted' || $m[2] === '') unset($jar[$m[1]]); else $jar[$m[1]] = $m[2]; }
    }
    return ['status' => $status, 'body' => (string)$res, 'json' => json_decode((string)$res, true)];
}
function post(string $path, array $body, array &$jar): array { global $base; return http($base . $path, $body, $jar); }

// An admin and an ordinary visitor (the admin is created the same way tools/make-admin.php does it).
function start_app(?string $key): void {
    global $appPort, $base;
    stop('app');
    $appPort++; $base = "http://127.0.0.1:$appPort";   // a fresh port each time, so a lingering old server can never answer for the new one
    serve('app', $appPort, 'router.php', $key === null ? [] : ['OPENWEATHER_API_KEY' => $key]);
}
$user = []; $admin = []; $anon = [];
start_app(null);
post('/api/destinations.php', [], $anon);   // seeds the 11 destinations
require $tmp . '/includes/config.php'; require $tmp . '/includes/response.php'; require $tmp . '/includes/db.php';
db_insert(['id' => 'wxtestadmin00001', 'first_name' => 'Wx', 'last_name' => 'Admin', 'email' => 'admin@example.com',
           'password' => password_hash('Passw0rd!x', PASSWORD_DEFAULT), 'theme' => 'light', 'prefs' => null, 'recent' => [], 'role' => 'admin', 'created' => date('c')]);
post('/api/register.php', ['first_name' => 'Test', 'last_name' => 'User', 'email' => 'user@example.com', 'password' => 'Passw0rd!x'], $user);
post('/api/admin/login.php', ['email' => 'admin@example.com', 'password' => 'Passw0rd!x'], $admin);
$places = post('/api/destinations.php', [], $anon)['json']['places'] ?? [];
$N = count($places) + 1;   // every destination + the Tacloban header badge

function weather(array &$jar): array { return post('/api/weather.php', [], $jar); }
function admin_form(array $d, array $over = []): array {
    return $over + array_intersect_key($d, array_flip(['id', 'name', 'town', 'area', 'view', 'hours', 'cats', 'time', 'feeAmt', 'fee', 'facilities', 'blurb', 'about', 'highlights', 'best', 'getThere', 'tip', 'lat', 'lng']));
}

// ---- 1. no API key ----
mock_reset();
$r = weather($user);
check('no key: the endpoint says weather is unavailable (503) and explains why', $r['status'] === 503 && ($r['json']['ok'] ?? true) === false && str_contains($r['json']['message'] ?? '', 'not set up'), $r['body']);
check('no key: no request is sent to OpenWeather', mock_calls() === 0);
check('no key: no weather values are made up', !isset($r['json']['weather']));
check('no key: destination browsing still works', count(post('/api/destinations.php', [], $anon)['json']['places'] ?? []) === count($places));
check('no key: the admin list still works', count(post('/api/admin/destinations.php', [], $admin)['json']['destinations'] ?? []) === count($places));
check('anonymous visitors cannot read weather (401)', weather($anon)['status'] === 401);

// ---- 2. working key: real readings, cached ----
start_app(TEST_KEY); mock_reset();
$r = weather($user);
$w = $r['json']['weather'] ?? [];
check('key set: one reading per place plus Tacloban', ($r['json']['ok'] ?? false) === true && count($w) === $N, 'got ' . count($w) . ' of ' . $N . ' ' . substr($r['body'], 0, 120));
check('key set: exactly one OpenWeather request per place', mock_calls() === $N, (string)mock_calls());
check('key set: every request carried the key (it stays on the server)', !in_array(false, array_column(mock_log(), 'keyOk'), true));
check('the API key never appears in the response', !str_contains($r['body'], TEST_KEY) && !str_contains($r['body'], 'appid'));
check('readings are exactly what OpenWeather said (condition 802, 3 m/s = 11 km/h, 40% cloud)', ($w['Tacloban City']['id'] ?? 0) === 802 && ($w['Tacloban City']['windKph'] ?? 0) === 11 && ($w['Tacloban City']['clouds'] ?? 0) === 40);
check('readings carry the observation time OpenWeather gave', abs(($w['Tacloban City']['observed'] ?? 0) - time()) < 30);
check('internal bookkeeping (coordinates, fetch time) is not sent to the browser', !isset($w['Tacloban City']['lat']) && !isset($w['Tacloban City']['fetched']));
weather($user); weather($admin); weather($user);
check('more visitors inside the cache window cost no extra requests', mock_calls() === $N, (string)mock_calls());
check('the cache file is not web-readable', ($c = @file_get_contents("$base/data/weather-cache.json")) === false || !str_contains((string)$c, 'tempC'));

// ---- 3. admin edits do not waste requests ----
$d = post('/api/admin/destinations.php', [], $admin)['json']['destinations'][0];
$before = mock_calls();
$r = post('/api/admin/destination-save.php', admin_form($d, ['blurb' => 'Only the description changed.']), $admin);
weather($user);
check('editing text in the admin costs no weather requests', ($r['json']['ok'] ?? false) && mock_calls() === $before, (string)(mock_calls() - $before));
$r = post('/api/admin/destination-save.php', admin_form($d, ['lat' => $d['lat'] + 0.05]), $admin);
$w2 = weather($user)['json']['weather'] ?? [];
check('moving a destination fetches just that place again (1 request)', ($r['json']['ok'] ?? false) && mock_calls() === $before + 1, (string)(mock_calls() - $before));
$lastReq = mock_log()[count(mock_log()) - 1] ?? [];
check('the request used the new coordinates', abs(($lastReq['lat'] ?? 0) - ($d['lat'] + 0.05)) < 1e-9 && isset($w2[$d['name']]), json_encode($lastReq));
$new = $d['name'] . ' Renamed';
$before = mock_calls();
post('/api/admin/destination-save.php', admin_form($d, ['name' => $new, 'lat' => $d['lat'] + 0.05]), $admin);
$w3 = weather($user)['json']['weather'] ?? [];
check('renaming a destination fetches just that place (1 request) and the old name disappears', mock_calls() === $before + 1 && isset($w3[$new]) && !isset($w3[$d['name']]), (string)(mock_calls() - $before));

// ---- 4. places without usable coordinates get no reading and no request ----
mock_reset();
$nocoord = ['name' => 'Nowhere Test', 'town' => 'Palo', 'blurb' => 'x', 'about' => 'x', 'hours' => '8-5', 'feeAmt' => 0, 'area' => 'rural', 'cats' => [post('/api/categories.php', [], $anon)['json']['categories'][0]['key']], 'lat' => 0, 'lng' => 0];
$r = post('/api/admin/destination-save.php', $nocoord, $admin);
$w4 = weather($user)['json']['weather'] ?? [];
check('coordinates 0,0 ("not entered"): the place is saved, but has no weather and no request is made for it', ($r['json']['ok'] ?? false) && !isset($w4['Nowhere Test']) && mock_calls() === $N, (string)mock_calls());

// ---- 5. OpenWeather rejects the key / rate limit / outage ----
foreach ([['401', 'rejected the API key', 'key rejected'], ['429', 'busy', 'rate limited'], ['500', 'not reachable', 'server error'], ['garbage', 'not reachable', 'unreadable answer'], ['empty', 'not reachable', 'answer without a temperature']] as [$mode, $words, $label]) {
    mock_reset(); mock_mode($mode);
    $r = weather($user);
    check("$label, nothing cached: clear 'unavailable' message, no readings", ($r['json']['ok'] ?? true) === false && str_contains($r['json']['message'] ?? '', $words) && !isset($r['json']['weather']), $r['body']);
    $calls = mock_calls();
    weather($user); weather($user); weather($admin);
    check("$label: repeated page views do not hammer OpenWeather (backoff)", mock_calls() === $calls, (string)(mock_calls() - $calls));
    check("$label: the key is not in the message", !str_contains($r['body'], TEST_KEY));
    check("$label: destination browsing and admin saving still work", count(post('/api/destinations.php', [], $anon)['json']['places'] ?? []) >= 11
        && (post('/api/admin/destination-save.php', admin_form($d, ['blurb' => 'Saved while weather is down.']), $admin)['json']['ok'] ?? false) === true);
}

// ---- 6. recovery after a failure ----
mock_reset(); mock_mode('500'); weather($user);
$c = cache_file(); $c['retry']['until'] = time() - 1; cache_put($c);   // pretend the waiting time has passed
mock_mode('ok');
$r = weather($user);
check('after the waiting time, a working service gives real readings again', ($r['json']['ok'] ?? false) === true && count($r['json']['weather'] ?? []) >= $N - 1 && ($r['json']['stale'] ?? true) === false, $r['body']);

// ---- 7. an expired cache plus a failing service: recent readings are kept, and labelled ----
mock_reset(); weather($user);
$c = cache_file(); foreach ($c['data'] as &$e) $e['fetched'] -= 3600; unset($e); cache_put($c);   // fetched an hour ago, observed an hour ago too
foreach ($c['data'] as &$e) $e['observed'] -= 3600; unset($e); cache_put($c);
mock_mode('500');
$r = weather($user);
check('service down, readings from an hour ago: they are still sent but flagged stale with a reason', ($r['json']['ok'] ?? false) === true && ($r['json']['stale'] ?? false) === true && is_string($r['json']['notice'] ?? null) && count($r['json']['weather'] ?? []) >= $N - 1, $r['body']);
$c = cache_file(); foreach ($c['data'] as &$e) { $e['fetched'] -= 20000; $e['observed'] -= 20000; } unset($e); $c['retry']['until'] = time() - 1; cache_put($c);
$r = weather($user);
check('service down, readings older than 3 hours: weather is reported unavailable, not shown as current', ($r['json']['ok'] ?? true) === false, $r['body']);

// ---- 8. the fake service is not running at all (connection refused) ----
stop('owm'); mock_reset();
$r = weather($user);
check('OpenWeather unreachable: clean "unavailable" answer, not a crash', ($r['json']['ok'] ?? true) === false && is_string($r['json']['message'] ?? null) && $r['status'] === 502, $r['status'] . ' ' . $r['body']);
check('OpenWeather unreachable: the rest of the site is fine', ($admin_list = post('/api/admin/destinations.php', [], $admin))['status'] === 200 && ($admin_list['json']['ok'] ?? false));
serve('owm', $owmPort, 'mock-owm.php');

// ---- 9. many visitors at once cost one set of requests ----
mock_reset();
$mh = curl_multi_init(); $hs = [];
$cookie = implode('; ', array_map(fn($k, $v) => "$k=$v", array_keys($user), $user));
for ($i = 0; $i < 6; $i++) {
    $ch = curl_init("$base/api/weather.php");
    curl_setopt_array($ch, [CURLOPT_POST => true, CURLOPT_POSTFIELDS => '{}', CURLOPT_RETURNTRANSFER => true, CURLOPT_HTTPHEADER => ['Content-Type: application/json'], CURLOPT_COOKIE => $cookie, CURLOPT_TIMEOUT => 60]);
    curl_multi_add_handle($mh, $ch); $hs[] = $ch;
}
do { curl_multi_exec($mh, $act); if ($act) curl_multi_select($mh, 0.5); } while ($act);
$oks = 0; foreach ($hs as $ch) { $j = json_decode((string)curl_multi_getcontent($ch), true); if (($j['ok'] ?? false) && count($j['weather'] ?? []) >= $N - 1) $oks++; }
check('6 simultaneous visitors on an empty cache: all get readings', $oks === 6, "$oks of 6");
check('6 simultaneous visitors on an empty cache: only one set of requests goes to OpenWeather', mock_calls() === $N, (string)mock_calls());

// ---- 10. the old cache format is understood, never trusted blindly ----
mock_reset();
cache_put(['time' => time(), 'data' => ['Tacloban City' => ['tempC' => 99, 'feelsC' => 99, 'humidity' => 1, 'windKph' => 1, 'rainMm' => 0, 'clouds' => 0, 'id' => 800, 'desc' => 'Old', 'night' => false, 'observed' => time()]]]);
$r = weather($user);
check('an old-format cache entry (no coordinates on record) is refreshed instead of being shown', ($r['json']['weather']['Tacloban City']['tempC'] ?? 99) !== 99, $r['body']);

echo "\n$pass passed, $fail failed\n";
exit($fail ? 1 : 0);
