# User UI refinement (theme + weather), corrected

Admin UI, admin functions, destination CRUD, login/registration, recommendations and routing are unchanged.

## Theme
- The user-facing selector offers only **Light Mode** and **Dark Mode** (dashboard menu and the floating switcher on login, register, forgot-password, terms, privacy).
- One saved choice (`localStorage` key `leyteTheme`, also saved on the account) applies on every public page, the admin console and across visits.
- A browser with no saved choice starts in the device's theme once (nothing is saved until the person picks one). Older saved `system` / `auto` values are converted once to the theme they were showing.
- Server: `THEMES` is `light | dark`, the default is `light`; an old account value of `system`/`auto` is returned as `null`, so the browser keeps its own theme.

## Weather
- **Check weather is kept.** The dashboard tile and the "Weather at every spot" popup (all destinations grouped by town, a Refresh button, click a row to open that destination) are restored from the previous implementation, with all of their JavaScript. Both share the same live OpenWeather data (`api/weather.php`, `js/weather.js`); no sample readings anywhere.
- The popup no longer has the gold/violet gradient bar: it is in the same border/radius rule as the Preferences, Manage profile, Log out, Clear history and destination popups (`css/style.css`), with the same background, padding and shadow in light and dark.
- The popup now shows "Loading weather…" while the first request runs, a plain-language reason with Refresh when the service fails, "No data" for a spot with no reading, and a footer that says when readings are older. Focus returns to Refresh after it runs, so Esc still closes the popup.
- The destination profile keeps its weather box, now a flat panel (no gradient) with the same states (loading, error with reason, no reading, old reading, "Try again").
- Unchanged: the header weather badge, card temperature chips and the weather-aware recommendation ranking.

## Changed files
- Theme: `js/theme.js`, `js/theme-init.js`, `css/theme.css`, `includes/config.php`, `includes/auth.php`, `api/theme.php`
- Weather and dashboard: `dashboard.html`, `js/dashboard.js`, `js/weather.js`, `css/dashboard.css`, `css/style.css`
- Tests: `tools/selftest.php`, `tools/weather-selftest.php` (expect Light/Dark only)
- Docs: `CHANGES-USER-UI.md` (this file)
