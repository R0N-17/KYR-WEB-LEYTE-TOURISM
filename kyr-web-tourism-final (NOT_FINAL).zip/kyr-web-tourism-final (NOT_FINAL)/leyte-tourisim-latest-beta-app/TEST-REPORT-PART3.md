# Part 3 test report

**Environment limits (read first).** The test machine had **no PHP** (no `php` binary, no network to install one). So nothing written in PHP was executed:
`php -l`, `tools/selftest.php`, `tools/weather-selftest.php`, and every real server response (sessions, 401/403, file writes, uploads, OpenWeather) are **Not Run**.
The browser tests below ran in real Chromium (Playwright) against the real project files, but the PHP API was **simulated** (fixed JSON answers, built from the real `data/*.json`). They prove the front-end behaviour, not the PHP.

## Passed (ran and succeeded)
| Test | Evidence |
|---|---|
| SCRUM-15 one preference -> matches first | Beaches picked: Kalanggaman Island, Cuatro Islas first |
| SCRUM-15 several preferences | History + Landmarks: top results all History/Landmark places |
| SCRUM-15 unselect one, others remain | History only: its places first, list updated |
| **SCRUM-15 unselect the final preference** | 0 recommendation cards; message "Select at least one preference to see recommendations."; save feedback matches; no "explore" note |
| SCRUM-15 refresh after saving empty selection | Reloaded page: still 0 cards; also after a forced catalog reload / re-render |
| SCRUM-15 brand-new account, stored empty prefs, prefs naming a deleted category | all show 0 cards + message |
| SCRUM-15 selected but no match | Category with no destinations: "No matching destinations", 0 cards; message differs from the no-selection one |
| SCRUM-15 budget / setting only | Free budget: only free places; Rural + Free: no-match state (not "everything") |
| SCRUM-15 "Set preferences" button | opens the preferences window |
| SCRUM-12 directory | all 12 destinations once, count label, town + blurb on cards, broken photo URL leaves no broken image |
| SCRUM-12 failure / empty | API failure: message + Try again; zero destinations: "No destinations yet"; no JS errors |
| SCRUM-13 filters | every category pill shows exactly its destinations; empty category shows message + reset; clear restores all; switching replaces results |
| SCRUM-14 profiles | correct profile opens; hours, fee, facilities, about shown; a place with every optional field empty shows no "undefined"/"null" |
| Weather popup + profile weather (failure path) | popup opens, shows the reason, no temperatures; profile shows "Weather unavailable" + Try again |
| Weather popup + profile weather (service answers) | popup lists readings, profile shows a reading (readings are test data supplied by the simulated API, not live) |
| SCRUM-16 admin UI (simulated backend) | list of 11; empty form blocked with no API call; no category blocked; failed save shows error, keeps modal, no success toast, list unchanged; create -> success + list refreshed; duplicate name rejected; failed delete shows error and keeps the record; delete removes; edit persists; edited records keep `stay`; category list loads |
| Part 1 cleanup (static) | no Estimated visit length / Trip length in admin form; no sample `weather` in `data/destinations.json` or the seed; `stay` present on all 11 records; no "System Default"; Check Weather popup and profile weather present |
| Settings page (Part 2 regression) | all 21 checks re-run and passed (sidebar + active state, Light/Dark apply + persist, account states, 401 redirect, mobile 375px, no JS errors) |
| Theme across pages | Dark set in Settings applies to dashboard, login, register, admin dashboard, admin categories |
| Admin sidebar on other pages | Settings visible, correct active item, no JS errors on Dashboard / Destinations / Categories |
| JavaScript syntax | every file in `js/` and `admin/js/` parses |
| JSON validity + data consistency | 4 JSON files valid; 11 destinations: unique ids and names, all categories exist, areas/views/stay values valid, required fields present, photo file exists |
| PHP bracket balance (weak check) | all 36 PHP files: brackets balance and no lexer errors (Pygments). **This is not a syntax check.** |

## Failed
None in the tests that ran. (Earlier runs in this session failed only because of test-script mistakes; they were corrected and are not application defects.)

## Not Run (need PHP) and follow-up
| Test | Why | Follow-up |
|---|---|---|
| `php -l` on all PHP files | no PHP | run `for f in $(find . -name '*.php' -not -path './vendor/*'); do php -l $f; done` |
| `php tools/selftest.php` | no PHP | run it; it covers login/logout, 401/403 on every admin endpoint (now including `admin/me.php`), CRUD + photo rules, categories, theme, session end |
| `php tools/weather-selftest.php` | no PHP | run it (needs curl) |
| Authentication, authorization and session behaviour on the real server | no PHP | the code was read: every `api/admin/*` endpoint except `login.php` calls `auth_require_admin()` (401 signed out / 403 non-admin); public responses return no password hash; JSON-only POST rule. Not executed. |
| Real CRUD persistence, duplicate rules, `stay` preservation, photo upload on the server | no PHP | covered by `selftest.php` |
| Persistence of an **empty** preference selection on the server | no PHP | the code path (`api/preferences.php` stores the empty object, `api/me.php` returns it) was read and the browser handles it; run the app once: clear all preferences, save, refresh |
| Live OpenWeather | no network, and the project key was removed from the package | add your own key and open Check Weather |
| mbstring / log-permission root causes | cannot reproduce without PHP | mbstring: inferred from the code (it calls `mb_*`); the log error: the fixed shared log path was the only candidate in the code. Both now handled; confirm on your machine. |

## Known limitations
- Registration/login lack rate limiting and CSRF tokens (documented earlier in FINAL-REVIEW.md); fine for a school project, add before public hosting.
- If the first `admin/me.php` request fails with a network error the admin page stays blank (pre-existing).
- The preferences window does not close on Escape right after pressing Save (button loses focus); the Close/Cancel buttons work.
