# Final review: Sprint 2 validation, admin dashboard/form refinements, automatic weather, light/dark mode

Read together with `SPRINT2.md`, `ADMIN-MODULE.md` and `ADMIN-REDESIGN.md`. SCRUM-17 (history) is intentionally NOT built.

## What was reviewed and what was found
I read the real code (PHP, JS, CSS, data files) instead of trusting earlier summaries. Genuine findings:
1. **Sample weather was still manual and could be shown as if real.** The admin form had "sample condition / temperature / tip" fields and the public popup fell back to them when live weather was off. Fixed (see Weather).
2. **Visit time / trip length were required on every destination** although they describe the place, not the visitor. Now optional (see Form).
3. **Dashboard numbers:** towns were counted from raw text ("Palo" and " palo " were two towns); "Recently updated" always said "updated" even for places never edited; shortcuts were redundant. Fixed (see Dashboard).
4. **Theme:** the public site had Light/Dark/Auto but defaulted to Light (ignoring the device), the admin had no dark mode, and logging in could overwrite a theme chosen on this browser. Fixed (see Theme).
5. **Rough-sea warning** only recognised the exact category key `beach`. It now also recognises any category whose label names the sea (beach, island, coast, bay...). Renaming categories never changes keys, so nothing else depends on them.
6. **Security review (PHP read-through, no serious flaw found).** Every admin endpoint calls `auth_require_admin()` on the server; JSON-only requests block cross-site form posts; sessions are regenerated on login and destroyed on logout; passwords use `password_hash`; the admin sign-in gives one message for wrong password and non-admin; registration ignores any `role` field; uploads are checked by content (finfo/getimagesize), type, size and pixel limits and stored under generated names; `data/`, `includes/` and `tools/` are blocked by `router.php` and `.htaccess`. Small hardening added: `X-Content-Type-Options: nosniff` on API responses and the session cookie's `Secure` flag when served over HTTPS. Not addressed: no login rate limiting beyond a 0.4 s delay, and no CSRF token (the JSON-only rule and SameSite=Lax cookie are the protection). Fine for a school project; add both before public hosting.

## Changes
### Weather (automatic, never typed in)
- `includes/destinations.php`, `includes/config.php`: the manual weather block and `DEST_CONDITIONS` are gone; saving a destination drops any old `weather` key from that record. Existing data files are not rewritten until a destination is saved.
- Weather still comes only from `includes/weather.php` / `api/weather.php` (OpenWeather, key server-side, 10-minute cache, per-destination coordinates).
- Public popup (`js/dashboard.js`, `js/weather.js`): live reading, or "Weather unavailable" with the reason. No invented fallback. A reading over 3 hours old is shown labelled "Older reading" and is not used for chips or advice. A destination without coordinates has no weather (never another place's).
- Admin form: read-only "Live weather" preview for the destination being edited; if OpenWeather fails the preview says so and saving still works. Admin dashboard: a small weather status chip.
### Destination form
Sections: Basic information, Location (with coordinates and the weather preview), Categories (with `+ New category`), Visitor information (fee, hours, best time to visit, facilities), **Visiting guidance (optional)**: suggested time of day and estimated visit length of the *place*, plus sunrise/sunset spot, and Destination details and tips, Photo. The user's own preferred time of day and trip length stay in the visitor's preferences (sign-up and Preferences), not in destination data. The recommender still uses the optional guidance when present; places without it just get no bonus for it.
### Admin dashboard
Header: "Dashboard", subtitle, your name, weather chip, **Add destination**. Cards: Total destinations, Towns and cities (distinct, case/space-insensitive, blanks ignored), With photos, Missing photos (the photo cards link to the filtered list). Destinations by category (compact bars; overlap noted). Recently updated with thumbnails, "Added" vs "Updated" and the real saved timestamp (hover for time), Manage all. **Needs attention** replaces the shortcut tiles: no photo, missing/invalid coordinates, no valid category, missing required details, each linking to the Destinations list with the matching "data check" filter (new select next to the category filter). Dashboard and list use the same rules (`Admin.issues` in `admin/js/admin.js`).
### Light / dark mode
- One shared implementation: `js/theme-init.js` (runs in `<head>`, no flash) and `js/theme.js`, loaded on every public AND admin page. Modes: Light, Dark, System (default), Auto (light 6 AM to 6 PM).
- No saved choice = follow the device (`prefers-color-scheme`), live. An explicit choice wins over the device, is stored in `localStorage` key `leyteTheme` (shared by public and admin, even across tabs) and, when signed in, also saved on the account via `api/theme.php` (which now accepts `system`; new accounts default to `system`).
- Admin: sun/moon button in the top bar and on the admin sign-in page (moon shown in dark, sun in light, accessible label "Switch to dark/light mode"). Public: the existing theme menu (now with System) and floating switcher.
- Login/logout never reset a choice made in this browser; the account's theme is only used by a browser with no choice of its own.
- Palette: light keeps the navy/blue/white look; dark is a deliberate navy palette (`#0B1220` page, `#121B2E` surfaces, light text, softened accents), not an inversion. Admin colours are CSS variables in `admin/css/admin.css`; Bootstrap's own `data-bs-theme` handles its components.
- Contrast measured in a browser (see tests): no checked text pair below 4.5:1 in either theme.

## Files changed in this round
PHP: `includes/config.php`, `includes/destinations.php`, `includes/bootstrap.php`. New: `tools/selftest.php`.
Public: `dashboard.html`, `js/dashboard.js`, `js/data.js`, `js/weather.js`, `js/login.js`, `js/theme.js`, `js/theme-init.js`, `css/theme.css`.
Admin: `admin/index.html`, `admin/destinations.html`, `admin/categories.html`, `admin/login.html`, `admin/js/admin.js`, `admin/js/dashboard.js`, `admin/js/destinations.js`, `admin/css/admin.css`, `admin/css/login.css`.
Docs: `README.txt`, `ADMIN-REDESIGN.md`, `FINAL-REVIEW.md`.

## Setup
`php -S localhost:8000 router.php` as before. Weather needs your OpenWeather key (README.txt). Back up `data/` and `images/places/` before upgrading (copy the folders); no data migration is needed. Hard-refresh once (Ctrl+F5).

## RUN THIS ON YOUR MACHINE: real PHP integration test
```
php tools/selftest.php
```
It copies the project to a temp folder with empty data (your real data is untouched), starts PHP's built-in server there and checks the real endpoints over HTTP: seeding, public reads (no manual weather), registration (cannot become admin), 401/403 on every admin endpoint, admin login (wrong password, non-admin), destination create/update/delete with optional guidance, photo upload, fake/script uploads rejected, existing photo kept after a rejected upload, version change on replacement, category duplicates (also different capitals/spacing), delete-with-move, weather endpoint with or without a key, logout invalidating the session. **I could not run it myself (no PHP in my environment), so treat its first run as a test of the test too.** If a check fails, send me the FAIL line.

## Test report
Legend: **STATIC** syntax only. **STAND-IN** real Chromium against a Node stand-in that mimics the PHP JSON (reads your real data files, does not run any PHP). **REAL PHP** not possible here.
| Area | Result |
|---|---|
| `node --check` on every JS file | PASSED (STATIC) |
| PHP syntax | NOT RUN: no PHP here. Only a rough bracket-balance scan of all 35 PHP files passed (that is NOT `php -l`). Run `php -l` on each file yourself. |
| Admin: dashboard data, Needs attention counts and links, filters, weather chip states, form without weather fields, optional guidance, live preview states, save request carries no weather | PASSED (STAND-IN) |
| Theme: first visit with OS light and OS dark (public, admin, admin login), toggle by mouse/Enter/Space, persistence across refresh and across admin/public pages, choice beats the OS, live OS change, login/logout keep the choice, System/Auto menu on the public site | PASSED (STAND-IN) |
| Light + dark screenshots reviewed and contrast measured on admin dashboard, destinations, form, delete modal, categories, category modal, login | PASSED (STAND-IN), 0 pairs below 4.5:1 |
| Public site in both themes: dashboard, directory, details popup (live / unavailable / older reading), preferences, register | PASSED (STAND-IN) |
| Responsive: no horizontal overflow on all three admin pages at 1440, 820, 390 px in light and dark; modal at 150/200/300% zoom | PASSED (STAND-IN) |
| Earlier suites re-run: Sprint 2 public features (43), admin redesign (78), admin modal (27), register/login/forgot-password | PASSED (STAND-IN) |
| Admin login/logout, 401/403, CRUD persistence, uploads, categories, file locking, real OpenWeather calls, registration | NOT TESTED (needs REAL PHP): run `php tools/selftest.php` and the checklists in `ADMIN-MODULE.md` |
| Safari, Firefox, real phones | NOT TESTED (Chromium only) |

## Known limitations
- Nothing here has run on real PHP. The code changes in PHP are small (listed above) and were checked by reading and a bracket scan only.
- Existing accounts that saved the old default "Light" keep Light on a browser with no choice; only new accounts default to System.
- Stats on the PHP side (`api/admin/stats.php`) still counts towns the old way; the dashboard no longer uses that number (it counts from the destination list).
- Weather sample fields remain inside the seed file and in old records until each destination is next saved; nothing reads them.
- No login rate limit and no CSRF token (see Security).
