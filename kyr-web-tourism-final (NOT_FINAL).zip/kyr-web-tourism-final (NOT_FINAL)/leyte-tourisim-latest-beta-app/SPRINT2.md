# Sprint 2: SCRUM-12, 13, 14, 15, 16 (status, setup, testing)

Stack unchanged: PHP + file storage (`data/*.json`, `data/users.txt`), Bootstrap 5, PHP sessions. No Supabase, MySQL or framework.

## What was already in this project, and what Sprint 2 added

The project you uploaded already contained the **SCRUM-16 admin module** (admin login, destination CRUD, photo upload, managed categories, `+ New category`, scrolling modal, seed/migration, locking and atomic writes). It is described in `ADMIN-MODULE.md`. I reviewed it end to end and **did not change any PHP file**.

What was missing was the **public side** of SCRUM-12/13/14/15. Before this change the "Browse destinations" card said *Coming soon*, there was no category filter, the details popup left out trip length / setting / time of day, and recommendations had no real fallback. Those are now done:

| Issue | What it does now |
|---|---|
| SCRUM-12 Browse directory | New **Destinations** page (sidebar link and the "Browse destinations" card). Cards show photo, name, town, short description and category chips. Loading, error (with **Try again**) and empty states. Data comes only from `api/destinations.php`, so a destination the admin adds shows up with no frontend edits. The page refetches when you open it, so admin changes appear without logging out. |
| SCRUM-13 Category filter | Filter pills = **All** plus every managed category (from `api/categories.php`), each with a count. A place with several categories appears under each. "Show all" returns to everything. A category with no places shows an empty state with a way back. Removed categories fall back to **All** instead of a blank list. The registration questionnaire, preferences form, filters and recommendations all read the same managed list (`data/categories.json`). |
| SCRUM-14 Details | Popup now also shows setting, best time of day and trip length (plus everything it already showed). Any optional field that is empty (description, highlights, facilities, best time, directions, tip) is hidden instead of rendering blank. |
| SCRUM-15 Recommendations | Places in a saved category always rank first (budget-fitting ones first among them), then other places fill the list. Duplicates removed (by id). Stale saved categories (deleted/renamed away) are ignored and dropped on the next save. **No preferences** shows general suggestions and a "Set preferences" prompt. **Preferences match nothing** says so and shows general suggestions. No destinations / load error have their own states. A note under the heading says why the list looks the way it does. |
| Photos everywhere | Every card, search result, popup and recommendation uses the single `image` URL from the server (`?v=` changes on replacement). Cards are redrawn when the image changes, so a replaced photo shows on the next refetch or reload. |

### Files changed in this session (all paths relative to the project root)
- `dashboard.html` (Destinations page, sidebar link, enabled quick card, details rows, recommendation note)
- `js/dashboard.js` (directory + filter, refresh, recommendations, details, preference cleaning)
- `js/data.js` (records load errors so screens can show them)
- `css/dashboard.css` (directory and filter styles, light and dark)
- `SPRINT2.md` (this file)

Everything else (all PHP, `admin/*`, `register.*`, `login.*`, `weather.*`, data files) is byte-for-byte what you uploaded. Your existing `data/users.txt`, `data/destinations.json`, `data/categories.json` and `images/places/` are included unchanged.

## Setup and migration

1. `php -S localhost:8000 router.php` in the project folder (PHP 8.1+ recommended).
2. Migration is automatic and safe to rerun: `data/destinations.json` and `data/categories.json` are created from the seed files **only if missing**; existing records are never overwritten. Existing user preferences keep working because category keys never change on rename, and deleting a category migrates users' preferences.
3. Admin: `php tools/make-admin.php promote you@example.com` (or `create`), then open `/admin/login.html`.
4. `data/` and `images/places/` must be writable by PHP.

## Tests actually performed

**Important limit: PHP is not installed in the environment I worked in and I had no network, so I could not run the PHP backend at all.** No `php -l`, no endpoint, upload, login or file-locking test was run by me.

Performed (real headless Chromium):
- The new public screens were run against a small throw-away Node stand-in for the public API endpoints. It served your real `data/destinations.json`, `data/categories.json` and `data/users.txt` (from a scratch copy) in the same JSON shapes as the PHP. **43/43 checks passed**: directory count and card contents; every filter, multi-category places, counts, show-all, empty category; details content; missing optional fields; replaced photo showing in directory, recommendations, search and popup; admin-added category and destination appearing publicly; stale saved category; no preferences; preferences matching nothing; load error and retry; no destinations; no phone horizontal overflow at 375 px; no JS console errors.
- The admin Add/Edit modal (served by the same stand-in, which answers only the three read endpoints the page needs): the body scrolls to the very bottom, header and Save/Cancel stay visible, photo input reachable, `+ New category` opens inside the form, at 1280x600, 1366x500 and 375x667. 24/24 checks passed. The admin sign-in page renders styled, and signed-out / ordinary-user visits are redirected by the page logic.
- `register.html`, `login.html`, `forgot-password.html` load with no JS errors, and the questionnaire builds its category cards from the server list.
- `node --check` on every JS file: all pass.

**Not performed (needs you, with PHP running):** PHP syntax checks; admin login against real sessions; real 401/403 from `api/admin/*`; create/edit/delete persistence; real image upload, replacement, rejection of bad files and cache behavior; category create/rename/delete/reassign against the real files; logout invalidating the admin session; registration/login/profile round trips; live weather. The existing checklist in `ADMIN-MODULE.md` covers these. Please also run:

- [ ] `php -l` on every `.php` file (nothing was edited, but it has never been run by me).
- [ ] Sign in as a normal user: Destinations page lists all places, filters work, details popup is complete.
- [ ] In the admin: replace a photo, then reload the public dashboard: new photo on the card, directory, popup, recommendations.
- [ ] Admin: add a category via `+ New category` while adding a destination; it appears as a filter pill, in the sign-up questionnaire and in Preferences.
- [ ] Admin: rename a category: label changes everywhere, users keep their picks. Delete one that is in use: you must pick a target; users' saved picks move too.
- [ ] Sign out of the admin, press Back: protected pages redirect to the sign-in page; `fetch('api/admin/destinations.php',{method:'POST',headers:{'Content-Type':'application/json'},body:'{}'})` returns 401.

## Remaining limitations
- Not tested by me against PHP (see above). I will not call Sprint 2 complete until the checklist passes on your machine.
- The directory refetches when you open it or return to the tab; a page left open does not update on its own.
- "Recently viewed" stores place names, so renaming a place drops it from that list (existing behavior).
- The rough-sea warning in `js/weather.js` still looks for the category key `beach` (existing limit).
- Category keys made only of digits (e.g. a category named "2024") could behave oddly in PHP array keys; not changed.
- `placeDetailModal` in `dashboard.html` is old unused markup; left alone.
- Uploads accept JPG, PNG, WebP and AVIF (AVIF is an extra); the limit is 3 MB / 8000 px.
