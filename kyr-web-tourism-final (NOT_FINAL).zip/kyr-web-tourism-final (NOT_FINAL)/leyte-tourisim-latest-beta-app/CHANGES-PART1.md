# Part 1: critical changes and cleanup

## 1. Trip Length removed from the admin
- Admin add/edit form, the View popup and the form's validation no longer have "Estimated visit length" (`admin/destinations.html`, `admin/js/destinations.js`, `admin/js/admin.js`, `includes/destinations.php`).
- Trip length stays a personal preference (registration questionnaire + dashboard Preferences; `api/preferences.php`, `PREF_TRIPS`).
- Stored data is not deleted: every existing record keeps its `stay` value, and `dest_update()` carries it over when an admin saves a destination.
- Recommendations still use it (`js/data.js`): a place with no stored visit length is never penalised and shows no "Trip length" chip.

## 2. Sample weather removed
- The hand-typed `weather` block (`condition`, `tempC`, `tip`) is removed from all 11 records in `data/destinations.json` and from `includes/destinations.seed.json`. Nothing else in those files changed. `dest_admin_view()` also strips it if an old file turns up.
- `includes/weather.php` rewritten around the existing OpenWeather call:
  - per-place cache with the coordinates it was fetched for; admin saves that don't touch name/coordinates cost no API calls, and a moved/new/renamed place costs one;
  - invalid coordinates (missing, out of range, 0,0) are skipped;
  - failures (no key, rejected key, rate limit, outage, unreadable answer) are remembered for 60 s / 5 min so page views don't retry every time;
  - only one request at a time refreshes the cache;
  - a reading is accepted only if OpenWeather supplied a temperature, a condition and an observation time;
  - `api/weather.php` always answers with JSON (never a crash) and never includes the key.
- `js/weather.js` / `js/dashboard.js`: shows "Weather unavailable" with the reason, polls only while the tab is visible, and the header badge no longer stays on "Loading…" after a failed answer.

## 3. Redundancy removed (only what was confirmed unused or duplicated)
- `dashboard.html`: the second destination popup `#placeDetailModal` (nothing could open it) and its CSS selectors; the hero "Plan a route" button (same disabled control as the quick card below it).
- `dashboard.html`: the "Check weather" card was a disabled "Coming soon" tile in front of a finished weather popup; it now opens that popup.
- `admin/index.html` + `admin/js/dashboard.js`: the "Missing photos" stat card (the same number is under "Needs attention" and in the list filter). The remaining three cards were re-spaced.
- Unused CSS: `.dm-close`, `.wx-inline`, `.ad-quick*`, `.ad-site-link`, `.ad-nav-btn`.

## Tests
- `php tools/selftest.php` (existing, extended for trip length and sample weather): 67 passed.
- `php tools/weather-selftest.php` (new, fake OpenWeather server): 48 passed.
