# Sprint 3: Route & Weather Planning (SCRUM-17, 18, 19) + Ratings & Reviews (SCRUM-20)

Stack unchanged: PHP + JSON/text files, Bootstrap 5, PHP sessions. No database, no framework, **no API key needed**.
Sprint 4 (SCRUM-21 favourites, SCRUM-22 activity history / admin panel) was **not started**.

## What was built

| Issue | What it does now |
|---|---|
| **SCRUM-17** Point-to-point route | New **Trip Planner** page (top menu, the "Plan a route" quick card, and **Plan a route here** in every destination popup). Pick From (starting points, your current location, or any destination) and To. Shows estimated road distance, travel time, "if you leave now" arrival, whether the place is open then (from its opening hours), a boat-crossing warning for island destinations, the destination's "Getting there" text, a sketch map, and **Open in Google Maps** (real directions and live traffic). |
| **SCRUM-18** Weather advisory | One rule set gives every destination **Good to go / Be careful / Not advised now / No live weather**, with the reasons and what to do (thunderstorm, heavy rain, strong wind at sea, extreme heat). Shown in the destination popup, on the route, in the "Check weather" list, and used by the trip planner. Based on OpenWeather's *current* conditions only (the free plan has no forecast), and the screens say so. |
| **SCRUM-19** Automatic one-day trip | Choose start point, leave/back-by times, day, fee limit and interests (pre-filled from saved preferences) and press **Plan my day**. It picks up to 5 stops, orders them to save driving, respects opening hours and closed days (e.g. closed Mondays), adds a lunch break, skips places that are over budget or unsafe in today's weather, prefers better-rated places, and shows a timeline with arrive/stay/leave times, fees, weather notes, what was left out and why, and one Google Maps link for the whole trip. |
| **SCRUM-20** Ratings & reviews | In every destination popup: average, review count and star breakdown; a 1-5 star rating with optional text (max 1000 characters). One review per visitor per place: posting again edits it; the visitor can delete their own (with confirmation). Other visitors see only "First L.". Cards and recommendations show "★ 4.5 (12)". Deleting an account deletes its reviews; deleting a destination deletes its reviews. |

## Files

New: `js/planner.js` (pure logic), `js/planner-ui.js`, `js/reviews.js`, `includes/reviews.php`, `api/reviews.php`, `api/review-save.php`, `api/review-delete.php`, `tools/planner-selftest.js`, `SPRINT3.md`.
Changed: `dashboard.html`, `js/dashboard.js`, `js/weather.js`, `css/dashboard.css`, `includes/config.php`, `includes/bootstrap.php`, `includes/destinations.php` (`dest_public` now also sends `lat`, `lng`, `ratingAvg`, `ratingCount`; `dest_delete` removes the place's reviews), `api/destinations.php`, `api/delete.php`, `tools/selftest.php` (+20 review checks), `README.txt`, `.gitignore`.
New data file, created on the first review: `data/reviews.json` (private, ignored by git, blocked by `router.php`/`.htaccess` like the other data files). Everything else in `data/` is untouched.

## Please read: how the estimates work
Distance = straight line x 1.4, time = 40 km/h (rounded up to 5 min), +60 min for each boat crossing. Tuned for Leyte's roads but still an estimate, and the screens say so. A destination needs a boat if its **name** contains "Island/Islas" (a hint, not a schedule). Opening hours are read from the admin's text ("6:00 AM – 5:00 PM", "Open 24 hours", "closed Mondays"); text it cannot read never blocks a stop. Typical visit length comes from the old `stay` field (half day = 90 min, full day = 3 h, both = 2 h, none = 90 min); overnight-only places are never in a day trip.

## Data problem found in your project
**"payapay tacloban"** is saved with latitude 34.877, longitude 103.8 (that is in China). The planner, the map and the route ignore any destination outside Leyte and list it as "No usable map location". Fix it in Admin > Destinations (Tacloban is about 11.24, 125.00). This also means its live weather was never right.

## Tests: what was and was not run

**Run (all passing):**
- `node tools/planner-selftest.js`: 56 checks on distance/time, boat logic, opening-hours parsing, every advisory rule, and the trip scheduler (times chain correctly, hours and closed days respected, budget, interests, storm behaviour, lunch, ratings influence, determinism, bad input) using your real destinations.
- 73 checks in headless Chromium against your real static files with a throw-away Node stand-in for the API: review post / edit / delete / validation / markup shown as text / stale-answer protection; route screen; advisory at every level in popup, route and weather list; trip planner (budget, interests, storm, no weather, future date, bad times, saved preferences); no console errors; no horizontal overflow at 375 px; light and dark screenshots reviewed.

**NOT run (PHP is not installed where I worked): none of the PHP.** No `php -l`, no endpoint, no file-locking test. The stand-in mirrors my PHP's rules, but it is not the PHP. Please run:
1. `php -l` on `includes/reviews.php`, `api/reviews.php`, `api/review-save.php`, `api/review-delete.php`, `includes/destinations.php`, `api/destinations.php`, `api/delete.php`.
2. `php tools/selftest.php` (now includes 20 review checks: auth, rating/text validation, one-review-per-visitor edit, second user, author shown as "First L.", no id/email leaked, destination list carries rating + coordinates, deleting a destination removes its reviews).
3. By hand: post a review in the app, reload, log in as another account and see it; delete the account and confirm its review is gone from `data/reviews.json`.

## Limitations
- Live weather is current conditions only; for a trip on another day the planner does not use weather and says so.
- "My current location" needs browser permission and a location inside Leyte.
- The trip planner picks stops greedily by value per minute, then finds the quickest order; it is good, not guaranteed optimal.
- Admins cannot yet moderate or delete other people's reviews (that belongs to the Sprint 4 admin panel, SCRUM-22).
- Review text is checked for `<` `>` and control characters like the rest of the app; there is no profanity filter or rate limit.
