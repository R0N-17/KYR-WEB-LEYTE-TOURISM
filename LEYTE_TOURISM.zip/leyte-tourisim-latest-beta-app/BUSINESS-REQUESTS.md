# Business Destination Requests

Public form `business-request.html` (linked from `login.html`) -> pending store -> admin review `admin/requests.html` -> approval into the live directory.

## One definition of the destination form
- `js/dest-form.js` draws every destination field (order, labels, input types, limits, required marks, help texts, category and time checkboxes, photo box) and holds collect / fill / check / photo helpers.
- Used by **Admin > Destinations > Add/Edit** (`admin/destinations.html`, now `<div id="destFields">`), the **public request form**, and the **admin review modal**.
- Server: `dest_clean()` (includes/destinations.php) validates admin saves AND requests; categories come from `data/categories.json` (`api/categories.php` for the public form).

## Storage / flow
- Pending requests: `data/destination-requests.json` (+ photos in `data/request-photos/`, both outside web access). Never in `data/destinations.json`, so not visible publicly, in filters, maps or recommendations.
- Admin: `api/admin/requests.php`, `request-save.php` (corrections), `request-approve.php`, `request-reject.php`, `request-photo.php`. Approve calls `dest_insert()` (same as Add destination) and copies the photo to `images/places`. A duplicate name returns 409 and the request stays pending.
- Public: `api/destination-request.php` (no account). Limits: honeypot, 5 per connection per hour, 5 pending per email, 500 pending total.

## Necessary differences from the admin form
1. Extra "Your details" section after the destination fields (name, email, phone, ownership confirmation) - the only non-destination data; kept on the request, never copied to the destination.
2. Admin-only extras omitted on the public form: "New category" box (only admins create categories) and the live-weather note.
Everything else is identical (verified by `tools/form-parity-test.js`).

## Tests
- `php tools/selftest.php` - 57 new `requests:` checks (4 older `reviews:` checks fail on the original zip too).
- `node tools/form-parity-test.js [path-to-original-project]` - field-by-field comparison.
