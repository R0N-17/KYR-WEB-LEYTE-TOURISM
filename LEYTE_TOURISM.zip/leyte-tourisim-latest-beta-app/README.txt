KYR WEB TOURISM GUIDE: SETUP
============================

REQUIREMENTS
  PHP 8.1 or newer, with these extensions enabled: json, mbstring, fileinfo, curl (live weather and weather-selftest), gd or getimagesize support (photo uploads).
  No database and no Composer/npm install: Bootstrap, Bootstrap Icons and the fonts are already in vendor/.
  Missing mbstring: the API answers "The PHP mbstring extension is not enabled" (it never crashes silently). Enable it:
    Debian/Ubuntu:  sudo apt install php-mbstring        Windows/XAMPP: remove the ; before extension=mbstring in php.ini, then restart.
  Check what your PHP has:  php -m

START
  1. In the project folder:  php -S localhost:8000 router.php        (router.php also blocks /data, /includes and /tools from the browser)
  2. Open http://localhost:8000/login.html (visitors) and http://localhost:8000/admin/login.html (administrators).
     Open the site through PHP, not by double-clicking the files or with Live Server.
  3. Register a visitor account on the register page. This package ships with NO accounts.
  4. Make an administrator (command line only):
       php tools/make-admin.php create you@example.com "First" "Last"      (asks for a password)
       php tools/make-admin.php promote you@example.com                      (turns an existing account into an admin)
       php tools/make-admin.php list | demote you@example.com
  5. PHP must be able to write to data/ and images/places/.

WHERE DATA IS STORED (JSON / text files, no database)
  data/users.txt          accounts, one JSON record per line (created on first registration; private, never share it)
  data/destinations.json  destinations (created from includes/destinations.seed.json the first time it is needed)
  data/categories.json    categories (created from includes/categories.seed.json)
  data/weather-cache.json live weather cache (created automatically)
  images/places/          destination photos          data/deleted-photos/  photos of deleted destinations (not web accessible)

LIVE WEATHER (optional): the site works without a key and shows "Weather unavailable". To enable it, copy includes/config.local.example.php
  to includes/config.local.php and paste your OpenWeather key (or set the OPENWEATHER_API_KEY environment variable). See LIVE WEATHER below.

TESTS (need PHP 8.1+ CLI with the extensions above; they use a temporary copy, your data is untouched)
  php tools/selftest.php            backend integration test: auth, roles, destinations, categories, photos, settings account endpoint
  php tools/weather-selftest.php    weather service test against a fake OpenWeather server (no key or internet needed)
  If an extension is missing they stop with "ENVIRONMENT: ..." and exit code 2 (a setup problem, not an application failure).

SCOPE NOTE: Sprint 3 adds route planning, weather advisory, the one-day trip planner and destination ratings/reviews (SEE SPRINT3.md).
  Routes use ESTIMATES (no Google Maps API key); "Open in Google Maps" links give real directions. Favourites and the admin history panel (Sprint 4) are not part of this release.
SPRINT 4 (SEE SPRINT4.md): favourites (hearts), My Trip Plans (save a route or a one-day trip, edit, printable itinerary receipt), and an admin Activity page.
  Supabase is NOT integrated (see SUPABASE-MIGRATION.md): data is still in data/*.json files.
  Extra test:  node tools/planner-selftest.js   (Node only; planner, weather advisory and trip scheduling logic)

------------------------------------------------------------------------------------------------------------------------

Add your own photos here to replace the drawn scenes in the login slideshow.

Use these exact file names (JPG, about 1600 px tall, under 500 KB each):

  kalanggaman-island.jpg
  lake-danao.jpg
  san-juanico-bridge.jpg
  cuatro-islas.jpg

A slide with no photo shows its drawn scene instead. To add a slide, copy a
<div class="carousel-item"> block in index.html and a matching indicator button.
Only use photos you took or have permission to use, and credit them where required.


LIVE WEATHER (OpenWeather)
--------------------------
1. Create a free key at https://openweathermap.org/api ("Current Weather Data"). New keys can take up to a couple of hours to activate.
2. Copy includes/config.local.example.php to includes/config.local.php and paste your key
   (or set the environment variable OPENWEATHER_API_KEY).
3. Run the site as before: php -S localhost:8000 router.php

How it works: the dashboard calls api/weather.php (login required). PHP asks OpenWeather for every destination that has
valid coordinates (plus Tacloban for the header) and caches the result in data/weather-cache.json for 10 minutes
(WEATHER_TTL in includes/config.php), so the free plan is never hit per visitor. The key never reaches the browser.
Weather is NEVER typed in by hand and there are no made-up readings. Without a key (or if OpenWeather is down) the site
still works and says "Weather unavailable"; if the service is down but older readings are cached, they are shown
labelled as older (readings over 3 hours old are never presented as current). A destination without valid coordinates
simply has no weather. The admin form shows a read-only live preview for the destination being edited.
Each place is cached on its own, together with the coordinates it was fetched for: a new, renamed or moved place is fetched on the
next request (one call), and unrelated admin edits cost no calls. After a failed refresh the server waits 60 seconds (5 minutes if the
key was rejected or the rate limit was hit) before asking again, and only one request at a time talks to OpenWeather.
Test it without a real key or network:  php tools/weather-selftest.php  (uses a fake OpenWeather server on 127.0.0.1)

TRIP LENGTH
-----------
Trip length is a personal preference (registration questionnaire and the dashboard's Preferences window). It is no longer entered
per destination in the admin. Destinations saved earlier keep their stored visit length ("stay" in data/destinations.json), and the
recommendations still use it; a destination without it is simply not penalised.
Each destination's coordinates come from its own record (admin console). Adding or editing a place needs no code change.


PLACE PHOTOS (one source of truth)
----------------------------------
Each destination in data/destinations.json carries its own photo reference: image = {file, v}. api/destinations.php sends it
to the website as a ready-made, versioned URL in the field "image", and every card, popup, search result, filter and
recommendation uses that field. Upload or replace photos in the admin console (Destinations > Edit); there is no other list of
photo paths. Files are saved as images/places/<destination-id>-<stamp>.<ext>. Dropping a file into images/places/ by hand no
longer changes anything. Photos that were already in the folder are linked to their destinations automatically, once.


ADMIN MODULE (SCRUM-16: Manage Local Tourism Data)
--------------------------------------------------
Admin console: /admin/login.html. Destinations live in data/destinations.json (created from includes/destinations.seed.json on first use)
and are served to the public site by api/destinations.php. js/data.js no longer lists the places.
Make an admin on the server:  php tools/make-admin.php promote you@example.com   (or: create, demote, list)
Full setup, file list and testing checklist: ADMIN-MODULE.md

TRIP HISTORY AND REVIEWS (SEE TRIP-HISTORY.md): a destination can only be reviewed after the visitor marks a saved trip plan that includes it as completed. History Log > Trip history lists completed trips with Leave a Review.
