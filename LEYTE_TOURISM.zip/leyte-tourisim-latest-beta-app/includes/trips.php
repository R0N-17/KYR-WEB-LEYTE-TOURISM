<?php
// MY TRIP PLANS: saved route / one-day itineraries. data/trips.json holds every plan; each belongs to exactly one account (uid).
// One shared store for BOTH planners (manual route and automatic one-day trip): a plan is a parent record with its ordered stops inside it.
// A stop is a SNAPSHOT of the destination at save time (name, town, coordinates, fee, hours), so a later admin edit or delete
// never silently turns a saved plan into a different trip.
//
// ESTIMATES: leg distances and times are NOT from a routing service. They are straight line x TRIP_ROAD_FACTOR at TRIP_AVG_KPH (labelled as
// estimates everywhere). The browser calculates them (js/planner.js); this file RE-CHECKS every leg against the same formula, so a request
// cannot store invented numbers.
// Same storage pattern as reviews.php: one exclusive lock per read-modify-write, writes go to a temp file renamed over the real one.
// Lock order (see categories.php): categories -> destinations -> users -> reviews -> trips. Nothing here takes another lock while holding this one.

const TRIP_STATUSES = ['planned', 'completed', 'cancelled'];
const TRIP_SOURCES  = ['route', 'daytrip', 'custom'];
const TRIP_LEVELS   = ['good', 'caution', 'avoid', 'unknown'];
// Leyte and nearby islands (the same box as js/planner.js). A start point outside it is a typing mistake or a place the estimate does not cover.
const TRIP_BOX = ['minLat' => 9.5, 'maxLat' => 11.9, 'minLng' => 123.9, 'maxLng' => 125.5];

function trip_locked(callable $fn) {
    $lock = fopen(TRIP_FILE . '.lock', 'c');
    if (!$lock) return $fn();
    flock($lock, LOCK_EX);
    try { return $fn(); }
    finally { flock($lock, LOCK_UN); fclose($lock); }
}

// [planId => record]. A damaged file stops a WRITE (carrying on would overwrite whatever is left); it is never silently treated as empty.
function trip_read_raw(): array {
    $raw = @file_get_contents(TRIP_FILE);
    if ($raw === false || trim($raw) === '') return [];
    $list = json_decode($raw, true);
    if (!is_array($list))
        throw new ApiError('data/trips.json is damaged. Restore it from a backup (or delete it to remove every saved trip plan).', 500);
    $out = [];
    foreach ($list as $r) if (is_array($r) && isset($r['id'], $r['uid'])) $out[(string)$r['id']] = $r;
    return $out;
}

function trip_save_all(array $all): void {
    $json = json_encode(array_values($all), JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES) . "\n";
    $tmp = TRIP_FILE . '.tmp' . getmypid();
    if (file_put_contents($tmp, $json) === false || !@rename($tmp, TRIP_FILE)) {
        @unlink($tmp);
        if (file_put_contents(TRIP_FILE, $json, LOCK_EX) === false)
            throw new ApiError('Could not save your trip plan. Check that the data folder is writable.', 500);
    }
}

/* ======================= The estimate (mirror of js/planner.js travel()) ======================= */

function trip_haversine_km(float $lat1, float $lng1, float $lat2, float $lng2): float {
    $p = M_PI / 180;
    $dLat = ($lat2 - $lat1) * $p; $dLng = ($lng2 - $lng1) * $p;
    $h = sin($dLat / 2) ** 2 + cos($lat1 * $p) * cos($lat2 * $p) * sin($dLng / 2) ** 2;
    return 2 * 6371.0 * asin(min(1.0, sqrt($h)));
}

// [roadKm (1 decimal), minimum minutes without any boat] for one leg between two points.
function trip_leg_estimate(array $a, array $b): array {
    $roadKm = trip_haversine_km((float)$a['lat'], (float)$a['lng'], (float)$b['lat'], (float)$b['lng']) * TRIP_ROAD_FACTOR;
    $min = max(5, (int)(ceil(($roadKm / TRIP_AVG_KPH) * 60 / 5) * 5));
    return [round($roadKm, 1), $min];
}

/* ======================= Validation ======================= */

// Plain text: no < or >, no control characters, collapsed spaces, length limit. $multiline keeps line breaks (notes).
function trip_text($v, string $label, int $max, bool $multiline = false, bool $required = false): string {
    if ($v === null) $v = '';
    if (!is_string($v)) throw new ApiError("The $label is not valid.", 422);
    $v = str_replace(["\r\n", "\r", "\t"], ["\n", "\n", ' '], $v);
    $v = trim($v);
    if (preg_match('/[<>]/', $v)) throw new ApiError("The $label can't contain the characters < or >.", 422);
    if (preg_match($multiline ? '/[\x00-\x09\x0B-\x1F\x7F]/' : '/[\x00-\x1F\x7F]/', $v)) throw new ApiError("The $label contains characters that are not allowed.", 422);
    $v = $multiline ? preg_replace("/\n{3,}/", "\n\n", preg_replace('/ {2,}/', ' ', $v)) : preg_replace('/ {2,}/', ' ', $v);
    if ($required && $v === '') throw new ApiError("Enter a $label.", 422);
    if (mb_strlen($v) > $max) throw new ApiError("Keep the $label to $max characters or fewer.", 422);
    return $v;
}

// A whole number within [$min, $max]. JSON numbers like 540 or "540" are fine; 540.5, null, text are not.
function trip_int($v, int $min, int $max, string $label): int {
    if (is_string($v) && preg_match('/^-?\d{1,6}$/', $v)) $v = (int)$v;
    if (!is_int($v) || $v < $min || $v > $max) throw new ApiError("The $label is not valid.", 422);
    return $v;
}

function trip_clean_point($p, string $label): array {
    if (!is_array($p)) throw new ApiError("Choose a $label.", 422);
    $lat = $p['lat'] ?? null; $lng = $p['lng'] ?? null;
    if (!is_numeric($lat) || !is_numeric($lng)) throw new ApiError("The $label has no usable location.", 422);
    $lat = (float)$lat; $lng = (float)$lng;
    if ($lat < TRIP_BOX['minLat'] || $lat > TRIP_BOX['maxLat'] || $lng < TRIP_BOX['minLng'] || $lng > TRIP_BOX['maxLng'])
        throw new ApiError("The $label is outside Leyte, which the route estimates cover.", 422);
    return ['name' => trip_text($p['name'] ?? '', "$label name", 80, false, true), 'lat' => round($lat, 6), 'lng' => round($lng, 6)];
}

// Weather snapshot: optional. {kind: current|unavailable, observedAt: unix time or null, note, items: [{destId,name,level,label,reasons[],desc,tempC}]}.
// Whatever is sent is only re-shaped and length-limited; the receipt labels it as a snapshot taken at observedAt, never as a forecast.
function trip_clean_weather($w): ?array {
    if ($w === null || $w === []) return null;
    if (!is_array($w)) throw new ApiError('The weather snapshot is not valid.', 422);
    $kind = ($w['kind'] ?? '') === 'current' ? 'current' : 'unavailable';
    $obs = $w['observedAt'] ?? null;
    $obs = (is_int($obs) && $obs > 1500000000 && $obs < 4000000000) ? $obs : null;
    $items = [];
    if ($kind === 'current') foreach (array_slice((array)($w['items'] ?? []), 0, TRIP_STOPS_MAX) as $it) {
        if (!is_array($it)) continue;
        $lvl = in_array($it['level'] ?? '', TRIP_LEVELS, true) ? $it['level'] : 'unknown';
        $reasons = [];
        foreach (array_slice((array)($it['reasons'] ?? []), 0, 3) as $r) if (is_string($r)) $reasons[] = mb_substr(str_replace(['<', '>'], '', $r), 0, 140);
        $temp = $it['tempC'] ?? null;
        $items[] = [
            'destId'  => mb_substr(preg_replace('/[^A-Za-z0-9_-]/', '', (string)($it['destId'] ?? '')), 0, 40),
            'name'    => mb_substr(str_replace(['<', '>'], '', (string)($it['name'] ?? '')), 0, 100),
            'level'   => $lvl,
            'label'   => mb_substr(str_replace(['<', '>'], '', (string)($it['label'] ?? '')), 0, 40),
            'reasons' => $reasons,
            'desc'    => mb_substr(str_replace(['<', '>'], '', (string)($it['desc'] ?? '')), 0, 60),
            'tempC'   => is_numeric($temp) ? (int)round((float)$temp) : null,
        ];
    }
    return ['kind' => $kind, 'observedAt' => $obs, 'note' => trip_text($w['note'] ?? '', 'weather note', 200), 'items' => $items];
}

// Checks one submitted plan and returns the clean fields to store. $oldStops = the stops of the plan being edited (by destination id):
// a destination the admin has since deleted keeps its saved snapshot, so editing the notes of an old plan still works.
function trip_clean(array $in, array $oldStops = []): array {
    $title = trip_text($in['title'] ?? '', 'trip title', TRIP_TITLE_MAX, false, true);
    $date = $in['date'] ?? '';
    if (!is_string($date) || !preg_match('/^(\d{4})-(\d{2})-(\d{2})$/', $date, $m) || !checkdate((int)$m[2], (int)$m[3], (int)$m[1]) || (int)$m[1] < 2020 || (int)$m[1] > 2100)
        throw new ApiError('Choose the date you plan to travel.', 422);
    $dep = trip_int($in['departure'] ?? null, 0, 1439, 'departure time');
    if (($in['mode'] ?? 'driving') !== 'driving') throw new ApiError('Driving is the only travel mode supported right now.', 422);
    $source = in_array($in['source'] ?? 'custom', TRIP_SOURCES, true) ? $in['source'] : 'custom';
    $status = $in['status'] ?? 'planned';
    if (!in_array($status, TRIP_STATUSES, true)) throw new ApiError('Choose a status: planned, completed or cancelled.', 422);
    $notes = trip_text($in['notes'] ?? '', 'notes', TRIP_NOTES_MAX, true);
    $start = trip_clean_point($in['start'] ?? null, 'starting point');

    $rawStops = $in['stops'] ?? null;
    if (!is_array($rawStops) || !$rawStops) throw new ApiError('Add at least one destination to the plan.', 422);
    if (count($rawStops) > TRIP_STOPS_MAX) throw new ApiError('A plan can have at most ' . TRIP_STOPS_MAX . ' destinations.', 422);

    $stops = []; $prev = $start; $prevEnd = $dep; $travelMin = 0; $km = 0.0; $fee = 0; $seen = [];
    foreach (array_values($rawStops) as $i => $s) {
        if (!is_array($s)) throw new ApiError('A destination in the plan is not valid.', 422);
        $did = $s['destId'] ?? '';
        if (!is_string($did) || !preg_match('/^[A-Za-z0-9_-]{1,40}$/', $did)) throw new ApiError('A destination in the plan is not valid.', 422);
        if (isset($seen[$did])) throw new ApiError('The same destination is in the plan twice.', 422);
        $seen[$did] = true;
        // Snapshot: from the live destination when it exists, otherwise from this plan's earlier snapshot, otherwise it is refused.
        $d = dest_find($did);
        if ($d) {
            if (!is_numeric($d['lat'] ?? null) || !is_numeric($d['lng'] ?? null)) throw new ApiError(($d['name'] ?? 'A destination') . ' has no map location yet, so it cannot be planned.', 422);
            $snap = ['name' => (string)$d['name'], 'town' => (string)($d['town'] ?? ''), 'lat' => round((float)$d['lat'], 6), 'lng' => round((float)$d['lng'], 6),
                     'fee' => (string)($d['fee'] ?? ''), 'feeAmt' => (int)($d['feeAmt'] ?? 0), 'hours' => (string)($d['hours'] ?? '')];
        } elseif (isset($oldStops[$did])) {
            $o = $oldStops[$did];
            $snap = ['name' => (string)$o['name'], 'town' => (string)$o['town'], 'lat' => (float)$o['lat'], 'lng' => (float)$o['lng'],
                     'fee' => (string)$o['fee'], 'feeAmt' => (int)$o['feeAmt'], 'hours' => (string)$o['hours']];
        } else throw new ApiError('A destination in the plan no longer exists. Remove it and try again.', 404);
        if ($snap['lat'] < TRIP_BOX['minLat'] || $snap['lat'] > TRIP_BOX['maxLat'] || $snap['lng'] < TRIP_BOX['minLng'] || $snap['lng'] > TRIP_BOX['maxLng'])
            throw new ApiError($snap['name'] . ' has map coordinates outside Leyte, so it cannot be planned. Ask the administrator to correct them.', 422);

        $visit = trip_int($s['visitMin'] ?? null, 15, 480, 'visit length');
        $arrive = trip_int($s['arrive'] ?? null, 0, 1440, 'arrival time');
        $begin = trip_int($s['begin'] ?? null, 0, 1440, 'visit start time');
        $end = trip_int($s['end'] ?? null, 0, 1440, 'visit end time');
        $legMin = trip_int($s['legMin'] ?? null, 1, 1440, 'travel time');
        $lunch = trip_int($s['lunchBefore'] ?? 0, 0, 120, 'lunch break');   // minutes of lunch before driving to this stop (0 = none)
        $legKm = $s['legKm'] ?? null;
        if (!is_numeric($legKm) || (float)$legKm < 0 || (float)$legKm > 500) throw new ApiError('The travel distance is not valid.', 422);
        $legKm = round((float)$legKm, 1);

        // The numbers must agree with the estimate formula: same distance (within rounding), and a time that is the base time, plus at most two boat crossings.
        [$expKm, $baseMin] = trip_leg_estimate($prev, $snap);
        if (abs($legKm - $expKm) > 0.15 + 0.02 * $expKm) throw new ApiError("The travel distance to {$snap['name']} does not match the estimate. Recalculate the plan and save again.", 422);
        if ($legMin < $baseMin || $legMin > $baseMin + 120) throw new ApiError("The travel time to {$snap['name']} does not match the estimate. Recalculate the plan and save again.", 422);
        // The clock must make sense: you cannot arrive before you could have driven there, nor start before arriving, and the visit lasts what it says.
        if ($arrive < $prevEnd + $lunch + $legMin) throw new ApiError("The arrival time at {$snap['name']} is earlier than the travel time allows.", 422);
        if ($begin < $arrive || $end !== $begin + $visit) throw new ApiError("The visit times at {$snap['name']} do not add up.", 422);
        if ($end > 1440) throw new ApiError('A one-day plan must finish by midnight. Remove a stop or leave earlier.', 422);

        $stops[] = ['order' => $i + 1, 'destId' => $did] + $snap + ['arrive' => $arrive, 'begin' => $begin, 'end' => $end, 'visitMin' => $visit, 'legMin' => $legMin, 'legKm' => $legKm, 'lunchBefore' => $lunch,
                    'boat' => !empty($s['boat']) && $legMin > $baseMin];
        $travelMin += $legMin; $km += $legKm; $fee += $snap['feeAmt'];
        $prev = $snap; $prevEnd = $end;
    }
    $retMin = trip_int($in['returnLegMin'] ?? null, 1, 1440, 'return travel time');
    $retKm = $in['returnLegKm'] ?? null;
    if (!is_numeric($retKm) || (float)$retKm < 0 || (float)$retKm > 500) throw new ApiError('The return distance is not valid.', 422);
    $retKm = round((float)$retKm, 1);
    [$expKm, $baseMin] = trip_leg_estimate($prev, $start);
    if (abs($retKm - $expKm) > 0.15 + 0.02 * $expKm || $retMin < $baseMin || $retMin > $baseMin + 120) throw new ApiError('The return trip does not match the estimate. Recalculate the plan and save again.', 422);
    $retLunch = trip_int($in['returnLunch'] ?? 0, 0, 120, 'lunch break');   // lunch taken at the last stop before driving home
    $returnTime = trip_int($in['returnTime'] ?? null, 0, 1440, 'return time');
    if ($returnTime < $prevEnd + $retLunch + $retMin) throw new ApiError('The return time is earlier than the travel time allows.', 422);
    $travelMin += $retMin; $km += $retKm;

    return [
        'title' => $title, 'date' => $date, 'departure' => $dep, 'mode' => 'driving', 'source' => $source, 'status' => $status, 'notes' => $notes,
        'start' => $start, 'stops' => $stops, 'returnLegMin' => $retMin, 'returnLegKm' => $retKm, 'returnLunch' => $retLunch, 'returnTime' => $returnTime,
        'totals' => ['travelMin' => $travelMin, 'km' => round($km, 1), 'fee' => $fee],
        'estimate' => ['method' => 'straight-line distance x ' . TRIP_ROAD_FACTOR . ' at ' . TRIP_AVG_KPH . ' km/h; +60 min per boat crossing', 'routingService' => false],
        'weather' => trip_clean_weather($in['weather'] ?? null),
    ];
}

/* ======================= Reads ======================= */

function trip_new_id(array $existing): string {
    do { $id = 'TP-' . date('Ymd') . '-' . strtoupper(bin2hex(random_bytes(3))); } while (isset($existing[$id]));
    return $id;
}

// What the browser gets. The owner's account id and the duplicate-save token never leave the server.
function trip_public(array $t): array {
    unset($t['uid'], $t['token']);
    return $t;
}

// A line for the "My Trip Plans" list: enough for a card, without the whole itinerary.
function trip_summary(array $t): array {
    return [
        'id' => $t['id'], 'title' => $t['title'], 'date' => $t['date'], 'departure' => $t['departure'], 'status' => $t['status'], 'source' => $t['source'] ?? 'custom',
        'start' => $t['start']['name'] ?? '', 'stopCount' => count($t['stops'] ?? []), 'stopNames' => array_slice(array_column($t['stops'] ?? [], 'name'), 0, 3),
        'returnTime' => $t['returnTime'] ?? null, 'travelMin' => $t['totals']['travelMin'] ?? null, 'km' => $t['totals']['km'] ?? null,
        'created' => $t['created'], 'updated' => $t['updated'], 'completedAt' => trip_completed_at($t),
    ];
}

// The signed-in owner's plans, upcoming dates first. Plans of other accounts never come back from here.
function trip_list(string $uid): array {
    $mine = array_values(array_filter(trip_read_raw(), fn($t) => $t['uid'] === $uid));
    usort($mine, fn($a, $b) => strcmp($b['date'], $a['date']) ?: strcmp($b['created'], $a['created']));
    return array_map('trip_summary', $mine);
}

// One plan, only if it belongs to $uid. A plan that is someone else's is reported exactly like one that does not exist (404), so ids cannot be probed.
function trip_get(string $id, string $uid): array {
    if (!preg_match('/^TP-\d{8}-[A-F0-9]{6}$/', $id)) throw new ApiError('That trip plan was not found.', 404);
    $t = trip_read_raw()[$id] ?? null;
    if (!$t || $t['uid'] !== $uid) throw new ApiError('That trip plan was not found.', 404);
    return $t;
}

/* ======================= Writes ======================= */

// Creates a plan. $token (16-64 chars, made by the browser for ONE save attempt) makes a repeated submit (double click, retry after a slow
// answer) return the plan that was already saved instead of a second copy. Returns [record, wasDuplicate].
function trip_create(string $uid, string $token, array $clean): array {
    if (!preg_match('/^[A-Za-z0-9_-]{16,64}$/', $token)) throw new ApiError('Reload the page and try again.', 422);
    return trip_locked(function () use ($uid, $token, $clean) {
        $all = trip_read_raw();
        $count = 0;
        foreach ($all as $t) {
            if ($t['uid'] !== $uid) continue;
            if (($t['token'] ?? '') === $token) return [$t, true];
            $count++;
        }
        if ($count >= TRIP_MAX_PER_USER) throw new ApiError('You can keep up to ' . TRIP_MAX_PER_USER . ' trip plans. Delete one you no longer need.', 422);
        $now = date('c');
        $rec = ['id' => trip_new_id($all), 'uid' => $uid, 'token' => $token, 'created' => $now, 'updated' => $now, 'completedAt' => $clean['status'] === 'completed' ? $now : null] + $clean;
        $all[$rec['id']] = $rec;
        trip_save_all($all);
        return [$rec, false];
    });
}

// Replaces the editable parts of one of the owner's plans. The id, owner, creation time and token never change.
function trip_update(string $id, string $uid, array $in): array {
    return trip_locked(function () use ($id, $uid, $in) {
        $all = trip_read_raw();
        $old = $all[$id] ?? null;
        if (!$old || $old['uid'] !== $uid) throw new ApiError('That trip plan was not found.', 404);
        $oldStops = [];
        foreach ((array)$old['stops'] as $s) $oldStops[(string)$s['destId']] = $s;
        $clean = trip_clean($in, $oldStops);
        $clean['source'] = $old['source'] ?? $clean['source'];
        if (!array_key_exists('weather', $in)) $clean['weather'] = $old['weather'] ?? null;   // not sent = keep the snapshot taken when the plan was saved
        // A completed trip is the record that lets its owner review those destinations, so while it stays completed its destinations cannot be swapped.
        // (Set it back to Planned first, change it, and mark it completed again.)
        if (($old['status'] ?? '') === 'completed' && $clean['status'] === 'completed') {
            $was = array_map('strval', array_keys($oldStops)); $nowIds = array_map('strval', array_column($clean['stops'], 'destId'));
            sort($was); sort($nowIds);
            if ($was !== $nowIds) throw new ApiError('The destinations of a completed trip cannot be changed. Set it back to Planned first.', 422);
        }
        $stamp = date('c');
        if ($clean['status'] !== 'completed') $clean['completedAt'] = null;
        elseif (($old['status'] ?? '') === 'completed') $clean['completedAt'] = trip_completed_at($old);   // already completed: the date stays
        else $clean['completedAt'] = $stamp;
        $all[$id] = array_merge($old, $clean, ['updated' => $stamp]);
        trip_save_all($all);
        return $all[$id];
    });
}

function trip_remove_where(callable $match): int {
    if (!is_file(TRIP_FILE)) return 0;
    return trip_locked(function () use ($match) {
        $all = trip_read_raw();
        $keep = array_filter($all, fn($t) => !$match($t));
        $n = count($all) - count($keep);
        if ($n > 0) trip_save_all($keep);
        return $n;
    });
}
function trip_delete(string $id, string $uid): void {
    if (!preg_match('/^TP-\d{8}-[A-F0-9]{6}$/', $id) || trip_remove_where(fn($t) => $t['id'] === $id && $t['uid'] === $uid) === 0)
        throw new ApiError('That trip plan was not found.', 404);
}
function trip_delete_for_user(string $uid): int { return trip_remove_where(fn($t) => $t['uid'] === $uid); }   // account deleted

/* ======================= Completed trips: the History Log, and who may review what ======================= */
// SPRINT 3 (completed-trip history and destination reviews). There is no second store: a trip is "completed" when its saved plan (data/trips.json)
// has status "completed". The history is DERIVED from those plans, one entry per destination in each completed plan, so nothing can disagree.
// A trip becomes completed only when its owner says so (api/trip-complete.php, or the status in the plan editor). Opening a destination or a map never does.

// When the owner marked it completed. Plans completed before this field existed fall back to their last-updated time.
function trip_completed_at(array $t): ?string {
    if (($t['status'] ?? '') !== 'completed') return null;
    return (string)($t['completedAt'] ?? $t['updated'] ?? $t['created'] ?? '') ?: null;
}

// Marks one of the owner's PLANNED trips as completed. Safe to repeat: a second call (double click, retry) changes nothing and says so.
// Returns [record, alreadyCompleted]. Someone else's plan is reported exactly like one that does not exist (404).
function trip_complete(string $id, string $uid): array {
    if (!preg_match('/^TP-\d{8}-[A-F0-9]{6}$/', $id)) throw new ApiError('That trip plan was not found.', 404);
    return trip_locked(function () use ($id, $uid) {
        $all = trip_read_raw();
        $t = $all[$id] ?? null;
        if (!$t || $t['uid'] !== $uid) throw new ApiError('That trip plan was not found.', 404);
        if (($t['status'] ?? '') === 'completed') return [$t, true];
        if (($t['status'] ?? '') !== 'planned') throw new ApiError('Only a planned trip can be marked as completed. Open the plan and set it back to Planned first.', 409);
        $now = date('c');
        $t['status'] = 'completed'; $t['completedAt'] = $now; $t['updated'] = $now;
        $all[$id] = $t;
        trip_save_all($all);
        return [$t, false];
    });
}

// The owner's History Log of trips: ['completed' => completed plans (newest completion first), each with its destinations and a Reviewed / Not Reviewed state per destination,
//                                   'incomplete' => planned and cancelled plans (soonest first, as list cards)].
// Review state comes from the reviews file (the one place reviews live), so it can never be out of step. Other accounts' plans never appear here.
function trip_history(string $uid): array {
    $mine = rev_mine_map($uid);
    $completed = []; $incomplete = [];
    foreach (trip_read_raw() as $t) {
        if ($t['uid'] !== $uid) continue;
        if (($t['status'] ?? '') !== 'completed') { $incomplete[] = $t; continue; }
        $dests = [];
        foreach ((array)($t['stops'] ?? []) as $s) {
            $did = (string)($s['destId'] ?? '');
            $rv = $mine[$did] ?? null;
            $dests[] = [
                'destId' => $did, 'name' => (string)($s['name'] ?? ''), 'town' => (string)($s['town'] ?? ''),
                'available' => $did !== '' && dest_find($did) !== null,   // a destination the admin removed cannot be reviewed any more
                'reviewed' => $rv !== null,
                'review' => $rv ? ['rating' => (int)$rv['rating'], 'date' => (string)($rv['updated'] ?? $rv['created'] ?? '')] : null,
            ];
        }
        $completed[] = ['id' => $t['id'], 'title' => $t['title'], 'date' => $t['date'], 'status' => 'completed', 'completedAt' => trip_completed_at($t), 'destinations' => $dests];
    }
    usort($completed, fn($a, $b) => strcmp((string)$b['completedAt'], (string)$a['completedAt']) ?: strcmp($a['id'], $b['id']));
    usort($incomplete, fn($a, $b) => strcmp($a['date'], $b['date']) ?: strcmp($a['created'], $b['created']));
    return ['completed' => $completed, 'incomplete' => array_map('trip_summary', $incomplete)];
}

// The id of one of $uid's COMPLETED plans that includes the destination, or null. This is what "you may review this place" means on the server.
function trip_completed_with(string $uid, string $destId): ?string {
    foreach (trip_read_raw() as $t) {
        if ($t['uid'] !== $uid || ($t['status'] ?? '') !== 'completed') continue;
        foreach ((array)($t['stops'] ?? []) as $s) if ((string)($s['destId'] ?? '') === $destId) return (string)$t['id'];
    }
    return null;
}

// Checks a review request made from a history entry and returns the plan. Ownership, completion and "this destination is part of that trip"
// are all decided here from the stored plan; nothing the browser says about them is believed. Wrong owner / unknown plan = 404.
function trip_review_check(string $tripId, string $uid, string $destId): array {
    $t = trip_get($tripId, $uid);
    if (($t['status'] ?? '') !== 'completed') throw new ApiError('Mark this trip as completed before you review it.', 403);
    $inTrip = false;
    foreach ((array)($t['stops'] ?? []) as $s) if ((string)($s['destId'] ?? '') === $destId) { $inTrip = true; break; }
    if (!$inTrip) throw new ApiError('That destination is not part of this trip.', 404);
    return $t;
}

