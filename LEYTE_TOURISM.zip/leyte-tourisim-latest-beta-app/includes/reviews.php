<?php
// SCRUM-20: destination ratings and reviews.
// One JSON file (data/reviews.json) holds every review: [{id, dest, uid, rating, comment, created, updated}, ...].
//   dest = the destination's id        uid = the reviewer's account id (never sent to the browser)
// A visitor has AT MOST ONE review per destination: posting again edits it. A NEW review needs a completed trip that includes the destination (includes/trips.php). Same storage approach as destinations.php / db.php:
// one exclusive lock around each read-modify-write, and writes go to a temp file that is renamed over the real one.
// Lock order (see categories.php): categories -> destinations -> users -> reviews. Nothing in here takes another lock while holding this one.
// Browsing destinations must never depend on reviews: rev_summaries() swallows a damaged file and returns "no ratings".

function rev_locked(callable $fn) {
    $lock = fopen(REV_FILE . '.lock', 'c');
    if (!$lock) return $fn();
    flock($lock, LOCK_EX);
    try { return $fn(); }
    finally { flock($lock, LOCK_UN); fclose($lock); }
}

// [reviewId => record]. A damaged file stops a WRITE (carrying on would overwrite whatever is left).
function rev_read_raw(): array {
    $raw = @file_get_contents(REV_FILE);
    if ($raw === false || trim($raw) === '') return [];
    $list = json_decode($raw, true);
    if (!is_array($list))
        throw new ApiError('data/reviews.json is damaged. Restore it from a backup (or delete it to remove every review).', 500);
    $out = [];
    foreach ($list as $r)
        if (is_array($r) && isset($r['id'], $r['dest'], $r['uid'], $r['rating'])) $out[(string)$r['id']] = $r;
    return $out;
}

function rev_save(array $all): void {
    $json = json_encode(array_values($all), JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES) . "\n";
    $tmp = REV_FILE . '.tmp' . getmypid();
    if (file_put_contents($tmp, $json) === false || !@rename($tmp, REV_FILE)) {
        @unlink($tmp);
        if (file_put_contents(REV_FILE, $json, LOCK_EX) === false)
            throw new ApiError('Could not save your review. Check that the data folder is writable.', 500);
    }
}

/* ======================= Validation ======================= */

// 1 to 5, whole stars only.
function rev_clean_rating(array $in): int {
    $r = $in['rating'] ?? null;
    if (is_string($r) && preg_match('/^[1-5]$/', $r)) $r = (int)$r;
    if (!is_int($r) || $r < 1 || $r > 5) throw new ApiError('Choose a rating from 1 to 5 stars.', 422);
    return $r;
}

// Optional text. Line breaks are kept (unlike dest_text); < and > and control characters are rejected, like everywhere else in the app.
function rev_clean_comment(array $in): string {
    $v = $in['comment'] ?? '';
    if ($v === null) $v = '';
    if (!is_string($v)) throw new ApiError('The review text is not valid.', 422);
    $v = str_replace(["\r\n", "\r", "\t"], ["\n", "\n", ' '], $v);
    $v = trim($v);
    if (preg_match('/[<>]/', $v)) throw new ApiError("The review can't contain the characters < or >.", 422);
    if (preg_match('/[\x00-\x09\x0B-\x1F\x7F]/', $v)) throw new ApiError('The review contains characters that are not allowed.', 422);
    $v = preg_replace('/ {2,}/', ' ', $v);
    $v = preg_replace("/\n{3,}/", "\n\n", $v);
    if (mb_strlen($v) > REV_COMMENT_MAX) throw new ApiError('Keep your review to ' . REV_COMMENT_MAX . ' characters or fewer.', 422);
    return $v;
}

/* ======================= Writes ======================= */

// Creates the visitor's review of a destination, or edits it if they already wrote one. Returns the saved record.
// $tripId (optional) = the completed trip the review was written from; it is kept on a NEW review for traceability.
// The returned record also says 'new' => true when it was created, false when an existing review was edited.
// $createOnly = true (reviews written from a trip) never edits: when the visitor already has a review of the destination it returns null, decided inside the same lock.
function rev_upsert(string $destId, string $uid, int $rating, string $comment, ?string $tripId = null, bool $createOnly = false): ?array {
    return rev_locked(function () use ($destId, $uid, $rating, $comment, $tripId, $createOnly) {
        $all = rev_read_raw();
        $now = date('c');
        $key = null;
        foreach ($all as $id => $r)
            if ($r['dest'] === $destId && $r['uid'] === $uid) { $key = $id; break; }
        if ($key !== null && $createOnly) return null;
        if ($key !== null) {
            $all[$key]['rating'] = $rating;
            $all[$key]['comment'] = $comment;
            $all[$key]['updated'] = $now;
            $rec = $all[$key];
            $isNew = false;
        } else {
            $key = 'r' . bin2hex(random_bytes(6));
            $rec = ['id' => $key, 'dest' => $destId, 'uid' => $uid, 'rating' => $rating, 'comment' => $comment, 'created' => $now, 'updated' => $now];
            if ($tripId !== null) $rec['trip'] = $tripId;
            $all[$key] = $rec;
            $isNew = true;
        }
        rev_save($all);
        return $rec + ['new' => $isNew];
    });
}

// Removes records matching $match (a function of one record). Saves only when something changed. Returns how many were removed.
function rev_remove_where(callable $match): int {
    if (!is_file(REV_FILE)) return 0;
    return rev_locked(function () use ($match) {
        $all = rev_read_raw();
        $keep = array_filter($all, fn($r) => !$match($r));
        $n = count($all) - count($keep);
        if ($n > 0) rev_save($keep);
        return $n;
    });
}

function rev_delete_mine(string $destId, string $uid): int { return rev_remove_where(fn($r) => $r['dest'] === $destId && $r['uid'] === $uid); }
function rev_delete_for_user(string $uid): int            { return rev_remove_where(fn($r) => $r['uid'] === $uid); }           // account deleted
function rev_delete_for_destination(string $destId): int  { return rev_remove_where(fn($r) => $r['dest'] === $destId); }      // destination deleted

/* ======================= Reads ======================= */

// Average and count from a list of records: ['avg' => 4.3 (1 decimal, or null with no reviews), 'count' => n, 'dist' => [1 => n, ..., 5 => n]].
function rev_stats(array $records): array {
    $dist = [1 => 0, 2 => 0, 3 => 0, 4 => 0, 5 => 0];
    $sum = 0; $n = 0;
    foreach ($records as $r) {
        $s = (int)$r['rating'];
        if ($s < 1 || $s > 5) continue;
        $dist[$s]++; $sum += $s; $n++;
    }
    return ['avg' => $n ? round($sum / $n, 1) : null, 'count' => $n, 'dist' => $dist];
}

// [destId => ['avg' => .., 'count' => ..]] for every destination that has reviews. Used by the public destination list.
function rev_summaries(): array {
    try {
        $by = [];
        foreach (rev_read_raw() as $r) $by[(string)$r['dest']][] = $r;
        $out = [];
        foreach ($by as $dest => $list) { $s = rev_stats($list); $out[$dest] = ['avg' => $s['avg'], 'count' => $s['count']]; }
        return $out;
    } catch (Throwable $e) {
        error_log('reviews: ' . $e->getMessage());
        return [];   // a damaged reviews file must never break browsing destinations
    }
}

// "Maria S." Only the first name and the first letter of the last name are ever shown to other visitors. The account id and email never leave the server.
function rev_author(?array $u): string {
    if (!$u) return 'Former visitor';
    $first = trim((string)($u['first_name'] ?? ''));
    $last = trim((string)($u['last_name'] ?? ''));
    $initial = $last !== '' ? ' ' . mb_strtoupper(mb_substr($last, 0, 1, 'UTF-8'), 'UTF-8') . '.' : '';
    return ($first !== '' ? $first : 'Visitor') . $initial;
}

// [destId => the review record] for one account's own reviews (used by the History Log to show Reviewed / Not Reviewed).
function rev_mine_map(string $uid): array {
    $out = [];
    foreach (rev_read_raw() as $r) if ($r['uid'] === $uid) $out[(string)$r['dest']] = $r;
    return $out;
}

// Everything the details popup needs for one destination.
// $viewerId = the signed-in account (or null): marks "mine" so the popup can show the edit form.
function rev_view(string $destId, ?string $viewerId): array {
    $all = array_values(array_filter(rev_read_raw(), fn($r) => $r['dest'] === $destId));
    usort($all, fn($a, $b) => strcmp((string)($b['updated'] ?? ''), (string)($a['updated'] ?? '')));   // newest first
    $users = $all ? db_all() : [];
    $mine = null;
    $list = [];
    foreach ($all as $r) {
        $isMine = $viewerId !== null && $r['uid'] === $viewerId;
        $row = [
            'id'      => (string)$r['id'],
            'rating'  => (int)$r['rating'],
            'comment' => (string)($r['comment'] ?? ''),
            'author'  => rev_author($users[$r['uid']] ?? null),
            'date'    => (string)($r['updated'] ?? $r['created'] ?? ''),
            'edited'  => ($r['updated'] ?? '') !== ($r['created'] ?? ''),
            'mine'    => $isMine,
        ];
        if ($isMine) $mine = $row;
        $list[] = $row;
    }
    // The visitor's own review is always sent, even when it is older than the newest REV_LIST_MAX.
    $shown = array_slice($list, 0, REV_LIST_MAX);
    if ($mine && !in_array($mine['id'], array_column($shown, 'id'), true)) $shown[] = $mine;
    // canReview: the popup shows the review form only to a visitor who already has a review here (so they can edit it) or who has a COMPLETED trip
    // that includes this destination. The server enforces the same rule in api/review-save.php; this flag only decides what the popup shows.
    $can = false;
    if ($viewerId !== null) {
        try { $can = $mine !== null || trip_completed_with($viewerId, $destId) !== null; }
        catch (Throwable $e) { error_log('reviews: ' . $e->getMessage()); }
    }
    return ['summary' => rev_stats($all), 'reviews' => $shown, 'mine' => $mine, 'canReview' => $can];
}

// The destination id from a request body. It must be a real destination, so reviews can never be attached to something that does not exist.
function rev_destination_id(array $in): string {
    $id = trim(str_in($in, 'destination'));
    if ($id === '' || !preg_match('/^[A-Za-z0-9_-]{1,40}$/', $id)) throw new ApiError('Choose a destination.', 422);
    if (!dest_find($id)) throw new ApiError('That destination no longer exists. Refresh the page.', 404);
    return $id;
}
