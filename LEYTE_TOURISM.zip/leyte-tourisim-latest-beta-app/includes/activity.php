<?php
// SCRUM-22: user activity and destination history, for the admin Activity page.
// data/activity.json keeps the newest ACT_MAX events: [{t, uid, type, dest}]. Types: view, favourite_add, favourite_remove, review, trip_save.
// It holds only an account id, what happened and which destination: no emails, no review text, no trip details.
// LOGGING MUST NEVER BREAK THE APP: every function here swallows its own errors (they go to the PHP error log).

const ACT_TYPES = ['view', 'favourite_add', 'favourite_remove', 'review', 'trip_save'];

function act_locked(callable $fn) {
    $lock = @fopen(ACT_FILE . '.lock', 'c');
    if (!$lock) return $fn();
    flock($lock, LOCK_EX);
    try { return $fn(); }
    finally { flock($lock, LOCK_UN); fclose($lock); }
}

function act_read(): array {
    $raw = @file_get_contents(ACT_FILE);
    if ($raw === false || trim($raw) === '') return [];
    $list = json_decode($raw, true);
    return is_array($list) ? array_values(array_filter($list, fn($e) => is_array($e) && isset($e['t'], $e['uid'], $e['type']))) : [];
}

function act_save(array $events): void {
    $json = json_encode(array_values($events), JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES) . "\n";
    $tmp = ACT_FILE . '.tmp' . getmypid();
    if (file_put_contents($tmp, $json) === false || !@rename($tmp, ACT_FILE)) {
        @unlink($tmp);
        file_put_contents(ACT_FILE, $json, LOCK_EX);
    }
}

// Records one event. Opening the same destination again within 30 seconds is not logged twice.
function act_log(string $uid, string $type, ?string $destId = null): void {
    if (!in_array($type, ACT_TYPES, true)) return;
    try {
        act_locked(function () use ($uid, $type, $destId) {
            $all = act_read();
            if ($type === 'view') {
                for ($i = count($all) - 1; $i >= 0 && $i >= count($all) - 20; $i--)
                    if ($all[$i]['uid'] === $uid && $all[$i]['type'] === 'view' && ($all[$i]['dest'] ?? null) === $destId && time() - (int)strtotime((string)$all[$i]['t']) < 30) return;
            }
            $all[] = ['t' => date('c'), 'uid' => $uid, 'type' => $type, 'dest' => $destId];
            if (count($all) > ACT_MAX) $all = array_slice($all, -ACT_MAX);
            act_save($all);
        });
    } catch (Throwable $e) { error_log('activity: ' . $e->getMessage()); }
}

// A deleted account takes its activity with it.
function act_delete_for_user(string $uid): void {
    if (!is_file(ACT_FILE)) return;
    try {
        act_locked(function () use ($uid) {
            $all = act_read();
            $keep = array_filter($all, fn($e) => $e['uid'] !== $uid);
            if (count($keep) !== count($all)) act_save($keep);
        });
    } catch (Throwable $e) { error_log('activity: ' . $e->getMessage()); }
}
