<?php
// Business Destination Requests.
// A business owner fills in the SAME destination fields the admin uses (js/dest-form.js on the page, dest_clean() here) and the request waits
// in data/destination-requests.json with status "pending". It is NOT in data/destinations.json, so it cannot appear on the public site,
// in category filters, on the map or in recommendations. Only an administrator's approval copies it into the live directory, through
// dest_insert(): the exact function the admin "Add destination" uses, so an approved request is an ordinary destination.
//
// Record: { id, ref, status: pending|approved|rejected, submitted, updated, ip (hash), contact: {name, email, phone},
//           dest: <output of dest_clean(): the destination fields, same names and types as a live destination>,
//           photo: {file, v} | null  (a file in data/request-photos/),
//           reviewedBy, reviewedAt, reason (rejections), destinationId (approvals) }
// Lock order: requests -> destinations (dest_insert takes its own lock). Nothing takes them the other way round.

function req_locked(callable $fn) {
    $lock = fopen(REQ_FILE . '.lock', 'c');
    if (!$lock) return $fn();
    flock($lock, LOCK_EX);
    try { return $fn(); }
    finally { flock($lock, LOCK_UN); fclose($lock); }
}

function req_read_raw(): array {
    $raw = @file_get_contents(REQ_FILE);
    if ($raw === false || trim($raw) === '') return [];
    $list = json_decode($raw, true);
    if (!is_array($list))
        throw new ApiError('data/destination-requests.json is damaged. Restore it from a backup.', 500);
    $out = [];
    foreach ($list as $r) if (is_array($r) && isset($r['id'])) $out[(string)$r['id']] = $r;
    return $out;
}

function req_save(array $all): void {
    $json = json_encode(array_values($all), JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES) . "\n";
    $tmp = REQ_FILE . '.tmp' . getmypid();
    if (file_put_contents($tmp, $json) === false || !@rename($tmp, REQ_FILE)) {
        @unlink($tmp);
        if (file_put_contents(REQ_FILE, $json, LOCK_EX) === false)
            throw new ApiError('Could not save the request. Check that the data folder is writable.', 500);
    }
}

function req_all(): array { return req_read_raw(); }

function req_count_pending(): int {
    $n = 0;
    try { foreach (req_read_raw() as $r) if (($r['status'] ?? '') === 'pending') $n++; } catch (Throwable $e) { error_log('requests: ' . $e->getMessage()); }
    return $n;
}

/* ---------- photos (data/request-photos/<id>-<stamp>.<ext>) ---------- */

function req_photo_path(array $r): ?string {
    $f = $r['photo']['file'] ?? null;
    if (!is_string($f) || !preg_match(IMG_FILE_RE, $f) || strpos($f, '..') !== false) return null;
    $p = REQ_PHOTO_DIR . '/' . $f;
    return is_file($p) ? $p : null;
}

function req_photo_store(string $id, array $photo): array {
    if (!preg_match('/^r[a-f0-9]{12}$/', $id) || !preg_match('/^[a-z0-9]{3,4}$/', $photo['ext'])) throw new ApiError('Invalid photo name.', 500);
    if (!is_dir(REQ_PHOTO_DIR) && !@mkdir(REQ_PHOTO_DIR, 0755, true)) throw new ApiError('Could not create the data/request-photos folder.', 500);
    $name = $id . '-' . dechex(time()) . bin2hex(random_bytes(2)) . '.' . $photo['ext'];
    $tmp = REQ_PHOTO_DIR . '/.upload-' . bin2hex(random_bytes(6)) . '.tmp';
    if (file_put_contents($tmp, $photo['bytes']) === false) { @unlink($tmp); throw new ApiError('Could not save the photo. Check that data/request-photos is writable.', 500); }
    @chmod($tmp, 0644);
    if (!@rename($tmp, REQ_PHOTO_DIR . '/' . $name)) { @unlink($tmp); throw new ApiError('Could not save the photo. Check that data/request-photos is writable.', 500); }
    return ['file' => $name, 'v' => time()];
}

function req_photo_remove(?array $photo): void {
    $f = $photo['file'] ?? null;
    if (is_string($f) && preg_match(IMG_FILE_RE, $f) && strpos($f, '..') === false) @unlink(REQ_PHOTO_DIR . '/' . $f);
}

// A stored request photo in the form img_prepare() returns, re-validated (type, size, no code) before it is ever copied to the live site.
function req_photo_prepared(array $r): ?array {
    $p = req_photo_path($r);
    if ($p === null) return null;
    $bytes = (string)file_get_contents($p);
    $mime = array_search(strtolower(pathinfo($p, PATHINFO_EXTENSION)), IMG_TYPES, true);
    if ($mime === false && strtolower(pathinfo($p, PATHINFO_EXTENSION)) === 'jpeg') $mime = 'image/jpeg';
    if ($mime === false) return null;
    return img_prepare('data:' . $mime . ';base64,' . base64_encode($bytes));
}

/* ---------- the owner's contact details (the ONLY fields that are not part of the destination) ---------- */

function req_clean_contact(array $in): array {
    $name = dest_text($in, 'contactName', 'your name', true, 100);
    if (mb_strlen($name) < 2) throw new ApiError('Enter your name.', 422);
    $email = clean_email(str_in($in, 'contactEmail'));
    $phone = dest_text($in, 'contactPhone', 'phone number', false, 30);
    if ($phone !== '' && !preg_match('/^[0-9+()\-\s.]{7,30}$/', $phone)) throw new ApiError('The phone number can only have digits, spaces, + ( ) - and periods.', 422);
    if (empty($in['confirm'])) throw new ApiError('Please confirm that you own this business or may submit it on its behalf.', 422);
    return ['name' => $name, 'email' => $email, 'phone' => $phone];
}

/* ---------- submit (public) ---------- */

function req_submit(array $in): array {
    // Hidden "website" field: people never see it, simple bots fill it. Answer as if it worked, store nothing.
    if (trim(str_in($in, 'website')) !== '') return ['ref' => 'BDR-' . date('Ymd') . '-' . strtoupper(bin2hex(random_bytes(3)))];

    $contact = req_clean_contact($in);
    $dest = dest_clean($in);                         // the SAME validation as the admin form: required fields, limits, categories that exist now, ...
    $photo = null;
    if (isset($in['photo']) && $in['photo'] !== '' && $in['photo'] !== null) {
        if (!is_string($in['photo'])) throw new ApiError('The photo could not be read.', 422);
        $photo = img_prepare($in['photo']);          // same photo rules as the admin form
    }
    $ip = hash('sha256', (string)($_SERVER['REMOTE_ADDR'] ?? '') . '|' . DB_FILE);   // not the address itself

    return req_locked(function () use ($dest, $contact, $photo, $ip) {
        $all = req_read_raw();
        $slug = dest_slug($dest['name']);
        $pending = 0; $recentIp = 0; $sameEmail = 0;
        foreach ($all as $r) {
            if (($r['status'] ?? '') !== 'pending') continue;
            $pending++;
            if (strcasecmp((string)($r['contact']['email'] ?? ''), $contact['email']) === 0) {
                $sameEmail++;
                if (dest_slug((string)($r['dest']['name'] ?? '')) === $slug) throw new ApiError('You already sent a request for "' . $dest['name'] . '". It is waiting for review.', 409);
            }
        }
        foreach ($all as $r) if (($r['ip'] ?? '') === $ip && time() - (int)strtotime((string)($r['submitted'] ?? '')) < 3600) $recentIp++;
        if ($recentIp >= REQ_PER_IP_HOUR) throw new ApiError('Too many requests from this connection. Please try again in an hour.', 429);
        if ($sameEmail >= REQ_PER_EMAIL) throw new ApiError('This email already has ' . REQ_PER_EMAIL . ' requests waiting for review. Please wait for a decision first.', 429);
        if ($pending >= REQ_MAX_PENDING) throw new ApiError('We cannot accept new requests right now. Please try again later.', 503);
        if (dest_slug_taken(dest_all(), $slug, null)) throw new ApiError('A destination named "' . $dest['name'] . '" is already listed.', 409);

        $id = 'r' . bin2hex(random_bytes(6));
        $ref = 'BDR-' . date('Ymd') . '-' . strtoupper(bin2hex(random_bytes(3)));
        $stored = $photo ? req_photo_store($id, $photo) : null;
        $now = date('c');
        $all[$id] = ['id' => $id, 'ref' => $ref, 'status' => 'pending', 'submitted' => $now, 'updated' => $now, 'ip' => $ip,
                     'contact' => $contact, 'dest' => $dest, 'photo' => $stored];
        try { req_save($all); }
        catch (Throwable $e) { req_photo_remove($stored); throw $e; }
        return ['ref' => $ref];
    });
}

/* ---------- what the admin screens get ---------- */

// 'destination' has exactly the shape of the admin Destinations API (dest_admin_view), so the shared form fills from it unchanged.
// Its 'image' is the request-photo URL (admin only), not a public photo URL.
function req_admin_view(array $r): array {
    $d = $r['dest'] ?? [];
    $d['image'] = req_photo_path($r) ? 'api/admin/request-photo.php?id=' . rawurlencode((string)$r['id']) . '&v=' . (int)($r['photo']['v'] ?? 0) : null;
    $d['slug'] = dest_slug((string)($d['name'] ?? ''));
    return [
        'id' => (string)$r['id'], 'ref' => (string)($r['ref'] ?? ''), 'status' => (string)($r['status'] ?? 'pending'),
        'submitted' => (string)($r['submitted'] ?? ''), 'updated' => (string)($r['updated'] ?? ''),
        'contact' => $r['contact'] ?? ['name' => '', 'email' => '', 'phone' => ''],
        'destination' => $d,
        'reviewedBy' => $r['reviewedBy'] ?? null, 'reviewedAt' => $r['reviewedAt'] ?? null,
        'reason' => (string)($r['reason'] ?? ''), 'destinationId' => $r['destinationId'] ?? null,
        'nameTaken' => ($r['status'] ?? '') === 'pending' && dest_slug_taken(dest_all(), dest_slug((string)($d['name'] ?? '')), null),
    ];
}

/* ---------- admin: correct, approve, reject ---------- */

function req_find_pending(array &$all, string $id): array {
    if (!isset($all[$id])) throw new ApiError('That request no longer exists. Refresh the list.', 404);
    if (($all[$id]['status'] ?? '') !== 'pending') throw new ApiError('That request was already ' . $all[$id]['status'] . '. Refresh the list.', 409);
    return $all[$id];
}

// Applies the administrator's corrections (same body the admin Add Destination form sends) to the stored request. Returns [record, newPhotoStoredOrNull].
function req_apply_edit(array &$all, string $id, array $in): array {
    $r = req_find_pending($all, $id);
    $r['dest'] = dest_clean($in);                    // the same validation again, on the corrected values
    $newPhoto = null; $oldPhoto = $r['photo'] ?? null;
    if (isset($in['photo']) && $in['photo'] !== '' && $in['photo'] !== null) {
        if (!is_string($in['photo'])) throw new ApiError('The photo could not be read.', 422);
        $newPhoto = req_photo_store($id, img_prepare($in['photo']));
        $r['photo'] = $newPhoto;
    } elseif (!empty($in['remove_photo'])) {
        $r['photo'] = null;
    }
    $r['updated'] = date('c');
    $all[$id] = $r;
    return [$r, $newPhoto, $oldPhoto];
}

function req_save_edit(string $id, array $in): array {
    return req_locked(function () use ($id, $in) {
        $all = req_read_raw();
        [$r, $newPhoto, $old] = req_apply_edit($all, $id, $in);
        try { req_save($all); } catch (Throwable $e) { req_photo_remove($newPhoto); throw $e; }
        if (($old['file'] ?? null) !== ($r['photo']['file'] ?? null)) req_photo_remove($old);
        return $r;
    });
}

// Approve = save the (possibly corrected) values, then add them to the live directory with dest_insert(): the same function and the same
// record format as the admin "Add destination". If the destination cannot be added (duplicate name, a category deleted meanwhile, ...)
// nothing changes and the request stays pending.
function req_approve(string $id, array $in, array $admin): array {
    return req_locked(function () use ($id, $in, $admin) {
        $all = req_read_raw();
        [$r, $newPhoto, $old] = req_apply_edit($all, $id, $in);
        $prepared = req_photo_prepared($r);          // null = no photo; a stored photo is re-validated before going live
        try { $rec = dest_insert($r['dest'], $prepared); }
        catch (Throwable $e) { req_photo_remove($newPhoto); throw $e; }   // nothing was saved: the request is untouched
        $r['status'] = 'approved'; $r['reviewedBy'] = $admin['email']; $r['reviewedAt'] = date('c'); $r['destinationId'] = $rec['id']; $r['updated'] = $r['reviewedAt'];
        $oldFile = $r['photo']['file'] ?? null;
        $r['photo'] = null;                          // the live destination has its own copy now
        $all[$id] = $r;
        try { req_save($all); }
        catch (Throwable $e) {
            try { dest_delete($rec['id']); } catch (Throwable $e2) { error_log('requests: could not undo an approval: ' . $e2->getMessage()); }   // keep the two files consistent
            req_photo_remove($newPhoto);
            throw $e;
        }
        req_photo_remove($old); if ($oldFile) req_photo_remove(['file' => $oldFile]);
        return [$r, $rec];
    });
}

function req_reject(string $id, string $reason, array $admin): array {
    $reason = trim(preg_replace('/\s+/u', ' ', $reason));
    if (mb_strlen($reason) > REQ_REASON_MAX) throw new ApiError('The reason must be ' . REQ_REASON_MAX . ' characters or fewer.', 422);
    if (preg_match('/[<>]/', $reason)) throw new ApiError("The reason can't contain the characters < or >.", 422);
    return req_locked(function () use ($id, $reason, $admin) {
        $all = req_read_raw();
        $r = req_find_pending($all, $id);
        $photo = $r['photo'] ?? null;
        $r['status'] = 'rejected'; $r['reason'] = $reason; $r['reviewedBy'] = $admin['email']; $r['reviewedAt'] = date('c'); $r['updated'] = $r['reviewedAt']; $r['photo'] = null;
        $all[$id] = $r;
        req_save($all);
        req_photo_remove($photo);
        return $r;
    });
}
