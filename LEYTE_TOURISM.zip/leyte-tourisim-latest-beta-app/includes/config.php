<?php
// Settings only.
const DB_FILE       = __DIR__ . '/../data/users.txt';   // temporary "database"
const THEMES        = ['light', 'dark'];
const DEFAULT_THEME = 'light';   // only used when a sign-up sends no valid theme (the site sends the one on screen)
const REMEMBER_DAYS = 30;
const RECENT_MAX    = 6;    // how many "Recently viewed" places are kept per account

// Allowed answers for the travel-preference questionnaire (match js/data.js)
// Categories are no longer a fixed list: they live in data/categories.json and are managed from admin/categories.html (see includes/categories.php).
const PREF_AREAS   = ['urban', 'rural', 'either'];
const PREF_TIMES   = ['morning', 'afternoon', 'evening'];
const PREF_BUDGETS = ['free', '50', '100', 'any'];
const PREF_TRIPS   = ['half', 'full', 'overnight'];

// OpenWeather (https://openweathermap.org/api). The key is NEVER sent to the browser: api/weather.php calls OpenWeather for you.
// Set it in ONE of these ways:  1) environment variable OPENWEATHER_API_KEY   2) copy includes/config.local.example.php to includes/config.local.php
const WEATHER_TTL        = 600;                                   // seconds a fetched reading is reused (saves your free-plan quota)
const WEATHER_RETRY      = 60;                                    // after a failed refresh (network, outage), wait this long before asking OpenWeather again
const WEATHER_RETRY_LONG = 300;                                   // same, after the key was rejected or the rate limit was hit
const WEATHER_MAX_AGE    = 3 * 3600;                              // stale readings are only served while at least one is newer than this; the website labels anything older
const WEATHER_DROP_AFTER = 86400;                                 // readings older than a day are never sent to the browser
const WEATHER_CACHE_FILE = __DIR__ . '/../data/weather-cache.json';
const OWM_ENDPOINT       = 'https://api.openweathermap.org/data/2.5/weather';
// SCRUM-16: local tourism data, managed from the admin module (admin/).
const DEST_FILE       = __DIR__ . '/../data/destinations.json';   // every destination record
const DEST_SEED_FILE  = __DIR__ . '/destinations.seed.json';      // the original 11 places, copied into DEST_FILE the first time it is needed
const DEST_TRASH_DIR  = __DIR__ . '/../data/deleted-photos';      // photos of deleted destinations are moved here, not destroyed
const PLACE_IMG_DIR   = __DIR__ . '/../images/places';            // photos; each destination's record names its file (image = {file, v}), see includes/destinations.php
const IMG_MAX_BYTES   = 3 * 1024 * 1024;                          // largest photo the admin may upload
const IMG_MAX_SIDE    = 8000;                                     // widest or tallest photo, in pixels
const IMG_TYPES       = ['image/jpeg' => 'jpg', 'image/png' => 'png', 'image/webp' => 'webp', 'image/avif' => 'avif'];   // allowed content types -> file extension we choose
const CAT_FILE        = __DIR__ . '/../data/categories.json';     // every tourism category (key, label, icon)
const CAT_SEED_FILE   = __DIR__ . '/categories.seed.json';        // the original 4 categories, copied into CAT_FILE the first time it is needed
const CAT_MAX         = 30;                                       // most categories the admin may create
const DEST_AREAS      = ['urban', 'rural'];
const DEST_VIEWS      = ['sunrise', 'sunset'];


// SCRUM-20: destination ratings and reviews. One JSON file (data/reviews.json) holds every review; see includes/reviews.php.
const REV_FILE        = __DIR__ . '/../data/reviews.json';
const REV_COMMENT_MAX = 1000;   // longest review text, in characters
const REV_LIST_MAX    = 50;     // newest reviews sent per destination (the average and the star counts always use every review)

// Sprint 4. SCRUM-21: favourites live on the account (users.txt). SCRUM-22: activity log. My Trip Plans: data/trips.json.
const FAV_MAX         = 100;                                // favourites kept per account
const ACT_FILE        = __DIR__ . '/../data/activity.json'; // newest ACT_MAX events, for the admin activity page (no emails, no passwords)
const ACT_MAX         = 2000;
const TRIP_FILE       = __DIR__ . '/../data/trips.json';    // every saved trip plan (each belongs to one account)
const TRIP_MAX_PER_USER = 50;
const TRIP_STOPS_MAX  = 8;
const TRIP_TITLE_MAX  = 80;
const TRIP_NOTES_MAX  = 1000;
const TRIP_ROAD_FACTOR = 1.4;                               // the estimate: straight line x 1.4 ...
const TRIP_AVG_KPH    = 40;                                 // ... at 40 km/h. The SAME numbers as ROAD_FACTOR / AVG_KPH in js/planner.js: the server re-checks every saved leg against them.

// Business Destination Requests: a business owner proposes a destination from the public form. It waits in its OWN file (never in DEST_FILE)
// until an administrator approves it; see includes/requests.php.
const REQ_FILE         = __DIR__ . '/../data/destination-requests.json';
const REQ_PHOTO_DIR    = __DIR__ . '/../data/request-photos';   // pending photos: inside data/, so they are not web-accessible
const REQ_MAX_PENDING  = 500;    // pending requests kept in total (stops the queue being flooded)
const REQ_PER_IP_HOUR  = 5;      // requests one network address may send per hour
const REQ_PER_EMAIL    = 5;      // pending requests one email address may have at the same time
const REQ_STATUSES     = ['pending', 'approved', 'rejected'];
const REQ_REASON_MAX   = 500;

if (is_file(__DIR__ . '/config.local.php')) require __DIR__ . '/config.local.php';
