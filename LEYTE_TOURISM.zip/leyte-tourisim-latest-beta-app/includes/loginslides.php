<?php
// Login page slideshow (the photos and caption card on the left side of login.html), managed from admin/settings.html.
// Same approach as destinations.php: one JSON file (data/login-slides.json), one lock around each read-modify-write, temp file + rename.
// Until an admin saves a change the file does not exist and the website keeps showing the original slideshow built into login.html.

const SLIDE_FILE    = __DIR__ . '/../data/login-slides.json';
const SLIDE_IMG_DIR = __DIR__ . '/../images/login';    // photos only (see images/login/.htaccess and router.php)
const SLIDE_MAX     = 8;                               // most slides the admin may have
const SLIDE_ID_RE   = '/^l[a-f0-9]{12}$/';

// The original four slides. "builtin" = which drawn scene of login.html is shown while a slide has no photo.
function slide_seed(): array {
    $src = [['Kalanggaman Island', 'Palompon', 'A white sandbar in clear water. Best at sunset.'],
            ['Lake Danao', 'Ormoc City', 'A mountain lake wrapped in morning mist.'],
            ['San Juanico Bridge', 'Tacloban City', 'Leyte meets Samar. Best at sunrise.'],
            ['Cuatro Islas', 'Inopacan', 'Island silhouettes at sunset.']];
    $out = [];
    foreach ($src as $i => [$t, $p, $x])
        $out[] = ['id' => sprintf('l%012x', $i + 1), 'builtin' => $i, 'title' => $t, 'place' => $p, 'text' => $x, 'image' => null];
    return $out;
}

function slide_locked(callable $fn) {
    $lock = fopen(SLIDE_FILE . '.lock', 'c');
    if (!$lock) return $fn();
    flock($lock, LOCK_EX);
    try { return $fn(); }
    finally { flock($lock, LOCK_UN); fclose($lock); }
}

// All slides in order. Never writes, so it is safe to call while holding the lock.
function slide_read(): array {
    if (!is_file(SLIDE_FILE)) return slide_seed();
    $list = json_decode((string)@file_get_contents(SLIDE_FILE), true);
    if (!is_array($list))   // a damaged file must stop the request: the next save would overwrite what is left
        throw new ApiError('data/login-slides.json is damaged. Restore it from a backup (or delete it to go back to the original slideshow).', 500);
    return array_values(array_filter($list, fn($s) => is_array($s) && isset($s['id']) && preg_match(SLIDE_ID_RE, (string)$s['id'])));
}

function slide_write(array $all): void {
    $json = json_encode(array_values($all), JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES) . "\n";
    $tmp = SLIDE_FILE . '.tmp' . getmypid();
    if (file_put_contents($tmp, $json) === false || !@rename($tmp, SLIDE_FILE)) {
        @unlink($tmp);
        if (file_put_contents(SLIDE_FILE, $json, LOCK_EX) === false)
            throw new ApiError('Could not save the slideshow. Check that the data folder is writable.', 500);
    }
}

function slide_image_url(array $s): ?string {
    $f = $s['image']['file'] ?? null;
    if (!is_string($f) || !preg_match(IMG_FILE_RE, $f) || strpos($f, '..') !== false || !is_file(SLIDE_IMG_DIR . '/' . $f)) return null;
    return 'images/login/' . rawurlencode($f) . '?v=' . ((int)($s['image']['v'] ?? 0) ?: (int)@filemtime(SLIDE_IMG_DIR . '/' . $f));
}

function slide_view(array $s): array {
    $b = $s['builtin'] ?? null;
    return ['id' => $s['id'], 'title' => (string)($s['title'] ?? ''), 'place' => (string)($s['place'] ?? ''), 'text' => (string)($s['text'] ?? ''),
            'image' => slide_image_url($s), 'builtin' => is_int($b) && $b >= 0 && $b <= 3 ? $b : null];
}

function slide_store(string $bytes, string $ext): string {
    if (!preg_match('/^[a-z0-9]{3,4}$/', $ext)) throw new ApiError('Invalid photo name.', 500);
    if (!is_dir(SLIDE_IMG_DIR) && !@mkdir(SLIDE_IMG_DIR, 0755, true)) throw new ApiError('Could not create the images/login folder.', 500);
    $name = 'slide-' . dechex(time()) . bin2hex(random_bytes(3)) . '.' . $ext;
    $tmp = SLIDE_IMG_DIR . '/.upload-' . bin2hex(random_bytes(6)) . '.tmp';
    if (file_put_contents($tmp, $bytes) === false) { @unlink($tmp); throw new ApiError('Could not save the photo. Check that images/login is writable.', 500); }
    @chmod($tmp, 0644);
    if (!@rename($tmp, SLIDE_IMG_DIR . '/' . $name)) { @unlink($tmp); throw new ApiError('Could not save the photo. Check that images/login is writable.', 500); }
    return $name;
}

// Deletes a photo file that no slide points at any more.
function slide_release(?string $file, array $all): void {
    if (!$file || !preg_match(IMG_FILE_RE, $file) || strpos($file, '..') !== false) return;
    foreach ($all as $s) if (($s['image']['file'] ?? null) === $file) return;
    @unlink(SLIDE_IMG_DIR . '/' . $file);
}

function slide_clean(array $in): array {
    return ['title' => dest_text($in, 'title', 'The title', true, 60),
            'place' => dest_text($in, 'place', 'The place', false, 60),
            'text'  => dest_text($in, 'text', 'The description', false, 140)];
}

// Creates (no id) or updates (id) one slide. $photo = img_prepare() result or null; $removePhoto clears the photo.
function slide_save(string $id, array $d, ?array $photo, bool $removePhoto): array {
    return slide_locked(function () use ($id, $d, $photo, $removePhoto) {
        $all = slide_read();
        $newFile = $photo ? slide_store($photo['bytes'], $photo['ext']) : null;
        try {
            if ($id === '') {
                if (count($all) >= SLIDE_MAX) throw new ApiError('The slideshow can have at most ' . SLIDE_MAX . ' slides. Delete one first.', 409);
                $rec = ['id' => 'l' . bin2hex(random_bytes(6)), 'builtin' => null] + $d + ['image' => null];
                if ($newFile) $rec['image'] = ['file' => $newFile, 'v' => time()];
                $all[] = $rec; $oldFile = null;
            } else {
                $i = array_search($id, array_column($all, 'id'), true);
                if ($i === false) throw new ApiError('That slide no longer exists. Reload the page.', 404);
                $oldFile = $all[$i]['image']['file'] ?? null;
                $rec = $d + $all[$i];
                if ($newFile) $rec['image'] = ['file' => $newFile, 'v' => time()];
                elseif ($removePhoto) $rec['image'] = null;
                $all[$i] = $rec;
            }
            slide_write($all);
        } catch (Throwable $e) { if ($newFile) @unlink(SLIDE_IMG_DIR . '/' . $newFile); throw $e; }   // the old photo is still in place
        if ($newFile || $removePhoto) slide_release($oldFile, $all);
        return $rec;
    });
}

function slide_delete(string $id): array {
    return slide_locked(function () use ($id) {
        $all = slide_read();
        $i = array_search($id, array_column($all, 'id'), true);
        if ($i === false) throw new ApiError('That slide no longer exists. Reload the page.', 404);
        if (count($all) <= 1) throw new ApiError('The slideshow needs at least one slide.', 409);
        [$old] = array_splice($all, $i, 1);
        slide_write($all);
        slide_release($old['image']['file'] ?? null, $all);
        return $old;
    });
}

function slide_move(string $id, string $dir): void {
    slide_locked(function () use ($id, $dir) {
        $all = slide_read();
        $i = array_search($id, array_column($all, 'id'), true);
        if ($i === false) throw new ApiError('That slide no longer exists. Reload the page.', 404);
        $j = $dir === 'up' ? $i - 1 : $i + 1;
        if ($j < 0 || $j >= count($all)) return;
        [$all[$i], $all[$j]] = [$all[$j], $all[$i]];
        slide_write($all);
    });
}
