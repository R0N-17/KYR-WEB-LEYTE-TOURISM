// Compares the destination form field by field across:  (1) Admin > Destinations > Add destination,  (2) the public Business Destination Request,
// (3) the admin review page for a request.  Needs: node, php, and the `playwright` npm package with a Chromium.
//   node tools/form-parity-test.js [path-to-an-ORIGINAL-copy-of-the-project]
// With a path it also compares against that copy's admin Add destination form (the form before the shared js/dest-form.js existed),
// proving the admin form was not changed. Works on throw-away copies with EMPTY data; it never touches your data.
const fs = require('fs'), os = require('os'), path = require('path'), { spawn, execFileSync } = require('child_process');
let chromium; try { ({ chromium } = require('playwright')); } catch (e) { ({ chromium } = require('/opt/npm-tools/node_modules/playwright')); }

const root = path.resolve(__dirname, '..');
const orig = process.argv[2] ? path.resolve(process.argv[2]) : null;
let pass = 0, fail = 0;
const check = (name, ok, extra) => { ok ? pass++ : fail++; console.log((ok ? 'PASS  ' : 'FAIL  ') + name + (!ok && extra ? '  [' + extra + ']' : '')); };

async function serve(src) {
  const tmp = fs.mkdtempSync(path.join(os.tmpdir(), 'kyr-parity-'));
  fs.cpSync(src, tmp, { recursive: true, filter: p => !p.includes(path.sep + '.git') });
  for (const f of fs.readdirSync(tmp + '/data')) if (f !== '.htaccess') fs.rmSync(path.join(tmp, 'data', f), { recursive: true, force: true });
  for (const f of fs.readdirSync(tmp + '/images/places')) if (/\.(jpe?g|png|webp|avif)$/i.test(f)) fs.rmSync(path.join(tmp, 'images/places', f));
  execFileSync('php', ['-r', `require '${tmp}/includes/config.php'; require '${tmp}/includes/response.php'; require '${tmp}/includes/db.php';
    db_insert(['id'=>'parityadmin000001','first_name'=>'Parity','last_name'=>'Admin','email'=>'admin@example.com','password'=>password_hash('Passw0rd!x',PASSWORD_DEFAULT),'theme'=>'light','prefs'=>null,'recent'=>[],'role'=>'admin','created'=>date('c')]);`]);
  const port = 20000 + Math.floor(Math.random() * 20000);
  const proc = spawn('php', ['-S', '127.0.0.1:' + port, 'router.php'], { cwd: tmp, stdio: 'ignore' });
  for (let i = 0; i < 50; i++) { try { await fetch(`http://127.0.0.1:${port}/login.html`); break; } catch (e) { await new Promise(r => setTimeout(r, 100)); } }
  return { tmp, port, base: `http://127.0.0.1:${port}`, stop: () => { proc.kill(); fs.rmSync(tmp, { recursive: true, force: true }); } };
}

// Everything a person can see or that decides validation, for every field, in page order.
const describe = () => [...document.querySelectorAll('#destForm section.ad-fsec')].map(sec => ({
  section: sec.querySelector('h3').textContent.replace(/\s+/g, ' ').trim(),
  sectionHelp: (sec.querySelector('.ad-fsec-head p') || {}).textContent,
  fields: [...sec.querySelectorAll('input, select, textarea')].filter(e => e.type !== 'hidden').map(e => {
    const lab = e.id && document.querySelector(`label[for="${e.id}"]`);
    const col = e.closest('[class*="col-"]') || e.parentElement;
    return {
      id: e.id || e.name, tag: e.tagName.toLowerCase(), type: e.type, name: e.name || '',
      label: lab ? lab.textContent.replace(/\s+/g, ' ').trim() : '',
      required: e.required || (lab ? lab.classList.contains('req') : false) || (document.getElementById(e.getAttribute('aria-labelledby') || '') || { classList: { contains: () => false } }).classList.contains('req'),
      min: e.getAttribute('min'), max: e.getAttribute('max'), step: e.getAttribute('step'), maxlength: e.getAttribute('maxlength'), placeholder: e.getAttribute('placeholder'), accept: e.getAttribute('accept'),
      options: e.tagName === 'SELECT' ? [...e.options].map(o => o.value + '=' + o.textContent.trim()) : undefined,
      help: [...col.querySelectorAll('.form-text, .invalid-feedback')].map(x => x.textContent.trim()).join(' | '),
    };
  }),
}));
// The checkbox groups (categories, times) are drawn from data: list the options too.
const groups = () => Object.fromEntries(['fCats', 'fTimes'].map(id => [id, [...document.querySelectorAll(`#${id} input`)].map(i => i.value + '=' + i.nextElementSibling.textContent.trim())]));

(async () => {
  const browser = await chromium.launch();
  const servers = [], results = {};
  try {
    const cur = await serve(root); servers.push(cur);
    const ctx = await browser.newContext(); const page = await ctx.newPage();
    const errors = []; page.on('pageerror', e => errors.push(String(e)));
    const login = async (s, c) => { const r = await c.request.post(s.base + '/api/admin/login.php', { data: { email: 'admin@example.com', password: 'Passw0rd!x' } }); return (await r.json()).ok; };
    check('admin sign-in works on the copy', await login(cur, ctx));

    // 1. admin Add destination (current)
    await page.goto(cur.base + '/admin/destinations.html'); await page.click('#addBtn'); await page.waitForSelector('#formModal.show #fName');
    results.admin = { form: await page.evaluate(describe), groups: await page.evaluate(groups) };
    // 2. public request form
    const pub = await ctx.newPage(); pub.on('pageerror', e => errors.push(String(e)));
    await pub.goto(cur.base + '/business-request.html'); await pub.waitForSelector('#fCats input');
    results.pub = { form: await pub.evaluate(describe), groups: await pub.evaluate(groups) };
    // 3. admin review (needs one request)
    const r = await ctx.request.post(cur.base + '/api/destination-request.php', { data: { name: 'Parity Place', town: 'Palo', area: 'urban', hours: '8-5', cats: [results.admin.groups.fCats[0].split('=')[0]], feeAmt: 0, blurb: 'b', about: 'a', lat: 11.1, lng: 124.9, contactName: 'Owner Name', contactEmail: 'o@example.com', confirm: true } });
    check('a request can be sent for the review page', (await r.json()).ok === true);
    const rev = await ctx.newPage(); rev.on('pageerror', e => errors.push(String(e)));
    await rev.goto(cur.base + '/admin/requests.html'); await rev.click('#rows button[data-id]'); await rev.waitForSelector('#formModal.show #fName');
    results.review = { form: await rev.evaluate(describe), groups: await rev.evaluate(groups) };
    check('no script errors on any of the three pages', errors.length === 0, errors.join(' ; '));

    // 0. original admin form (before the refactor)
    if (orig) {
      const o = await serve(orig); servers.push(o);
      const octx = await browser.newContext(); const op = await octx.newPage();
      check('admin sign-in works on the original copy', await login(o, octx));
      await op.goto(o.base + '/admin/destinations.html'); await op.click('#addBtn'); await op.waitForSelector('#formModal.show #fName');
      results.original = { form: await op.evaluate(describe), groups: await op.evaluate(groups) };
    }

    // The public form adds ONE extra block after the destination fields: "Your details" (the owner's contact). Those fields are the only ones not in the admin form.
    const OWNER = 'Your details';
    const strip = f => ({ ...f, form: f.form.filter(s => s.section !== OWNER) });
    const flat = f => f.form.flatMap(s => s.fields.map(x => ({ ...x, section: s.section })));
    const same = (a, b) => JSON.stringify(a) === JSON.stringify(b);
    const diffs = (a, b) => { const out = []; const fa = flat(a), fb = flat(b); const ids = [...new Set([...fa, ...fb].map(x => x.id))];
      for (const id of ids) { const x = fa.find(f => f.id === id), y = fb.find(f => f.id === id); if (!x || !y) { out.push(`${id}: only in ${x ? 'admin form' : 'request form'}`); continue; }
        for (const k of Object.keys(x)) if (!same(x[k], y[k])) out.push(`${id}.${k}: ${JSON.stringify(x[k])} vs ${JSON.stringify(y[k])}`); }
      return out; };
    const order = f => flat(f).map(x => x.id).join(',');
    const heads = f => f.form.map(s => [s.section, s.sectionHelp]);

    if (results.original) {
      const d = diffs(results.original, results.admin);
      check('ADMIN Add destination is unchanged: every field, label, type, limit, option and help text identical to the original', d.length === 0 && same(results.original.groups, results.admin.groups) && same(heads(results.original), heads(results.admin)), d.join('\n'));
      check('ADMIN Add destination: same field order as the original', order(results.original) === order(results.admin));
    }
    const owner = results.pub.form.find(s => s.section === OWNER);
    check('REQUEST form: "Your details" is the only extra section and it comes after all destination sections', !!owner && results.pub.form[results.pub.form.length - 1] === owner);
    const pubDest = strip(results.pub);
    check('REQUEST form has the same sections (titles and help text) in the same order as the admin form', same(heads(results.admin), heads(pubDest)));
    const d2 = diffs(results.admin, pubDest).filter(x => !/^(nLabel|nOutdoor)/.test(x));
    console.log('\nField differences between the admin form and the public request form, excluding the admin-only "New category" box:'); d2.forEach(x => console.log('   - ' + x)); console.log(d2.length ? '' : '   (none)\n');
    check('REQUEST form: same fields, labels, input types, required marks, limits, options and help texts as the admin form', d2.length === 0, d2.join('\n'));
    check('REQUEST form: same field order as the admin form', order(pubDest) === order(results.admin).split(',').filter(i => !['nLabel', 'nOutdoor'].includes(i)).join(','));
    check('REQUEST form offers the same categories and times as the admin form', same(results.admin.groups, results.pub.groups), JSON.stringify([results.admin.groups, results.pub.groups]));
    const d3 = diffs(results.admin, results.review);
    check('REVIEW page form is identical to the admin Add destination form (same definition, admin mode)', d3.length === 0 && order(results.admin) === order(results.review) && same(heads(results.admin), heads(results.review)), d3.join('\n'));
  } finally { await browser.close(); servers.forEach(s => s.stop()); }
  console.log(`\n${pass} passed, ${fail} failed`); process.exit(fail ? 1 : 0);
})().catch(e => { console.error(e); process.exit(2); });
