<?php
// KYR Web Tourism: integration self-test for the REAL PHP backend. Command line only.
//
//   php tools/selftest.php
//
// It never touches your real data. It copies the project into a temporary folder with EMPTY data (the app seeds its own
// destinations and categories from includes/*.seed.json), starts PHP's built-in web server on that copy, and exercises the real
// endpoints over HTTP: public reads, registration, sessions, admin authorization, destination create / update / delete,
// photo upload and rejection, category rules, logout. Needs PHP 8.1+ with the json, fileinfo and gd (or getimagesize) extensions the app already uses.
// Exit code 0 = everything passed.
if (PHP_SAPI !== 'cli') { http_response_code(403); exit('Command line only.'); }
// Environment preflight: a missing PHP extension is a server setup problem, not an application failure. Say so and stop before any test runs.
if (PHP_VERSION_ID < 80100) { fwrite(STDERR, "ENVIRONMENT: PHP 8.1 or newer is required (this is " . PHP_VERSION . "). No tests were run.\n"); exit(2); }
foreach (['json', 'mbstring', 'fileinfo'] as $__ext) if (!extension_loaded($__ext)) { fwrite(STDERR, "ENVIRONMENT: the PHP '$__ext' extension is not enabled, so the tests cannot run. This is not an application failure. Enable it and run again.\n"); exit(2); }

$src = realpath(__DIR__ . '/..');
$tmp = sys_get_temp_dir() . '/kyr-selftest-' . bin2hex(random_bytes(4));
$pass = 0; $fail = 0; $server = null;

function check(string $name, bool $ok, string $extra = ''): void {
    global $pass, $fail;
    if ($ok) { $pass++; echo "PASS  $name\n"; } else { $fail++; echo "FAIL  $name" . ($extra !== '' ? "  [$extra]" : '') . "\n"; }
}
function copy_tree(string $from, string $to): void {
    @mkdir($to, 0777, true);
    foreach (new DirectoryIterator($from) as $f) {
        if ($f->isDot()) continue;
        $name = $f->getFilename();
        if ($name === '.git') continue;
        $target = $to . '/' . $name;
        if ($f->isDir()) copy_tree($f->getPathname(), $target); else copy($f->getPathname(), $target);
    }
}
function rm_tree(string $dir): void {
    if (!is_dir($dir)) return;
    foreach (new DirectoryIterator($dir) as $f) {
        if ($f->isDot()) continue;
        $f->isDir() ? rm_tree($f->getPathname()) : @unlink($f->getPathname());
    }
    @rmdir($dir);
}
function cleanup(): void { global $server, $tmp; if (is_resource($server)) { proc_terminate($server); proc_close($server); } rm_tree($tmp); }
register_shutdown_function('cleanup');

// ---- set up the scratch copy: code + images, but no users and no data files ----
copy_tree($src, $tmp);
foreach (glob($tmp . '/data/*') ?: [] as $f) if (basename($f) !== '.htaccess') { is_dir($f) ? rm_tree($f) : @unlink($f); }
foreach (glob($tmp . '/images/places/*') ?: [] as $f) if (is_file($f)) @unlink($f);   // the seed's one photo is irrelevant to these tests

$port = random_int(20000, 40000);
$logFile = sys_get_temp_dir() . '/kyr-selftest-server-' . basename($tmp) . '.log';   // unique per run: a fixed name left behind by another user in a shared temp folder made the log unwritable
$desc = [1 => ['file', $logFile, 'w'], 2 => ['file', $logFile, 'a']];
$server = proc_open([PHP_BINARY, '-S', "127.0.0.1:$port", 'router.php'], $desc, $pipes, $tmp);
$base = "http://127.0.0.1:$port";
for ($i = 0; $i < 50; $i++) { if (@fsockopen('127.0.0.1', $port, $e, $s, 0.2)) break; usleep(100000); }

// ---- tiny HTTP client with a cookie jar per "browser" ----
function http(string $method, string $url, ?array $json, array &$jar, bool $raw = false): array {
    $headers = "Accept: application/json\r\n";
    if ($jar) $headers .= 'Cookie: ' . implode('; ', array_map(fn($k, $v) => "$k=$v", array_keys($jar), $jar)) . "\r\n";
    $opts = ['method' => $method, 'ignore_errors' => true, 'header' => $headers, 'follow_location' => 0];
    if ($json !== null) { $opts['content'] = json_encode($json); $opts['header'] .= "Content-Type: application/json\r\n"; }
    $body = @file_get_contents($url, false, stream_context_create(['http' => $opts]));
    $status = 0;
    foreach ($http_response_header ?? [] as $h) {
        if (preg_match('#^HTTP/\S+\s+(\d+)#', $h, $m)) $status = (int)$m[1];
        if (stripos($h, 'Set-Cookie:') === 0 && preg_match('/Set-Cookie:\s*([^=]+)=([^;]*)/i', $h, $m)) { if ($m[2] === 'deleted' || $m[2] === '') unset($jar[$m[1]]); else $jar[$m[1]] = $m[2]; }
    }
    return ['status' => $status, 'body' => $body === false ? '' : $body, 'json' => $raw ? null : json_decode((string)$body, true)];
}
function post(string $path, array $json, array &$jar): array { global $base; return http('POST', $base . $path, $json, $jar); }

$anon = []; $user = []; $admin = []; $other = [];

// ---- 1. public pages and public reads ----
check('login page is served', http('GET', "$base/login.html", null, $anon, true)['status'] === 200);
check('admin sign-in page is served', http('GET', "$base/admin/login.html", null, $anon, true)['status'] === 200);
check('data files are not downloadable', http('GET', "$base/data/users.txt", null, $anon, true)['status'] >= 400);
check('includes are not downloadable', http('GET', "$base/includes/config.php", null, $anon, true)['status'] >= 400);
$r = post('/api/destinations.php', [], $anon);
check('public destinations load from the real endpoint (seeded on first use)', ($r['json']['ok'] ?? false) && count($r['json']['places'] ?? []) >= 11, $r['body']);
$p0 = $r['json']['places'][0] ?? [];
check('public destination has the expected fields and NO manual weather', isset($p0['name'], $p0['town'], $p0['cats'], $p0['time'], $p0['stay']) && !array_key_exists('weather', $p0));
$r = post('/api/categories.php', [], $anon);
$catKeys = array_column($r['json']['categories'] ?? [], 'key');
check('categories load and are seeded', count($catKeys) >= 4, $r['body']);
check('weather endpoint refuses anonymous visitors', post('/api/weather.php', [], $anon)['status'] === 401);

// ---- 2. registration, sessions, ordinary user cannot use admin endpoints ----
$r = post('/api/register.php', ['first_name' => 'Test', 'last_name' => 'User', 'email' => 'user@example.com', 'password' => 'Passw0rd!x', 'role' => 'admin'], $user);
check('registration works', ($r['json']['ok'] ?? false) === true, $r['body']);
check('registration cannot grant admin (role field ignored)', ($r['json']['user']['role'] ?? 'user') !== 'admin');
check('ordinary user: a sign-up that sends no theme gets Light', ($r['json']['user']['theme'] ?? '') === 'light', $r['body']);
check('session works (me.php)', (post('/api/me.php', [], $user)['json']['ok'] ?? false) === true);
foreach (['admin/destinations.php', 'admin/destination-save.php', 'admin/destination-delete.php', 'admin/categories.php', 'admin/category-save.php', 'admin/category-delete.php', 'admin/stats.php', 'admin/me.php'] as $ep) {
    check("ordinary user gets 403 from api/$ep", post("/api/$ep", ['name' => 'x'], $user)['status'] === 403);
    check("anonymous visitor gets 401 from api/$ep", post("/api/$ep", ['name' => 'x'], $anon)['status'] === 401);
}
check('theme can be saved as "dark"', (post('/api/theme.php', ['theme' => 'dark'], $user)['json']['ok'] ?? false) === true);
check('"system" and "auto" are no longer accepted themes', (post('/api/theme.php', ['theme' => 'system'], $user)['json']['ok'] ?? true) === false && (post('/api/theme.php', ['theme' => 'auto'], $user)['json']['ok'] ?? true) === false);
check('an unknown theme is rejected', (post('/api/theme.php', ['theme' => 'neon'], $user)['json']['ok'] ?? true) === false);

// ---- 3. administrator (created the same way tools/make-admin.php does) ----
require $tmp . '/includes/config.php';
require $tmp . '/includes/response.php';
require $tmp . '/includes/db.php';
db_insert(['id' => 'selftestadmin0001', 'first_name' => 'Self', 'last_name' => 'Test', 'email' => 'admin@example.com',
           'password' => password_hash('Passw0rd!x', PASSWORD_DEFAULT), 'theme' => 'light', 'prefs' => null, 'recent' => [], 'role' => 'admin', 'created' => date('c')]);
check('admin sign-in rejects a wrong password', post('/api/admin/login.php', ['email' => 'admin@example.com', 'password' => 'wrong'], $other)['status'] === 401);
check('admin sign-in rejects an ordinary user', post('/api/admin/login.php', ['email' => 'user@example.com', 'password' => 'Passw0rd!x'], $other)['status'] === 401);
$r = post('/api/admin/login.php', ['email' => 'admin@example.com', 'password' => 'Passw0rd!x'], $admin);
check('admin sign-in works', ($r['json']['ok'] ?? false) === true, $r['body']);
check('admin sees the destination list', count(post('/api/admin/destinations.php', [], $admin)['json']['destinations'] ?? []) >= 11);
$r = post('/api/admin/stats.php', [], $admin);
check('admin stats are available', ($r['json']['ok'] ?? false) === true && isset($r['json']['stats']['cats']));
$r = post('/api/admin/me.php', [], $admin);   // Settings page: account information
check('settings: me.php returns the signed-in administrator only', ($r['json']['admin']['email'] ?? '') === 'admin@example.com' && ($r['json']['admin']['first_name'] ?? '') === 'Self');
check('settings: me.php never exposes the password hash or id', !isset($r['json']['admin']['password']) && !isset($r['json']['admin']['id']) && !str_contains($r['body'], '$2y$'));
check('settings page is served', http('GET', "$base/admin/settings.html", null, $anon, true)['status'] === 200);

// ---- 4. destination CRUD ----
$base_dest = ['name' => 'Selftest Cove', 'town' => 'Palo', 'blurb' => 'A test place.', 'about' => 'Created by tools/selftest.php.', 'hours' => '8:00 AM - 5:00 PM',
              'feeAmt' => 25, 'area' => 'rural', 'cats' => [$catKeys[0]], 'lat' => 11.15, 'lng' => 124.99, 'time' => [], 'stay' => ['overnight']];   // 'stay' is sent on purpose: the admin no longer edits it, so it must be ignored
$r = post('/api/admin/destination-save.php', $base_dest, $admin);
check('create destination with no suggested time (optional); a stray visit length is ignored', ($r['json']['ok'] ?? false) === true, $r['body']);
$id = $r['json']['destination']['id'] ?? '';
$pub = array_values(array_filter(post('/api/destinations.php', [], $anon)['json']['places'] ?? [], fn($p) => $p['name'] === 'Selftest Cove'));
check('new destination is visible to the public site at once', count($pub) === 1 && $pub[0]['time'] === [] && $pub[0]['stay'] === [], json_encode($pub));
check('the admin record has no visit length either', !isset($r['json']['destination']['stay']) || $r['json']['destination']['stay'] === [], $r['body']);
check('a duplicate name is rejected (409)', post('/api/admin/destination-save.php', $base_dest, $admin)['status'] === 409);
check('a request with only a name is rejected (required fields)', (post('/api/admin/destination-save.php', ['name' => 'Incomplete'], $admin)['json']['ok'] ?? true) === false);
$bad = $base_dest; $bad['name'] = 'Bad Coords'; $bad['lat'] = 123;
check('invalid latitude is rejected', (post('/api/admin/destination-save.php', $bad, $admin)['json']['ok'] ?? true) === false);
$bad = $base_dest; $bad['name'] = 'Bad Cat'; $bad['cats'] = ['no-such-category'];
check('an unknown category is rejected', (post('/api/admin/destination-save.php', $bad, $admin)['json']['ok'] ?? true) === false);
$upd = $base_dest; $upd['id'] = $id; $upd['blurb'] = 'Updated blurb.'; $upd['time'] = ['morning'];
$r = post('/api/admin/destination-save.php', $upd, $admin);
check('update destination', ($r['json']['ok'] ?? false) === true, $r['body']);
$pub = array_values(array_filter(post('/api/destinations.php', [], $anon)['json']['places'] ?? [], fn($p) => $p['name'] === 'Selftest Cove'));
check('update is visible publicly, including optional guidance', ($pub[0]['blurb'] ?? '') === 'Updated blurb.' && ($pub[0]['time'] ?? []) === ['morning']);
// Existing visit-length data must survive an admin edit (the form no longer shows it, but recommendations still use it).
$list = post('/api/admin/destinations.php', [], $admin)['json']['destinations'] ?? [];
$seeded = array_values(array_filter($list, fn($d) => !empty($d['stay'])))[0] ?? null;
check('seeded destinations still carry their stored visit length', $seeded !== null);
if ($seeded) {
    $form = array_intersect_key($seeded, array_flip(['id', 'name', 'town', 'area', 'view', 'hours', 'cats', 'time', 'feeAmt', 'fee', 'facilities', 'blurb', 'about', 'highlights', 'best', 'getThere', 'tip', 'lat', 'lng']));
    $form['blurb'] = 'Edited by the self-test.';
    $r = post('/api/admin/destination-save.php', $form, $admin);
    $pubSeed = array_values(array_filter(post('/api/destinations.php', [], $anon)['json']['places'] ?? [], fn($p) => $p['id'] === $seeded['id']))[0] ?? [];
    check('editing a destination in the admin keeps its stored visit length', ($r['json']['ok'] ?? false) && ($pubSeed['stay'] ?? null) === $seeded['stay'] && $pubSeed['blurb'] === 'Edited by the self-test.', $r['body']);
}
check('no destination carries sample weather (admin list)', !array_filter($list, fn($d) => array_key_exists('weather', $d)));
check('the destination data file is still valid JSON after writes', is_array(json_decode((string)file_get_contents($tmp . '/data/destinations.json'), true)));

// ---- 5. photo upload ----
$png = 'data:image/png;base64,' . base64_encode(base64_decode('iVBORw0KGgoAAAANSUhEUgAAAAgAAAAGCAYAAADQ5d+PAAAAJ0lEQVR4nGP8z8Dwn4EIwESMolGFxCs8Pn7+f2KsZGCgP0ymoYB4RQBe5g8JeGfcigAAAABJRU5ErkJggg=='));
$withPhoto = $upd; $withPhoto['photo'] = $png;
$r = post('/api/admin/destination-save.php', $withPhoto, $admin);
check('upload a real PNG photo', ($r['json']['ok'] ?? false) === true, $r['body']);
$img1 = $r['json']['destination']['image'] ?? null;
check('photo URL is versioned and the file exists', is_string($img1) && str_contains($img1, '?v=') && is_file($tmp . '/' . explode('?', $img1)[0]), (string)$img1);
$pub = array_values(array_filter(post('/api/destinations.php', [], $anon)['json']['places'] ?? [], fn($p) => $p['name'] === 'Selftest Cove'));
check('public site returns the same photo URL', ($pub[0]['image'] ?? null) === $img1);
foreach ([['text/plain', "<?php echo 'x';"], ['image/png', "GIF89a<?php system('id'); ?>"], ['image/jpeg', 'not an image at all']] as [$mime, $bytes]) {
    $evil = $upd; $evil['photo'] = "data:$mime;base64," . base64_encode($bytes);
    $r = post('/api/admin/destination-save.php', $evil, $admin);
    check("fake photo ($mime, " . substr($bytes, 0, 12) . '...) is rejected', ($r['json']['ok'] ?? true) === false, $r['body']);
}
$r = post('/api/destinations.php', [], $anon);
$pub = array_values(array_filter($r['json']['places'] ?? [], fn($p) => $p['name'] === 'Selftest Cove'));
check('a rejected upload leaves the existing photo untouched', ($pub[0]['image'] ?? null) === $img1);
$exe = glob($tmp . '/images/places/*.{php,phtml,html,js}', GLOB_BRACE) ?: [];
check('no executable file was written into images/places', count($exe) === 0, implode(',', $exe));
$withPhoto2 = $upd; $withPhoto2['photo'] = $png . '';
$r = post('/api/admin/destination-save.php', $withPhoto2, $admin);
$img2 = $r['json']['destination']['image'] ?? null;
check('replacing the photo changes the version/URL (cache busting)', is_string($img2) && $img2 !== $img1, "$img1 -> $img2");

// ---- 6. categories ----
$r = post('/api/admin/category-save.php', ['label' => 'Selftest Cat', 'icon' => 'bi-star'], $admin);
check('create category', ($r['json']['ok'] ?? false) === true, $r['body']);
$ckey = $r['json']['category']['key'] ?? '';
check('duplicate category rejected', post('/api/admin/category-save.php', ['label' => 'Selftest Cat', 'icon' => 'bi-star'], $admin)['status'] === 409);
check('duplicate category rejected, different capitals and spacing', post('/api/admin/category-save.php', ['label' => '  selftest   CAT ', 'icon' => 'bi-star'], $admin)['status'] === 409);
$assign = $upd; $assign['cats'] = [$catKeys[0], $ckey]; unset($assign['photo']);
post('/api/admin/destination-save.php', $assign, $admin);
check('deleting a category still in use is refused without a target', (post('/api/admin/category-delete.php', ['key' => $ckey], $admin)['json']['ok'] ?? true) === false);
$r = post('/api/admin/category-delete.php', ['key' => $ckey, 'move_to' => $catKeys[0]], $admin);
check('deleting with a target moves destinations', ($r['json']['ok'] ?? false) === true, $r['body']);
$r = post('/api/admin/category-save.php', ['label' => 'Unused', 'icon' => 'bi-x'], $admin);
check('an unused category deletes cleanly', (post('/api/admin/category-delete.php', ['key' => $r['json']['category']['key'] ?? ''], $admin)['json']['ok'] ?? false) === true);

// ---- 7. weather (works with or without an OpenWeather key) ----
$w = post('/api/weather.php', [], $user);
check('weather endpoint answers a signed-in user with ok:true or a clear message (never a crash)', isset($w['json']['ok']) && ($w['json']['ok'] === true || is_string($w['json']['message'] ?? null)), $w['body']);
$sv = post('/api/admin/destination-save.php', $upd, $admin);
check('saving a destination works whether or not the weather service is reachable', ($sv['json']['ok'] ?? false) === true);

// An independent copy of the estimate formula (straight line x 1.4 at 40 km/h), so these tests do not just trust the code they test.
$tpLeg = function (array $a, array $b): array {
    $p = M_PI / 180; $dLat = ($b['lat'] - $a['lat']) * $p; $dLng = ($b['lng'] - $a['lng']) * $p;
    $h = sin($dLat / 2) ** 2 + cos($a['lat'] * $p) * cos($b['lat'] * $p) * sin($dLng / 2) ** 2;
    $km = 2 * 6371 * asin(sqrt($h)) * 1.4;
    return [round($km, 1), max(5, (int)(ceil($km / 40 * 60 / 5) * 5))];
};
$tpStart = ['name' => 'Tacloban City (city center)', 'lat' => 11.2444, 'lng' => 125.0048];
$tpDest = ['lat' => 11.15, 'lng' => 124.99];   // Selftest Cove
[$tpKm1, $tpMin1] = $tpLeg($tpStart, $tpDest);
[$tpKmR, $tpMinR] = $tpLeg($tpDest, $tpStart);
$tpDep = 480; $tpArr = $tpDep + $tpMin1; $tpEnd = $tpArr + 90;
$tripBody = ['title' => 'Selftest day', 'date' => '2030-01-15', 'departure' => $tpDep, 'mode' => 'driving', 'source' => 'route', 'start' => $tpStart,
    'stops' => [['destId' => $id, 'visitMin' => 90, 'arrive' => $tpArr, 'begin' => $tpArr, 'end' => $tpEnd, 'legMin' => $tpMin1, 'legKm' => $tpKm1, 'boat' => false]],
    'returnLegMin' => $tpMinR, 'returnLegKm' => $tpKmR, 'returnTime' => $tpEnd + $tpMinR, 'notes' => "Bring water\nand a hat", 'token' => 'selftest-token-0001',
    'weather' => ['kind' => 'current', 'observedAt' => 1790000000, 'note' => '', 'items' => [['destId' => $id, 'name' => 'Selftest Cove', 'level' => 'good', 'label' => 'Good to go', 'reasons' => ['Clear sky, 29C.'], 'desc' => 'Clear sky', 'tempC' => 29]]]];

// Sprint 3: a NEW review now needs a COMPLETED trip that includes the destination. So each reviewer in 7b first saves a plan (status completed) for this destination;
// those plans are deleted again at the end of 7b so the trip tests in 7c start from an empty list, exactly as before.
// ---- 7b. SCRUM-20: ratings and reviews, and the coordinates / rating summary now sent with every public destination ----
$r = post('/api/reviews.php', ['destination' => $id], $anon);
check('reviews: anyone can read a destination\'s reviews (none yet)', ($r['json']['ok'] ?? false) === true && ($r['json']['summary']['count'] ?? -1) === 0 && ($r['json']['reviews'] ?? null) === [] && ($r['json']['mine'] ?? 1) === null, $r['body']);
check('reviews: an anonymous visitor cannot post one (401)', post('/api/review-save.php', ['destination' => $id, 'rating' => 5], $anon)['status'] === 401);
check('reviews: an anonymous visitor cannot delete one (401)', post('/api/review-delete.php', ['destination' => $id], $anon)['status'] === 401);
foreach ([0, 6, 'abc', 4.5, null] as $badRating)
    check('reviews: rating ' . var_export($badRating, true) . ' is rejected', (post('/api/review-save.php', ['destination' => $id, 'rating' => $badRating], $user)['json']['ok'] ?? true) === false);
check('reviews: a destination that does not exist is refused (404)', post('/api/review-save.php', ['destination' => 'dffffffffffff', 'rating' => 5], $user)['status'] === 404);
check('reviews: HTML characters in the text are rejected', (post('/api/review-save.php', ['destination' => $id, 'rating' => 5, 'comment' => '<b>hi</b>'], $user)['json']['ok'] ?? true) === false);
check('reviews: a text over the limit is rejected', (post('/api/review-save.php', ['destination' => $id, 'rating' => 5, 'comment' => str_repeat('a', REV_COMMENT_MAX + 1)], $user)['json']['ok'] ?? true) === false);
check('reviews: without a completed trip a visitor cannot post a review (403)', post('/api/review-save.php', ['destination' => $id, 'rating' => 4, 'comment' => 'x'], $user)['status'] === 403);
$planU = post('/api/trip-save.php', ['token' => 'selftest-7b-user-0001', 'status' => 'completed'] + $tripBody, $user)['json']['trip']['id'] ?? '';
$r = post('/api/review-save.php', ['destination' => $id, 'rating' => 4, 'comment' => "Nice view.\nGo early."], $user);
check('reviews: a signed-in visitor can post a rating with text', ($r['json']['ok'] ?? false) === true && ($r['json']['summary']['count'] ?? 0) === 1 && (float)($r['json']['summary']['avg'] ?? 0) === 4.0, $r['body']);
check('reviews: line breaks in the text are kept', ($r['json']['reviews'][0]['comment'] ?? '') === "Nice view.\nGo early.");
check('reviews: only "First L." is shown, never the id or email', ($r['json']['reviews'][0]['author'] ?? '') === 'Test U.' && !isset($r['json']['reviews'][0]['uid']) && !str_contains($r['body'], 'user@example.com'), $r['body']);
check('reviews: the writer\'s own review is marked as theirs', ($r['json']['mine']['rating'] ?? 0) === 4 && ($r['json']['reviews'][0]['mine'] ?? false) === true);
$r = post('/api/reviews.php', ['destination' => $id], $anon);
check('reviews: other visitors see it, but not as theirs', ($r['json']['summary']['count'] ?? 0) === 1 && ($r['json']['mine'] ?? 1) === null && ($r['json']['reviews'][0]['mine'] ?? true) === false);
$r = post('/api/review-save.php', ['destination' => $id, 'rating' => 2, 'comment' => ''], $user);
check('reviews: posting again EDITS the same review (one per visitor per destination)', ($r['json']['summary']['count'] ?? 0) === 1 && (float)($r['json']['summary']['avg'] ?? 0) === 2.0 && ($r['json']['reviews'][0]['edited'] ?? false) === true, $r['body']);
$second = [];
post('/api/register.php', ['first_name' => 'Second', 'last_name' => 'Person', 'email' => 'second@example.com', 'password' => 'Passw0rd!x'], $second);
$planS = post('/api/trip-save.php', ['token' => 'selftest-7b-second-0001', 'status' => 'completed'] + $tripBody, $second)['json']['trip']['id'] ?? '';
$r = post('/api/review-save.php', ['destination' => $id, 'rating' => 5, 'comment' => 'Loved it.'], $second);
check('reviews: a second visitor adds a second review and the average updates', ($r['json']['summary']['count'] ?? 0) === 2 && (float)($r['json']['summary']['avg'] ?? 0) === 3.5 && ($r['json']['summary']['dist'][5] ?? 0) === 1, $r['body']);
$pub = array_values(array_filter(post('/api/destinations.php', [], $anon)['json']['places'] ?? [], fn($p) => $p['name'] === 'Selftest Cove'));
check('public destination list carries the rating summary and usable coordinates', (float)($pub[0]['ratingAvg'] ?? 0) === 3.5 && ($pub[0]['ratingCount'] ?? 0) === 2 && abs((float)($pub[0]['lat'] ?? 0) - 11.15) < 1e-6 && abs((float)($pub[0]['lng'] ?? 0) - 124.99) < 1e-6, json_encode($pub));
$r = post('/api/review-delete.php', ['destination' => $id], $second);
check('reviews: a visitor can delete only their own review', ($r['json']['summary']['count'] ?? 0) === 1 && (float)($r['json']['summary']['avg'] ?? 0) === 2.0 && ($r['json']['mine'] ?? 1) === null, $r['body']);
post('/api/trip-delete.php', ['id' => $planU], $user); post('/api/trip-delete.php', ['id' => $planS], $second);   // back to no plans for 7c (the reviews stay)

// ---- 7c. Sprint 4: SCRUM-21 favourites, SCRUM-22 activity (admin), My Trip Plans ----
check('favourites: an anonymous visitor cannot change them (401)', post('/api/favourites.php', ['destination' => $id, 'on' => true], $anon)['status'] === 401);
check('favourites: "on" must be true or false', (post('/api/favourites.php', ['destination' => $id, 'on' => 'yes'], $user)['json']['ok'] ?? true) === false);
check('favourites: a destination that does not exist is refused (404)', post('/api/favourites.php', ['destination' => 'dffffffffffff', 'on' => true], $user)['status'] === 404);
$r = post('/api/favourites.php', ['destination' => $id, 'on' => true], $user);
check('favourites: add a destination', ($r['json']['ok'] ?? false) === true && ($r['json']['favourites'] ?? []) === [$id], $r['body']);
$r = post('/api/favourites.php', ['destination' => $id, 'on' => true], $user);
check('favourites: adding twice keeps one (a repeated request cannot flip it)', ($r['json']['favourites'] ?? []) === [$id]);
check('favourites: they come back with the account (any device after login)', (post('/api/me.php', [], $user)['json']['user']['favourites'] ?? []) === [$id]);
check('favourites: another visitor has none', (post('/api/me.php', [], $second)['json']['user']['favourites'] ?? ['x']) === []);

check('trips: an anonymous visitor cannot list or save (401)', post('/api/trips.php', [], $anon)['status'] === 401 && post('/api/trip-save.php', $tripBody, $anon)['status'] === 401);
$r = post('/api/trip-save.php', $tripBody, $user);
$tripId = $r['json']['trip']['id'] ?? '';
$tripCreated = $r['json']['trip']['created'] ?? '';
check('trips: a signed-in visitor can save a plan; it gets a reference like TP-YYYYMMDD-XXXXXX', ($r['json']['ok'] ?? false) === true && (bool)preg_match('/^TP-\d{8}-[A-F0-9]{6}$/', $tripId), $r['body']);
check('trips: the saved plan has the stop snapshot, totals, status and a creation time', ($r['json']['trip']['stops'][0]['name'] ?? '') === 'Selftest Cove' && ($r['json']['trip']['totals']['fee'] ?? -1) === 25 && ($r['json']['trip']['status'] ?? '') === 'planned' && !empty($r['json']['trip']['created']) && ($r['json']['trip']['notes'] ?? '') === "Bring water\nand a hat" && ($r['json']['trip']['estimate']['routingService'] ?? true) === false, $r['body']);
check('trips: the owner\'s account id and the save token are never sent back', !isset($r['json']['trip']['uid']) && !isset($r['json']['trip']['token']) && !str_contains($r['body'], 'selftest-token-0001'));
$r = post('/api/trip-save.php', $tripBody, $user);
check('trips: saving the same attempt twice (same token) returns the first plan, not a copy', ($r['json']['duplicate'] ?? false) === true && ($r['json']['trip']['id'] ?? '') === $tripId && count(post('/api/trips.php', [], $user)['json']['trips'] ?? []) === 1, $r['body']);
$r = post('/api/trips.php', [], $user);
check('trips: the list shows one card per plan with title, date, start, stop count, status', ($r['json']['trips'][0]['title'] ?? '') === 'Selftest day' && ($r['json']['trips'][0]['stopCount'] ?? 0) === 1 && ($r['json']['trips'][0]['start'] ?? '') === 'Tacloban City (city center)' && !isset($r['json']['trips'][0]['stops']), $r['body']);
check('trips: reading one plan in full works for its owner', ($r2 = post('/api/trip.php', ['id' => $tripId], $user))['json']['trip']['id'] === $tripId && count($r2['json']['trip']['stops']) === 1);
// another account must not be able to see, change or delete it, and must not even learn that it exists
check('trips: another visitor\'s list is empty', (post('/api/trips.php', [], $second)['json']['trips'] ?? ['x']) === []);
check('trips: another visitor cannot read it (404, same as a plan that does not exist)', post('/api/trip.php', ['id' => $tripId], $second)['status'] === 404 && post('/api/trip.php', ['id' => 'TP-20300101-AAAAAA'], $second)['status'] === 404);
check('trips: another visitor cannot edit it (404)', post('/api/trip-save.php', ['id' => $tripId, 'title' => 'Hijacked'] + $tripBody, $second)['status'] === 404);
check('trips: another visitor cannot delete it (404)', post('/api/trip-delete.php', ['id' => $tripId], $second)['status'] === 404);
check('trips: ...and it is untouched after those attempts', ($r2 = post('/api/trip.php', ['id' => $tripId], $user))['json']['trip']['title'] === 'Selftest day');
// validation: every one of these must be refused, and none may create a plan
$bad = function (string $name, array $changes) use ($tripBody, $user) {
    static $n = 0; $n++;
    $body = array_replace_recursive($tripBody, ['token' => sprintf('selftest-bad-%04d-xxxx', $n)]);
    foreach ($changes as $k => $v) $body[$k] = $v;
    $r = post('/api/trip-save.php', $body, $user);
    check("trips: refused: $name", ($r['json']['ok'] ?? true) === false, $r['body']);
};
$stop0 = $tripBody['stops'][0];
$bad('a made-up distance', ['stops' => [['legKm' => $tpKm1 + 5] + $stop0]]);
$bad('a travel time shorter than the estimate allows', ['stops' => [['legMin' => max(1, $tpMin1 - 5)] + $stop0]]);
$bad('arriving before the drive could finish', ['stops' => [['arrive' => $tpDep + 1, 'begin' => $tpDep + 1, 'end' => $tpDep + 91] + $stop0]]);
$bad('visit times that do not add up', ['stops' => [['end' => $tpEnd + 7] + $stop0]]);
$bad('a plan that ends after midnight', ['stops' => [['arrive' => 1400, 'begin' => 1400, 'end' => 1490] + $stop0]]);
$bad('a start point outside Leyte', ['start' => ['name' => 'Far away', 'lat' => 34.877, 'lng' => 103.8]]);
$bad('a destination that does not exist', ['stops' => [['destId' => 'dffffffffffff'] + $stop0]]);
$bad('the same destination twice', ['stops' => [$stop0, $stop0]]);
$bad('no destinations', ['stops' => []]);
$bad('too many destinations', ['stops' => array_fill(0, TRIP_STOPS_MAX + 1, $stop0)]);
$bad('a title with < or >', ['title' => '<b>x</b>']);
$bad('an empty title', ['title' => '   ']);
$bad('an impossible date', ['date' => '2030-02-31']);
$bad('a status that is not planned/completed/cancelled', ['status' => 'booked']);
$bad('a travel mode that is not supported', ['mode' => 'walking']);
$bad('notes over the limit', ['notes' => str_repeat('n', TRIP_NOTES_MAX + 1)]);
$bad('a return time before the drive home is possible', ['returnTime' => $tpEnd + 1]);
$bad('arriving before the lunch break it claims has finished', ['stops' => [['lunchBefore' => 45] + $stop0]]);
check('trips: none of the refused requests created a plan', count(post('/api/trips.php', [], $user)['json']['trips'] ?? []) === 1);
$r = post('/api/trip-save.php', ['id' => $tripId, 'title' => 'Renamed day', 'status' => 'completed', 'notes' => 'Edited notes'] + array_diff_key($tripBody, ['weather' => 1, 'token' => 1]), $user);
check('trips: the owner can edit title, notes and status; id and creation time stay; the saved weather is kept', ($r['json']['trip']['title'] ?? '') === 'Renamed day' && ($r['json']['trip']['status'] ?? '') === 'completed' && ($r['json']['trip']['id'] ?? '') === $tripId && ($r['json']['trip']['created'] ?? 'x') === $tripCreated && ($r['json']['trip']['weather']['items'][0]['level'] ?? '') === 'good', $r['body']);
// SCRUM-22: the admin Activity page
post('/api/recent.php', ['name' => 'Selftest Cove'], $user);
$r = post('/api/admin/activity.php', [], $admin);
$row = array_values(array_filter($r['json']['activity']['destinations'] ?? [], fn($d) => $d['id'] === $id))[0] ?? [];
check('activity: the admin sees opens, favourites, reviews and trip plans per destination', ($row['views'] ?? 0) >= 1 && ($row['favourites'] ?? 0) === 1 && ($row['reviews'] ?? 0) === 1 && ($row['plans'] ?? 0) === 1, $r['body']);
check('activity: the recent events name the visitor and the action, but carry no emails', count($r['json']['activity']['recent'] ?? []) >= 4 && !str_contains($r['body'], '@example.com') && in_array('trip_save', array_column($r['json']['activity']['recent'], 'type'), true) && in_array('favourite_add', array_column($r['json']['activity']['recent'], 'type'), true), $r['body']);
check('activity: an ordinary visitor and an anonymous visitor cannot open it', in_array(post('/api/admin/activity.php', [], $user)['status'], [401, 403], true) && in_array(post('/api/admin/activity.php', [], $anon)['status'], [401, 403], true));
$r = post('/api/favourites.php', ['destination' => $id, 'on' => false], $user);
check('favourites: remove', ($r['json']['ok'] ?? false) === true && ($r['json']['favourites'] ?? ['x']) === []);
post('/api/favourites.php', ['destination' => $id, 'on' => true], $user);   // left on: the deleted-destination checks below cover it

// ---- 7d. Sprint 3: completed-trip History Log and reviews (completion, ownership, eligibility, duplicates) ----
$s3a = []; $s3b = [];
post('/api/register.php', ['first_name' => 'Sprint', 'last_name' => 'Alpha', 'email' => 'sprint3a@example.com', 'password' => 'Passw0rd!x'], $s3a);
post('/api/register.php', ['first_name' => 'Sprint', 'last_name' => 'Beta', 'email' => 'sprint3b@example.com', 'password' => 'Passw0rd!x'], $s3b);
$otherDest = '';
foreach (post('/api/destinations.php', [], $anon)['json']['places'] ?? [] as $pl) if (($pl['id'] ?? '') !== $id) { $otherDest = $pl['id']; break; }
$cnt0 = (int)(post('/api/reviews.php', ['destination' => $id], $anon)['json']['summary']['count'] ?? 0);
check('history: anonymous visitors cannot read history, complete or review from a trip (401)', post('/api/trip-history.php', [], $anon)['status'] === 401 && post('/api/trip-complete.php', ['id' => 'TP-20300101-AAAAAA'], $anon)['status'] === 401 && post('/api/trip-review.php', ['trip' => 'TP-20300101-AAAAAA', 'destination' => $id, 'rating' => 5, 'comment' => 'x'], $anon)['status'] === 401);
check('history: with no plan at all, review-save is refused (403) and the popup does not offer a form', post('/api/review-save.php', ['destination' => $id, 'rating' => 5, 'comment' => 'x'], $s3a)['status'] === 403 && (post('/api/reviews.php', ['destination' => $id], $s3a)['json']['canReview'] ?? true) === false);
check('history: reviewing from a plan that does not exist is a 404', post('/api/trip-review.php', ['trip' => 'TP-20300101-AAAAAA', 'destination' => $id, 'rating' => 5, 'comment' => 'x'], $s3a)['status'] === 404);
$r = post('/api/trip-save.php', ['token' => 'selftest-s3a-plan-0001', 'title' => 'Sprint plan'] + $tripBody, $s3a);
$planA = $r['json']['trip']['id'] ?? '';
check('history: a saved plan starts as planned, with no completion date', ($r['json']['ok'] ?? false) === true && ($r['json']['trip']['status'] ?? '') === 'planned' && ($r['json']['trip']['completedAt'] ?? 'x') === null, $r['body']);
$r = post('/api/trip-history.php', [], $s3a);
check('history: a planned plan is listed as incomplete, not completed', ($r['json']['completed'] ?? ['x']) === [] && ($r['json']['incomplete'][0]['id'] ?? '') === $planA && ($r['json']['incomplete'][0]['status'] ?? '') === 'planned', $r['body']);
check('review rule: a PLANNED plan gives no review access (trip-review and review-save both 403)', post('/api/trip-review.php', ['trip' => $planA, 'destination' => $id, 'rating' => 5, 'comment' => 'x'], $s3a)['status'] === 403 && post('/api/review-save.php', ['destination' => $id, 'rating' => 5, 'comment' => 'x'], $s3a)['status'] === 403);
post('/api/destinations.php', [], $s3a); post('/api/recent.php', ['name' => 'Selftest Cove'], $s3a);   // opening / viewing a destination
check('review rule: viewing a destination (and saving it as a favourite) gives no review access', post('/api/favourites.php', ['destination' => $id, 'on' => true], $s3a)['json']['ok'] === true && post('/api/review-save.php', ['destination' => $id, 'rating' => 5, 'comment' => 'x'], $s3a)['status'] === 403 && ((post('/api/trip-history.php', [], $s3a)['json']['completed'] ?? ['x']) === []));
$r = post('/api/trip-save.php', ['token' => 'selftest-s3b-plan-0001', 'title' => 'Cancelled plan', 'status' => 'cancelled'] + $tripBody, $s3b);
$planB = $r['json']['trip']['id'] ?? '';
check('review rule: a CANCELLED plan gives no review access', post('/api/trip-review.php', ['trip' => $planB, 'destination' => $id, 'rating' => 5, 'comment' => 'x'], $s3b)['status'] === 403 && post('/api/review-save.php', ['destination' => $id, 'rating' => 5, 'comment' => 'x'], $s3b)['status'] === 403);
check('completion: a cancelled plan cannot be marked completed (409)', post('/api/trip-complete.php', ['id' => $planB], $s3b)['status'] === 409);
check('completion: another visitor cannot complete it (404, same as a plan that does not exist)', post('/api/trip-complete.php', ['id' => $planA], $s3b)['status'] === 404 && post('/api/trip-complete.php', ['id' => 'TP-20300101-AAAAAA'], $s3b)['status'] === 404 && post('/api/trip.php', ['id' => $planA], $s3a)['json']['trip']['status'] === 'planned');
$r = post('/api/trip-complete.php', ['id' => $planA], $s3a);
$doneAt = $r['json']['trip']['completedAt'] ?? '';
check('completion: the owner marks it completed; status and completion date are saved', ($r['json']['ok'] ?? false) === true && ($r['json']['trip']['status'] ?? '') === 'completed' && $doneAt !== '' && ($r['json']['duplicate'] ?? true) === false && !isset($r['json']['trip']['uid']), $r['body']);
$r = post('/api/trip-complete.php', ['id' => $planA], $s3a);
check('completion: sending it again changes nothing (same date, duplicate flag, still one plan)', ($r['json']['duplicate'] ?? false) === true && ($r['json']['trip']['completedAt'] ?? '') === $doneAt && count(post('/api/trips.php', [], $s3a)['json']['trips'] ?? []) === 1, $r['body']);
$h = post('/api/trip-history.php', [], $s3a);
check('history: the completed plan appears with its destination, date, status and Not Reviewed', ($h['json']['completed'][0]['id'] ?? '') === $planA && ($h['json']['completed'][0]['status'] ?? '') === 'completed' && ($h['json']['completed'][0]['completedAt'] ?? '') === $doneAt && ($h['json']['completed'][0]['destinations'][0]['destId'] ?? '') === $id && ($h['json']['completed'][0]['destinations'][0]['name'] ?? '') === 'Selftest Cove' && ($h['json']['completed'][0]['destinations'][0]['reviewed'] ?? true) === false && ($h['json']['incomplete'] ?? ['x']) === [], $h['body']);
$hb = post('/api/trip-history.php', [], $s3b);
check('history: another visitor sees only their own trips, nothing of this one', !str_contains($hb['body'], $planA) && ($hb['json']['completed'] ?? ['x']) === [] && !str_contains($hb['body'], 'sprint3a@example.com') && !isset($h['json']['completed'][0]['uid']), $hb['body']);
check('review rule: the popup now offers the form (canReview) to the owner and to nobody else', (post('/api/reviews.php', ['destination' => $id], $s3a)['json']['canReview'] ?? false) === true && (post('/api/reviews.php', ['destination' => $id], $s3b)['json']['canReview'] ?? true) === false && (post('/api/reviews.php', ['destination' => $id], $anon)['json']['canReview'] ?? true) === false);
check('review rule: another visitor cannot review through the owner\'s completed plan (404)', post('/api/trip-review.php', ['trip' => $planA, 'destination' => $id, 'rating' => 5, 'comment' => 'Hijack'], $s3b)['status'] === 404);
check('review rule: a visitor with no completed plan of their own still cannot review the same destination (403)', post('/api/review-save.php', ['destination' => $id, 'rating' => 5, 'comment' => 'Hijack'], $s3b)['status'] === 403);
if ($otherDest !== '') check('review rule: a destination that is not in the completed plan is refused (404), by both endpoints', post('/api/trip-review.php', ['trip' => $planA, 'destination' => $otherDest, 'rating' => 5, 'comment' => 'x'], $s3a)['status'] === 404 && post('/api/review-save.php', ['destination' => $otherDest, 'rating' => 5, 'comment' => 'x'], $s3a)['status'] === 403);
foreach ([[0, 'ok'], [6, 'ok'], ['abc', 'ok'], [null, 'ok']] as [$badRating, $_]) check('review form: rating ' . var_export($badRating, true) . ' is rejected by the server', (post('/api/trip-review.php', ['trip' => $planA, 'destination' => $id, 'rating' => $badRating, 'comment' => 'fine'], $s3a)['json']['ok'] ?? true) === false);
check('review form: an empty written review is rejected', post('/api/trip-review.php', ['trip' => $planA, 'destination' => $id, 'rating' => 5, 'comment' => '   '], $s3a)['status'] === 422);
check('review form: < > and an over-long text are rejected', post('/api/trip-review.php', ['trip' => $planA, 'destination' => $id, 'rating' => 5, 'comment' => '<b>x</b>'], $s3a)['status'] === 422 && post('/api/trip-review.php', ['trip' => $planA, 'destination' => $id, 'rating' => 5, 'comment' => str_repeat('a', REV_COMMENT_MAX + 1)], $s3a)['status'] === 422);
check('review form: nothing was saved by the rejected requests', (int)(post('/api/reviews.php', ['destination' => $id], $anon)['json']['summary']['count'] ?? -1) === $cnt0);
$r = post('/api/trip-review.php', ['trip' => $planA, 'destination' => $id, 'rating' => 5, 'comment' => 'Worth the trip.', 'uid' => 'someone-else', 'user' => 'someone-else'], $s3a);
check('review form: a valid rating and review from the completed plan is saved', ($r['json']['ok'] ?? false) === true && ($r['json']['mine']['rating'] ?? 0) === 5 && (int)($r['json']['summary']['count'] ?? 0) === $cnt0 + 1, $r['body']);
$rv = json_decode((string)file_get_contents($tmp . '/data/reviews.json'), true) ?: [];
$saved = array_values(array_filter($rv, fn($x) => ($x['comment'] ?? '') === 'Worth the trip.'))[0] ?? [];
check('review form: it is stored under the right destination and the right plan, and a user id typed by the browser is ignored', ($saved['dest'] ?? '') === $id && ($saved['trip'] ?? '') === $planA && ($saved['uid'] ?? 'someone-else') !== 'someone-else' && ($saved['uid'] ?? '') !== '', json_encode($saved));
$r = post('/api/trip-review.php', ['trip' => $planA, 'destination' => $id, 'rating' => 1, 'comment' => 'Second try.'], $s3a);
check('review rule: a second review of the same destination from the same plan is refused (409) and nothing changes', $r['status'] === 409 && (int)(post('/api/reviews.php', ['destination' => $id], $anon)['json']['summary']['count'] ?? -1) === $cnt0 + 1 && ($r2 = post('/api/reviews.php', ['destination' => $id], $s3a))['json']['mine']['rating'] === 5, $r['body']);
$h = post('/api/trip-history.php', [], $s3a);
check('history: after the review the destination shows Reviewed with its rating', ($h['json']['completed'][0]['destinations'][0]['reviewed'] ?? false) === true && ($h['json']['completed'][0]['destinations'][0]['review']['rating'] ?? 0) === 5, $h['body']);
$pubr = post('/api/reviews.php', ['destination' => $id], $anon);
$row = array_values(array_filter($pubr['json']['reviews'] ?? [], fn($x) => ($x['comment'] ?? '') === 'Worth the trip.'))[0] ?? [];
check('display: the review shows on that destination with a public name (First L.), stars and a date, and no id or email', ($row['author'] ?? '') === 'Sprint A.' && ($row['rating'] ?? 0) === 5 && !empty($row['date']) && !str_contains($pubr['body'], 'sprint3a@example.com') && !isset($row['uid']), $pubr['body']);
if ($otherDest !== '') check('display: the review does not appear under another destination', !str_contains(post('/api/reviews.php', ['destination' => $otherDest], $anon)['body'], 'Worth the trip.'));
$pub = array_values(array_filter(post('/api/destinations.php', [], $anon)['json']['places'] ?? [], fn($p) => $p['name'] === 'Selftest Cove'));
check('display: the destination\'s review count in the public list matches', ($pub[0]['ratingCount'] ?? 0) === $cnt0 + 1);
check('edit: the reviewer can still edit their own review; another visitor cannot delete it', ($r = post('/api/review-save.php', ['destination' => $id, 'rating' => 4, 'comment' => 'Worth the trip.'], $s3a))['json']['mine']['rating'] === 4 && (int)($r['json']['summary']['count'] ?? 0) === $cnt0 + 1 && (int)(post('/api/review-delete.php', ['destination' => $id], $s3b)['json']['summary']['count'] ?? -1) === $cnt0 + 1);
$r = post('/api/trip-save.php', ['id' => $planA, 'status' => 'completed'] + array_diff_key($tripBody, ['weather' => 1, 'token' => 1]), $s3a);
check('completion: editing a completed plan keeps its completion date', ($r['json']['ok'] ?? false) === true && ($r['json']['trip']['completedAt'] ?? '') === $doneAt, $r['body']);

// ---- 7d. Business Destination Requests: same fields and validation as the admin form, kept apart until approved ----
$owner = ['contactName' => 'Maria Owner', 'contactEmail' => 'owner@example.com', 'contactPhone' => '+63 917 000 0000', 'confirm' => true];
$reqBody = ['name' => 'Owner Beach Resort', 'town' => 'Tolosa', 'area' => 'rural', 'view' => 'sunset', 'hours' => '7:00 AM - 6:00 PM', 'cats' => [$catKeys[0]], 'time' => ['morning', 'evening'],
            'feeAmt' => 120, 'fee' => '', 'facilities' => ['Cottages', 'Parking'], 'blurb' => 'A quiet beach.', 'about' => 'Submitted by a business owner.', 'highlights' => ['Sunset view'],
            'best' => 'March to May', 'getThere' => 'Ten minutes from the highway.', 'tip' => 'Bring cash.', 'lat' => 11.05, 'lng' => 125.03];
check('requests: the public request page is served', http('GET', "$base/business-request.html", null, $anon, true)['status'] === 200);
check('requests: the admin review page is served', http('GET', "$base/admin/requests.html", null, $anon, true)['status'] === 200);
check('requests: the request data file is not downloadable', http('GET', "$base/data/destination-requests.json", null, $anon, true)['status'] >= 400);
foreach (['requests', 'request-save', 'request-approve', 'request-reject'] as $ep) {
    check("requests: anonymous gets 401 and an ordinary user 403 from api/admin/$ep.php", post("/api/admin/$ep.php", ['id' => 'x'], $anon)['status'] === 401 && post("/api/admin/$ep.php", ['id' => 'x'], $user)['status'] === 403);
}
$liveBefore = count(post('/api/destinations.php', [], $anon)['json']['places'] ?? []);

// Same validation as Add destination: every bad body must get the SAME message from both endpoints.
$cases = ['no name' => ['name' => ''], 'no town' => ['town' => ''], 'bad area' => ['area' => 'sea'], 'bad view' => ['view' => 'noon'], 'no hours' => ['hours' => ''], 'no category' => ['cats' => []],
          'unknown category' => ['cats' => ['nope']], 'bad time' => ['time' => ['midnight']], 'negative fee' => ['feeAmt' => -1], 'no fee' => ['feeAmt' => ''], 'latitude 123' => ['lat' => 123], 'no longitude' => ['lng' => ''],
          'html in blurb' => ['blurb' => 'a <b>b</b>'], 'no about' => ['about' => ''], 'long blurb' => ['blurb' => str_repeat('x', 201)], 'too many highlights' => ['highlights' => array_map(fn($i) => "h$i", range(1, 11))]];
foreach ($cases as $label => $change) {
    $b = array_replace($reqBody, $change); $b['name'] = ($change['name'] ?? null) === '' ? '' : 'Parity ' . substr(md5($label), 0, 6);
    $a = post('/api/admin/destination-save.php', $b, $admin); $q = post('/api/destination-request.php', $b + $owner, $anon);
    check("requests: validation matches the admin form ($label)", ($a['json']['ok'] ?? true) === false && ($q['json']['ok'] ?? true) === false && ($a['json']['message'] ?? 'a') === ($q['json']['message'] ?? 'q') && $a['status'] === $q['status'], ($a['json']['message'] ?? '') . ' | ' . ($q['json']['message'] ?? ''));
}
foreach (['no email' => ['contactEmail' => ''], 'bad email' => ['contactEmail' => 'nope'], 'no name' => ['contactName' => ''], 'bad phone' => ['contactPhone' => 'abc'], 'not confirmed' => ['confirm' => false]] as $label => $change)
    check("requests: owner details are checked ($label)", (post('/api/destination-request.php', array_replace($reqBody + $owner, $change), $anon)['json']['ok'] ?? true) === false);
check('requests: a name that is already live is refused', post('/api/destination-request.php', array_replace($reqBody, ['name' => 'Selftest Cove']) + $owner, $anon)['status'] === 409);
check('requests: failed attempts stored nothing', !is_file($tmp . '/data/destination-requests.json') || count(json_decode((string)file_get_contents($tmp . '/data/destination-requests.json'), true)) === 0);

$r = post('/api/destination-request.php', $reqBody + $owner + ['photo' => $png], $anon);
check('requests: a business owner can send a request (no account) and gets a reference', ($r['json']['ok'] ?? false) === true && preg_match('/^BDR-\d{8}-[A-F0-9]{6}$/', (string)($r['json']['ref'] ?? '')), $r['body']);
$refA = $r['json']['ref'] ?? '';
check('requests: a pending request is NOT in the live destinations (public list, admin list, data file)',
    count(post('/api/destinations.php', [], $anon)['json']['places'] ?? []) === $liveBefore
    && !array_filter(post('/api/admin/destinations.php', [], $admin)['json']['destinations'] ?? [], fn($d) => $d['name'] === 'Owner Beach Resort')
    && !str_contains((string)file_get_contents($tmp . '/data/destinations.json'), 'Owner Beach Resort'));
check('requests: a duplicate pending request from the same owner is refused', post('/api/destination-request.php', $reqBody + $owner, $anon)['status'] === 409);
$hp = post('/api/destination-request.php', array_replace($reqBody, ['name' => 'Bot Place']) + $owner + ['website' => 'http://spam'], $anon);
check('requests: the hidden honeypot field makes a bot look successful but stores nothing', ($hp['json']['ok'] ?? false) === true && !str_contains((string)file_get_contents($tmp . '/data/destination-requests.json'), 'Bot Place'));
$list = post('/api/admin/requests.php', ['status' => 'pending'], $admin)['json'];
$ra = array_values(array_filter($list['requests'] ?? [], fn($x) => $x['ref'] === $refA))[0] ?? null;
check('requests: the admin sees it as pending with the owner details', $ra && $ra['status'] === 'pending' && $ra['contact']['email'] === 'owner@example.com' && ($list['counts']['pending'] ?? 0) === 1, json_encode($list));
check('requests: admin menu badge count is available (me.php)', (post('/api/admin/me.php', [], $admin)['json']['admin']['pending_requests'] ?? 0) === 1);
// Same destination structure as a live destination record
$live = post('/api/admin/destinations.php', [], $admin)['json']['destinations'][0] ?? [];
$fieldKeys = ['name', 'town', 'cats', 'area', 'time', 'view', 'feeAmt', 'fee', 'hours', 'facilities', 'blurb', 'about', 'highlights', 'best', 'getThere', 'tip', 'lat', 'lng'];
check('requests: the request holds every destination field the admin form saves, under the same names', !array_diff($fieldKeys, array_keys($ra['destination'] ?? [])) && !array_diff($fieldKeys, array_keys($live)));
check('requests: an empty fee label got the same default as Add destination', ($ra['destination']['fee'] ?? '') === '₱120 entrance fee');
check('requests: its photo is not public, and only an administrator can see it', http('GET', $base . '/' . ($ra['destination']['image'] ?? 'x'), null, $anon, true)['status'] === 401
    && http('GET', $base . '/' . ($ra['destination']['image'] ?? 'x'), null, $admin, true)['status'] === 200 && http('GET', $base . '/' . ($ra['destination']['image'] ?? 'x'), null, $user, true)['status'] === 403);
check('requests: the pending photo is stored outside images/places', count(glob($tmp . '/data/request-photos/*') ?: []) === 1 && count(glob($tmp . '/images/places/*r*') ?: []) >= 0);

// Admin corrects values (same body as the Add destination form) and approves in one step.
$fix = array_replace($reqBody, ['name' => 'Owner Beach Resort', 'blurb' => 'A quiet beach, corrected by the admin.', 'town' => 'Tolosa', 'feeAmt' => 100, 'fee' => '']) + ['id' => $ra['id']];
$r = post('/api/admin/request-save.php', $fix, $admin);
check('requests: the admin can save corrections and the request stays pending', ($r['json']['ok'] ?? false) && ($r['json']['request']['status'] ?? '') === 'pending' && ($r['json']['request']['destination']['blurb'] ?? '') === 'A quiet beach, corrected by the admin.', $r['body']);
$bad = $fix; $bad['lat'] = 999;
check('requests: corrections are validated like Add destination', (post('/api/admin/request-approve.php', $bad, $admin)['json']['ok'] ?? true) === false && count(post('/api/destinations.php', [], $anon)['json']['places'] ?? []) === $liveBefore);
$r = post('/api/admin/request-approve.php', $fix, $admin);
check('requests: approving adds it to the live directory', ($r['json']['ok'] ?? false) === true && ($r['json']['destination']['name'] ?? '') === 'Owner Beach Resort', $r['body']);
$pub = array_values(array_filter(post('/api/destinations.php', [], $anon)['json']['places'] ?? [], fn($p) => $p['name'] === 'Owner Beach Resort'))[0] ?? null;
check('requests: the approved destination is an ordinary public destination with the corrected values, category, time, coordinates and fee',
    $pub && $pub['blurb'] === 'A quiet beach, corrected by the admin.' && $pub['cats'] === [$catKeys[0]] && $pub['time'] === ['morning', 'evening'] && $pub['lat'] === 11.05 && $pub['lng'] === 125.03
    && $pub['feeAmt'] === 100 && $pub['fee'] === '₱100 entrance fee' && $pub['view'] === 'sunset' && $pub['facilities'] === ['Cottages', 'Parking'] && $pub['area'] === 'rural', json_encode($pub));
check('requests: the photo the owner sent is now the destination photo in images/places (the admin did not re-upload it)', is_string($pub['image'] ?? null) && is_file($tmp . '/' . explode('?', $pub['image'])[0]));
check('requests: the pending photo copy was removed', count(glob($tmp . '/data/request-photos/*') ?: []) === 0);
$rec = array_values(array_filter(json_decode((string)file_get_contents($tmp . '/data/destinations.json'), true), fn($d) => $d['name'] === 'Owner Beach Resort'))[0] ?? [];
$liveRec = array_values(array_filter(json_decode((string)file_get_contents($tmp . '/data/destinations.json'), true), fn($d) => $d['name'] === 'Selftest Cove'));
check('requests: the saved record has the same keys as one added with Add destination (no extra owner data leaks into it)', !array_diff(array_merge($fieldKeys, ['id', 'created', 'updated', 'image']), array_keys($rec)) && !isset($rec['contact']) && !isset($rec['status']) && !str_contains(json_encode($rec), 'owner@example.com'));
check('requests: it is in the category filter counts (same record format)', (array_column(post('/api/admin/categories.php', [], $admin)['json']['categories'] ?? [], 'count', 'key')[$catKeys[0]] ?? 0) >= 1);
check('requests: an approved request is marked approved and cannot be approved or rejected again (409)', post('/api/admin/request-approve.php', $fix, $admin)['status'] === 409 && post('/api/admin/request-reject.php', ['id' => $ra['id']], $admin)['status'] === 409
    && (post('/api/admin/requests.php', ['status' => 'approved'], $admin)['json']['requests'][0]['destinationId'] ?? '') === ($r['json']['destination']['id'] ?? 'x'));
check('requests: the live directory got exactly one new destination', count(post('/api/destinations.php', [], $anon)['json']['places'] ?? []) === $liveBefore + 1);

// Reject
$r = post('/api/destination-request.php', array_replace($reqBody, ['name' => 'Rejected Place']) + $owner, $anon);
$rid = array_values(array_filter(post('/api/admin/requests.php', ['status' => 'pending'], $admin)['json']['requests'] ?? [], fn($x) => $x['destination']['name'] === 'Rejected Place'))[0]['id'] ?? '';
$r = post('/api/admin/request-reject.php', ['id' => $rid, 'reason' => 'Not a tourist site.'], $admin);
check('requests: rejecting keeps it out of the live directory and records the reason', ($r['json']['ok'] ?? false) && ($r['json']['request']['reason'] ?? '') === 'Not a tourist site.' && !array_filter(post('/api/destinations.php', [], $anon)['json']['places'] ?? [], fn($p) => $p['name'] === 'Rejected Place'));
check('requests: a rejected request cannot be approved (409)', post('/api/admin/request-approve.php', array_replace($reqBody, ['name' => 'Rejected Place', 'id' => $rid]), $admin)['status'] === 409);

// A name that becomes live between submission and approval: approval is refused and the request stays pending
post('/api/destination-request.php', array_replace($reqBody, ['name' => 'Race Place']) + $owner, $anon);
post('/api/admin/destination-save.php', array_replace($base_dest, ['name' => 'Race Place']), $admin);
$rid = array_values(array_filter(post('/api/admin/requests.php', ['status' => 'pending'], $admin)['json']['requests'] ?? [], fn($x) => $x['destination']['name'] === 'Race Place'))[0] ?? [];
check('requests: the list warns when the name is already live', ($rid['nameTaken'] ?? false) === true);
$r = post('/api/admin/request-approve.php', array_replace($reqBody, ['name' => 'Race Place', 'id' => $rid['id'] ?? 'x']), $admin);
check('requests: approving a name that is already live is refused (409) and the request stays pending', $r['status'] === 409 && count(array_filter(post('/api/admin/requests.php', ['status' => 'pending'], $admin)['json']['requests'] ?? [], fn($x) => $x['destination']['name'] === 'Race Place')) === 1, $r['body']);
$r = post('/api/admin/request-approve.php', array_replace($reqBody, ['name' => 'Race Place Two', 'id' => $rid['id'] ?? 'x']), $admin);
check('requests: the admin can fix the name in the review form and then approve', ($r['json']['ok'] ?? false) === true, $r['body']);

// Per-address limit (5 an hour): 4 requests are stored so far (Owner, Rejected, Race, + the honeypot one is not), so the 6th stored attempt is refused
$n = 0; $limited = false;
foreach (range(1, 4) as $i) { $q = post('/api/destination-request.php', array_replace($reqBody, ['name' => "Limit Place $i"]) + array_replace($owner, ['contactEmail' => "limit$i@example.com"]), $anon); if (($q['status'] ?? 0) === 429) $limited = true; }
check('requests: one connection cannot flood the queue (429 after 5 an hour)', $limited);
check('requests: the request data file is still valid JSON', is_array(json_decode((string)file_get_contents($tmp . '/data/destination-requests.json'), true)));

// ---- 8. delete, logout ----
$r = post('/api/admin/destination-delete.php', ['id' => $id], $admin);
check('delete destination', ($r['json']['ok'] ?? false) === true, $r['body']);
$pub = array_values(array_filter(post('/api/destinations.php', [], $anon)['json']['places'] ?? [], fn($p) => $p['name'] === 'Selftest Cove'));
check('deleted destination is gone from the public site', count($pub) === 0);
$left = json_decode((string)@file_get_contents($tmp . '/data/reviews.json'), true);
check('reviews: deleting a destination removes its reviews', is_array($left) && count(array_filter($left, fn($rv) => ($rv['dest'] ?? '') === $id)) === 0, json_encode($left));
check('reviews: a deleted destination can no longer be read or reviewed (404)', post('/api/reviews.php', ['destination' => $id], $anon)['status'] === 404);
$r = post('/api/trip.php', ['id' => $tripId], $user);
check('trips: a saved plan keeps its destination snapshot after the admin deletes that destination', ($r['json']['ok'] ?? false) === true && ($r['json']['trip']['stops'][0]['name'] ?? '') === 'Selftest Cove' && ($r['json']['trip']['stops'][0]['fee'] ?? null) !== null, $r['body']);
$r = post('/api/trip-save.php', ['id' => $tripId, 'notes' => 'Still editable'] + array_diff_key($tripBody, ['weather' => 1, 'token' => 1, 'notes' => 1]), $user);
check('trips: and the owner can still edit that plan', ($r['json']['ok'] ?? false) === true && ($r['json']['trip']['notes'] ?? '') === 'Still editable', $r['body']);
check('favourites: a deleted destination left in a favourites list does not break the account', ($r = post('/api/me.php', [], $user))['status'] === 200 && ($r['json']['ok'] ?? false) === true);
$before = count(json_decode((string)file_get_contents($tmp . '/data/trips.json'), true));
$r = post('/api/trip-delete.php', ['id' => $tripId], $user);
check('trips: the owner can delete a plan; it is gone from the list and the file', ($r['json']['ok'] ?? false) === true && count(post('/api/trips.php', [], $user)['json']['trips'] ?? ['x']) === 0 && count(json_decode((string)file_get_contents($tmp . '/data/trips.json'), true)) === $before - 1);
check('trips: deleting it twice is a 404', post('/api/trip-delete.php', ['id' => $tripId], $user)['status'] === 404);
post('/api/logout.php', [], $admin);
check('after logout the admin session no longer works (401)', post('/api/admin/destinations.php', [], $admin)['status'] === 401);
check('an ordinary user can still log in again', (post('/api/login.php', ['email' => 'user@example.com', 'password' => 'Passw0rd!x'], $other)['json']['ok'] ?? false) === true);

echo "\n$pass passed, $fail failed\n";
echo "(server log: $logFile)\n";
exit($fail ? 1 : 0);
