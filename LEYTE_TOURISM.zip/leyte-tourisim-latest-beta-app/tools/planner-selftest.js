// KYR Web Tourism: tests for js/planner.js (route estimates, weather advisory, opening hours, the automatic one-day trip planner).
//   node tools/planner-selftest.js
// Needs only Node 16+. No server, no network, no PHP. Uses the real data/destinations.json when it exists, otherwise includes/destinations.seed.json.
const fs = require('fs'), path = require('path');
const P = require('../js/planner.js');
let pass = 0, fail = 0;
const check = (name, ok, extra) => { if (ok) { pass++; console.log('PASS  ' + name); } else { fail++; console.log('FAIL  ' + name + (extra ? '  [' + extra + ']' : '')); } };
const near = (a, b, tol) => Math.abs(a - b) <= tol;

/* the destinations, in the shape api/destinations.php sends them */
const file = ['../data/destinations.json', '../includes/destinations.seed.json'].map(f => path.join(__dirname, f)).find(f => fs.existsSync(f));
const raw = JSON.parse(fs.readFileSync(file, 'utf8'));
const PLACES = raw.map((d, i) => ({ id: d.id || 'seed' + i, name: d.name, town: d.town, cats: d.cats || [], area: d.area, feeAmt: d.feeAmt | 0, stay: d.stay || [], hours: d.hours || '',
  lat: typeof d.lat === 'number' ? d.lat : null, lng: typeof d.lng === 'number' ? d.lng : null, ratingAvg: null, ratingCount: 0 }));
const byName = n => PLACES.find(p => p.name === n);
const TAC = P.START_POINTS[0];
const helpers = { isOutdoorCat: c => c === 'beach' || c === 'nature', isSeaCat: c => c === 'beach' };

/* ---- distance and travel estimates ---- */
check('Tacloban to Palo is about 10 km in a straight line', near(P.haversineKm(TAC, P.START_POINTS[1]), 9.7, 0.6), P.haversineKm(TAC, P.START_POINTS[1]));
check('the road estimate is longer than the straight line', (() => { const t = P.travel(TAC, P.START_POINTS[2]); return t.roadKm > t.straightKm && near(t.roadKm / t.straightKm, P.ROAD_FACTOR, 0.02); })());
check('Tacloban to Ormoc is a long drive (over 1.5 h) by the estimate', P.travel(TAC, P.START_POINTS[2]).minutes > 90);
check('two places in the same spot still take the minimum time', P.travel(TAC, TAC).minutes === 5);
check('island destinations need a boat, mainland ones do not', P.needsBoat({ name: 'Kalanggaman Island' }) && P.needsBoat({ name: 'Cuatro Islas' }) && !P.needsBoat({ name: 'Lake Danao Natural Park' }));
check('a boat adds time to the trip', P.travel(TAC, P.START_POINTS[1], 1).minutes === P.travel(TAC, P.START_POINTS[1], 0).minutes + 60 && P.travel(TAC, P.START_POINTS[1], 1).boat === true);
check('coordinates outside Leyte are not usable (typing mistake in the admin)', !P.hasCoords({ lat: 34.877, lng: 103.8 }) && !P.hasCoords({ lat: null, lng: null }) && !P.hasCoords({ lat: 0, lng: 0 }) && P.hasCoords({ lat: 11.2, lng: 125 }));
const r = P.route(TAC, byName('Lake Danao Natural Park'));
check('route(): distance, time and a Google Maps link', r && r.roadKm > 50 && r.minutes > 60 && r.mapsUrl.startsWith('https://www.google.com/maps/dir/?api=1') && r.mapsUrl.includes('origin=11.2444%2C125.0048') && r.mapsUrl.includes('destination=10.9856%2C124.7075'), JSON.stringify(r));
check('route() refuses a place with no usable location', P.route(TAC, { name: 'x', lat: 34.8, lng: 103.8 }) === null);
check('route(): an island destination adds the boat note', P.route(TAC, byName('Kalanggaman Island')).boat === true);
check('route(): from and to the same spot is flagged', P.route(TAC, TAC).sameSpot === true);
check('directionsUrl with stops lists the waypoints separated by |', decodeURIComponent(P.directionsUrl(TAC, TAC, [{ lat: 11.1, lng: 124.9 }, { lat: 11.2, lng: 125 }])).includes('waypoints=11.1,124.9|11.2,125'));

/* ---- clock helpers ---- */
check('fmtTime', P.fmtTime(8 * 60) === '8:00 AM' && P.fmtTime(12 * 60) === '12:00 PM' && P.fmtTime(13 * 60 + 5) === '1:05 PM' && P.fmtTime(0) === '12:00 AM');
check('fmtDuration', P.fmtDuration(45) === '45 min' && P.fmtDuration(60) === '1 h' && P.fmtDuration(95) === '1 h 35 min');
check('parseClock', P.parseClock('08:30') === 510 && P.parseClock('') === null && P.parseClock('25:00') === null);

/* ---- opening hours ---- */
const h1 = P.parseHours('6:00 AM – 5:00 PM');
check('hours: a normal range', h1 && h1.open === 360 && h1.close === 1020 && h1.closedDays.length === 0, JSON.stringify(h1));
const h2 = P.parseHours('9:00 AM – 5:00 PM, closed Mondays');
check('hours: closed Mondays', h2 && h2.open === 540 && h2.close === 1020 && h2.closedDays.join() === '1', JSON.stringify(h2));
check('hours: open 24 hours', (h => h && h.open === 0 && h.close === 1440)(P.parseHours('Open 24 hours')));
check('hours: 12 PM and 12 AM edge cases', (h => h && h.open === 0 && h.close === 720)(P.parseHours('12:00 AM – 12:00 PM')) );
check('hours: text it cannot understand is "unknown" (never blocks a stop)', P.parseHours('Ask the caretaker') === null && P.parseHours('') === null);
check('hours: several closed days', P.parseHours('8 AM - 4 PM, closed Saturdays and Sundays').closedDays.sort().join() === '0,6');

/* ---- weather advisory ---- */
const wx = o => ({ group: 'clear', id: 800, tempC: 29, feelsC: 31, windKph: 10, rainMm: 0, desc: 'Clear sky', ...o });
const lake = byName('Lake Danao Natural Park'), cathedral = byName('Palo Metropolitan Cathedral'), kal = byName('Kalanggaman Island');
check('advisory: no reading = unknown, with a clear message', (a => a.level === 'unknown' && a.reasons.length && a.advice)(P.advisory(null, lake, helpers)));
check('advisory: fine weather = good', P.advisory(wx(), lake, helpers).level === 'good');
check('advisory: a thunderstorm = avoid for an outdoor place', P.advisory(wx({ group: 'thunder', id: 211 }), lake, helpers).level === 'avoid');
check('advisory: a thunderstorm = only caution for an indoor place', P.advisory(wx({ group: 'thunder', id: 211 }), cathedral, helpers).level === 'caution');
check('advisory: light rain = caution outdoors, fine indoors', P.advisory(wx({ group: 'rain', id: 500, rainMm: 1 }), lake, helpers).level === 'caution' && P.advisory(wx({ group: 'rain', id: 500, rainMm: 1 }), cathedral, helpers).level === 'good');
check('advisory: heavy rain = avoid outdoors', P.advisory(wx({ group: 'rain', id: 503, rainMm: 12 }), lake, helpers).level === 'avoid');
check('advisory: strong wind = avoid at sea, caution at 30+', P.advisory(wx({ windKph: 45 }), kal, helpers).level === 'avoid' && P.advisory(wx({ windKph: 33 }), kal, helpers).level === 'caution' && P.advisory(wx({ windKph: 45 }), lake, helpers).level === 'good');
check('advisory: extreme heat = caution', P.advisory(wx({ feelsC: 40 }), lake, helpers).level === 'caution');
check('advisory: every level carries label, icon, reasons and advice', ['good', 'caution', 'avoid', 'unknown'].every(l => P.LEVELS[l].label && P.LEVELS[l].icon));

/* ---- the day planner: invariants every plan must satisfy ---- */
function assertPlan(name, plan, o) {
  const items = plan.items, visits = plan.stops;
  let ok = plan.ok && items[0].type === 'depart' && items[items.length - 1].type === 'return';
  let why = '';
  let t = items[0].at;
  for (const it of items.slice(1)) {
    if (it.type === 'travel') { if (it.at !== t) { ok = false; why = 'travel start ' + it.at + ' != ' + t; } t = it.at + it.minutes; }
    else if (it.type === 'visit') { if (it.arrive !== t || it.begin < it.arrive || it.end <= it.begin) { ok = false; why = 'visit times ' + JSON.stringify(it); } t = it.end; }
    else if (it.type === 'lunch') { if (it.at !== t) { ok = false; why = 'lunch'; } t = it.at + it.minutes; }
    else if (it.type === 'return') { if (it.at !== t) { ok = false; why = 'return ' + it.at + ' != ' + t; } }
  }
  const names = visits.map(v => v.place.name);
  if (new Set(names).size !== names.length) { ok = false; why = 'duplicate stop'; }
  if (visits.length < 1 || visits.length > P.MAX_STOPS) { ok = false; why = 'stop count'; }
  if (t > o.endTime || items[0].at !== o.startTime) { ok = false; why = 'out of the time window ' + t; }
  for (const v of visits) {
    const h = P.parseHours(v.place.hours);
    if (h && (v.begin < h.open || v.end > h.close)) { ok = false; why = 'outside opening hours: ' + v.place.name; }
    if (h && h.closedDays.includes(o.dow)) { ok = false; why = 'closed that day: ' + v.place.name; }
    if (!P.hasCoords(v.place)) { ok = false; why = 'bad coordinates used: ' + v.place.name; }
    if (o.limit !== undefined && v.place.feeAmt > o.limit) { ok = false; why = 'over budget: ' + v.place.name; }
  }
  if (plan.summary.fee !== visits.reduce((a, v) => a + v.fee, 0)) { ok = false; why = 'fee total'; }
  check(name, ok, why);
}
const base = { start: TAC, startTime: 8 * 60, endTime: 18 * 60, budget: 'any', cats: [], dow: 2, lunch: true };   // dow 2 = Tuesday
const tue = P.planDayTrip(PLACES, base, {});
assertPlan('planner: a Tuesday plan from Tacloban is valid (times chain, hours respected, no bad coordinates)', tue, { ...base });
check('planner: the plan has a Google Maps round-trip link with its stops', tue.mapsUrl.startsWith('https://www.google.com/maps/dir/?api=1') && decodeURIComponent(tue.mapsUrl).split('waypoints=')[1].split('|').length === tue.stops.length);
check('planner: the bad-coordinate destination is reported, never planned', (() => { const bad = PLACES.find(p => p.lat !== null && !P.hasCoords(p)); return !bad || (!tue.stops.some(s => s.place.name === bad.name) && tue.skipped.some(s => s.name === bad.name && /location/i.test(s.reason))); })());
check('planner: lunch is scheduled at most once, and a plan that runs past noon has one when there is time', tue.items.filter(i => i.type === 'lunch').length <= 1 && (tue.summary.returnTime < 12 * 60 || tue.summary.lunch));
check('planner: a long day with room for it never skips lunch', (() => { const p = P.planDayTrip(PLACES, { ...base, cats: ['nature'] }, {}); return p.ok && p.items.filter(i => i.type === 'lunch').length === 1; })());
check('planner: lunch can be switched off', P.planDayTrip(PLACES, { ...base, lunch: false }, {}).items.every(i => i.type !== 'lunch'));
const mon = P.planDayTrip(PLACES, { ...base, dow: 1 }, {});
assertPlan('planner: a Monday plan is valid', mon, { ...base, dow: 1 });
check('planner: nothing closed on Mondays is planned on a Monday, and it says why', !mon.stops.some(s => /closed Mondays/.test(s.place.hours)) && mon.skipped.some(s => s.reason === 'Closed on this day'));
const free = P.planDayTrip(PLACES, { ...base, budget: 'free' }, {});
assertPlan('planner: "free only" plans only free places', free, { ...base, limit: 0 });
check('planner: paid places are listed as over budget', free.skipped.some(s => s.reason === 'Over your budget'));
const hist = P.planDayTrip(PLACES, { ...base, cats: ['history'] }, {});
check('planner: interests limit the stops to those categories', hist.ok && hist.stops.every(s => s.place.cats.includes('history')), hist.reason);
const wetCtx = { advisoryFor: p => P.advisory(wx({ group: 'thunder', id: 211 }), p, helpers) };
const wet = P.planDayTrip(PLACES, base, wetCtx);
check('planner: in a thunderstorm no outdoor place is planned; indoor ones come with a caution', wet.ok && wet.stops.every(s => !s.place.cats.some(helpers.isOutdoorCat)) && wet.stops.every(s => s.adv.level === 'caution') && wet.skipped.some(s => /^Weather:/.test(s.reason)), wet.reason);
check('planner: a caution note is added when stops carry cautions', wet.notes.some(n => /weather cautions/i.test(n)));
const cleanCtx = { advisoryFor: p => P.advisory(wx(), p, helpers) };
const fine = P.planDayTrip(PLACES, base, cleanCtx);
assertPlan('planner: with fine weather the plan is valid', fine, base);
check('planner: no live weather is stated in the notes', P.planDayTrip(PLACES, base, {}).notes.includes('Live weather was not considered.') && !fine.notes.includes('Live weather was not considered.'));
const tight = P.planDayTrip(PLACES, { ...base, startTime: 8 * 60, endTime: 9 * 60 + 15 }, {});
check('planner: a window too short for anything says so instead of inventing a plan', tight.ok === false && /fits|fit/i.test(tight.reason), tight.reason);
check('planner: an end time before the start is refused', P.planDayTrip(PLACES, { ...base, endTime: 7 * 60 }, {}).ok === false);
check('planner: a missing starting point is refused', P.planDayTrip(PLACES, { ...base, start: null }, {}).ok === false);
check('planner: no places at all is handled', P.planDayTrip([], base, {}).ok === false);
check('planner: overnight-only places are never in a day plan', (() => { const ov = [{ ...PLACES[2], name: 'Camp Only', stay: ['overnight'] }]; const p = P.planDayTrip(ov, base, {}); return !p.ok && p.skipped.some(s => s.reason === 'Needs an overnight stay'); })());
check('planner: it is deterministic (same input, same plan)', JSON.stringify(P.planDayTrip(PLACES, base, {}).stops.map(s => s.place.name)) === JSON.stringify(tue.stops.map(s => s.place.name)));
check('planner: far places are left out of a short window from Tacloban (Kalanggaman needs a long drive plus a boat)', !P.planDayTrip(PLACES, { ...base, endTime: 14 * 60 }, {}).stops.some(s => s.place.name === 'Kalanggaman Island'));
// ratings influence the choice: with 2 equally good single-stop options and room for only one, the better rated one is picked
(() => {
  const a = { id: 'a', name: 'Place A', cats: ['history'], feeAmt: 0, stay: ['half'], hours: '', lat: 11.20, lng: 125.0, ratingAvg: 2.0, ratingCount: 10 };
  const b = { id: 'b', name: 'Place B', cats: ['history'], feeAmt: 0, stay: ['half'], hours: '', lat: 11.20, lng: 125.0, ratingAvg: 4.8, ratingCount: 10 };
  const p = P.planDayTrip([a, b], { ...base, endTime: 8 * 60 + 150, lunch: false }, {});   // 2.5 h: only one 90-minute stop fits with the driving
  check('planner: with room for one stop the higher-rated place is chosen', p.ok && p.stops.length === 1 && p.stops[0].place.name === 'Place B', JSON.stringify(p.stops.map(s => s.place.name)));
  const lone = { ...a, ratingAvg: 5, ratingCount: 1 }, many = { ...b, name: 'Place C', ratingAvg: 4.0, ratingCount: 20 };
  const q = P.planDayTrip([lone, many], { ...base, endTime: 8 * 60 + 150, lunch: false }, {});
  check('planner: one 5-star review does not beat 20 reviews averaging 4', q.ok && q.stops[0].place.name === 'Place C', q.stops.map(s => s.place.name).join());
})();
// a place that opens late: the plan waits and says so
(() => {
  const late = { id: 'l', name: 'Late Museum', cats: ['history'], feeAmt: 0, stay: ['half'], hours: '10:00 AM – 5:00 PM', lat: 11.20, lng: 125.0, ratingCount: 0 };
  const p = P.planDayTrip([late], { ...base, lunch: false }, {});
  assertPlan('planner: a late-opening place is scheduled at opening time', p, { ...base, lunch: false });
  check('planner: it records the wait and tells the visitor', p.stops[0].begin === 600 && p.stops[0].wait > 0 && p.notes.some(n => /before a place opens/.test(n)));
})();

/* ---- trip plans (Sprint 4): buildItinerary must reproduce the generated plan, and must satisfy the server's rules (includes/trips.php trip_clean) ---- */
// The server's checks, written again here from trips.php so a plan that passes this passes the PHP: leg distance within rounding of the estimate,
// leg time between the base time and base + 120, arrival not before prevEnd + lunch + leg, visit adds up, ends by midnight, return consistent.
function serverAccepts(start, itin, dep) {
  const why = [];
  let prev = start, prevEnd = dep;
  itin.stops.forEach(s => {
    const exp = P.haversineKm(prev, s.place) * P.ROAD_FACTOR, base = Math.max(5, Math.ceil(exp / P.AVG_KPH * 60 / 5) * 5);
    if (Math.abs(s.legKm - Math.round(exp * 10) / 10) > 0.15 + 0.02 * exp) why.push('km ' + s.place.name);
    if (s.legMin < base || s.legMin > base + 120) why.push('min ' + s.place.name);
    if (s.arrive < prevEnd + s.lunchBefore + s.legMin) why.push('arrive ' + s.place.name);
    if (s.begin < s.arrive || s.end !== s.begin + s.visitMin || s.end > 1440) why.push('visit ' + s.place.name);
    if (s.visitMin < 15 || s.visitMin > 480) why.push('visitMin');
    prev = s.place; prevEnd = s.end;
  });
  const expR = P.haversineKm(prev, start) * P.ROAD_FACTOR, baseR = Math.max(5, Math.ceil(expR / P.AVG_KPH * 60 / 5) * 5);
  if (Math.abs(itin.ret.legKm - Math.round(expR * 10) / 10) > 0.15 + 0.02 * expR || itin.ret.legMin < baseR || itin.ret.legMin > baseR + 120) why.push('return leg');
  if (itin.returnTime < prevEnd + itin.returnLunch + itin.ret.legMin || itin.returnTime > 1440) why.push('return time');
  return why;
}
(() => {
  const plan = P.planDayTrip(PLACES, base, {});
  const stops = plan.stops.map(s => ({ place: s.place, visitMin: s.end - s.begin }));
  const it = P.buildItinerary(TAC, stops, { startTime: base.startTime, lunch: true, dow: base.dow });
  check('itinerary: rebuilding a generated day reproduces every arrival, start, end and the return time', it.stops.length === plan.stops.length && it.stops.every((s, i) => s.arrive === plan.stops[i].arrive && s.begin === plan.stops[i].begin && s.end === plan.stops[i].end) && it.returnTime === plan.summary.returnTime, JSON.stringify([it.returnTime, plan.summary.returnTime]));
  check('itinerary: totals match the generated plan (travel time, km, fees)', it.travelMin === plan.summary.travelMin && Math.abs(it.km - plan.summary.km) < 0.11 && it.fee === plan.summary.fee, JSON.stringify([it.travelMin, plan.summary.travelMin, it.km, plan.summary.km]));
  check('itinerary: a rebuilt plan passes every rule the server applies', serverAccepts(TAC, it, base.startTime).length === 0, serverAccepts(TAC, it, base.startTime).join());
  const rev = P.buildItinerary(TAC, stops.slice().reverse(), { startTime: base.startTime, lunch: true, dow: base.dow });
  check('itinerary: reordering the stops gives a valid, recalculated timeline', serverAccepts(TAC, rev, base.startTime).length === 0 && rev.stops[0].place.name === stops[stops.length - 1].place.name);
  const longer = P.buildItinerary(TAC, stops.map(s => ({ ...s, visitMin: s.visitMin + 60 })), { startTime: base.startTime, lunch: true, dow: base.dow });
  check('itinerary: longer visits push the return time later by at least the extra time', longer.returnTime >= it.returnTime + 60 * stops.length - 1 || longer.fits === false);
  const one = P.buildItinerary(TAC, [{ place: byName('Palo Metropolitan Cathedral'), visitMin: 90 }], { startTime: 8 * 60, dow: 2 });
  check('itinerary: a one-stop route is valid and has no lunch', serverAccepts(TAC, one, 480).length === 0 && one.stops[0].lunchBefore === 0 && one.returnLunch === 0);
  const late = P.buildItinerary(TAC, [{ place: byName('Palo Metropolitan Cathedral'), visitMin: 480 }, { place: byName('Lake Danao Natural Park'), visitMin: 480 }], { startTime: 12 * 60, dow: 2 });
  check('itinerary: a plan running past midnight is flagged, not silently accepted', late.fits === false && late.warnings.some(w => /midnight/.test(w)));
  const closed = P.buildItinerary(TAC, [{ place: PLACES.find(p => /closed Mondays/.test(p.hours)), visitMin: 60 }], { startTime: 9 * 60, dow: 1 });
  check('itinerary: a place closed on the trip day gets a warning', closed.stops[0].warn.some(w => /Closed/.test(w)));
  const islandIt = P.buildItinerary(TAC, [{ place: byName('Kalanggaman Island'), visitMin: 120 }], { startTime: 6 * 60, dow: 2 });
  check('itinerary: an island stop carries the boat flag, and still passes the server rules', islandIt.boat === true && islandIt.stops[0].boat === true && serverAccepts(TAC, islandIt, 360).length === 0, serverAccepts(TAC, islandIt, 360).join());
  const tweaked = JSON.parse(JSON.stringify(it)); tweaked.stops[0].legKm += 5;
  check('itinerary: the server-rule checker itself catches a made-up distance (the test is not vacuous)', serverAccepts(TAC, tweaked, base.startTime).length > 0);
})();

console.log(`\n${pass} passed, ${fail} failed`);
process.exit(fail ? 1 : 0);
