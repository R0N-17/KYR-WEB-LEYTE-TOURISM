# Supabase: status and migration plan

**Status: not integrated.** I searched the whole project: there is no Supabase client, URL, key, SQL or reference. All data is in files under `data/` (users.txt, destinations.json, categories.json, reviews.json, trips.json, activity.json) with file locks. Nothing in this sprint was tested against Supabase and nothing claims to be.

## When it is needed
The file store already works across devices **if the site runs on one server with a persistent, writable `data/` folder**. Supabase (Postgres) becomes necessary if you host somewhere with an ephemeral or read-only filesystem, run more than one server, or want real backups, queries and row-level security.

## It is an application-wide migration, not a trip-plans feature
Users, sessions, destinations, categories, reviews, favourites, trip plans and activity all live in the same file layer, and logins are PHP sessions over `users.txt`. Moving only trip plans would leave two storage systems. Suggested order: (1) a small PHP data-access layer behind the existing `db_*`, `dest_*`, `rev_*`, `trip_*`, `act_*` functions (the API files only call those, so the endpoints would not change); (2) a one-time import script from the JSON files; (3) switch each module; (4) retire `data/*.json`.

## Security rules for a PHP + Supabase setup
- Keep the **service-role key and DB password only on the server** (`includes/config.local.php` or environment variables, never in `js/`, never committed). The browser must not talk to Supabase directly while auth is PHP sessions.
- Connect from PHP with PDO (`pgsql`) or Supabase's REST API, using parameter binding.
- Ownership stays enforced in PHP (`WHERE user_id = :me`). If you later move auth to Supabase Auth, add the RLS policies below and use the user's JWT instead of the service key.

## Draft schema (untested; adapt names to your conventions)
```sql
create table trip_plans (
  id            text primary key check (id ~ '^TP-[0-9]{8}-[A-F0-9]{6}$'),
  user_id       uuid not null,                       -- the account (FK to your users table once it exists)
  save_token    text not null,
  title         text not null check (char_length(title) between 1 and 80),
  travel_date   date not null,
  departure_min smallint not null check (departure_min between 0 and 1439),
  travel_mode   text not null default 'driving' check (travel_mode = 'driving'),
  source        text not null default 'custom' check (source in ('route','daytrip','custom')),
  status        text not null default 'planned' check (status in ('planned','completed','cancelled')),
  start_name    text not null, start_lat numeric(9,6) not null, start_lng numeric(9,6) not null,
  return_leg_min smallint not null, return_leg_km numeric(6,1) not null,
  return_lunch_min smallint not null default 0, return_time_min smallint not null,
  total_travel_min int not null, total_km numeric(7,1) not null, total_fee int not null,
  weather       jsonb,                               -- {kind, observedAt, note, items[]}: a snapshot, with the time it was read
  notes         text not null default '' check (char_length(notes) <= 1000),
  created_at    timestamptz not null default now(),
  updated_at    timestamptz not null default now(),
  unique (user_id, save_token)                       -- the duplicate-submit guard
);
create table trip_plan_stops (
  trip_id     text not null references trip_plans(id) on delete cascade,
  stop_order  smallint not null check (stop_order between 1 and 8),
  destination_id text,                               -- no FK: the destination may be deleted later
  name text not null, town text, lat numeric(9,6) not null, lng numeric(9,6) not null,
  fee_text text, fee_amount int not null default 0, hours_text text,   -- snapshot at save time
  arrive_min smallint not null, begin_min smallint not null, end_min smallint not null,
  visit_min smallint not null check (visit_min between 15 and 480),
  leg_min smallint not null, leg_km numeric(6,1) not null, lunch_before_min smallint not null default 0, boat boolean not null default false,
  primary key (trip_id, stop_order)
);
create index on trip_plans (user_id, travel_date desc);
-- one transaction per save: insert the plan and all its stops together (or none).

-- Only if you move to Supabase Auth (auth.uid()); with PHP sessions enforce ownership in PHP instead:
alter table trip_plans enable row level security;
create policy "own plans" on trip_plans using (user_id = auth.uid()) with check (user_id = auth.uid());
alter table trip_plan_stops enable row level security;
create policy "own stops" on trip_plan_stops using (exists (select 1 from trip_plans p where p.id = trip_id and p.user_id = auth.uid()));
```
Favourites (`user_id, destination_id, created_at`, unique pair), reviews (`destination_id, user_id, rating 1-5, comment, created/updated`, unique pair) and the activity log follow the same pattern.

## What I need from you to do it properly
Where the site will be hosted, whether you want Supabase Auth or to keep PHP sessions, and the project URL and database (kept out of the repository).
