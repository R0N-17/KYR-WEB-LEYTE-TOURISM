# Completed-trip History Log and reviews

No new store: a trip is "completed" when its saved plan in `data/trips.json` has `status: completed` (+ `completedAt`). Reviews stay in `data/reviews.json` (one per visitor per destination).

## Rules, all enforced on the server
- Only the plan's owner can complete it: `api/trip-complete.php` {id}. Someone else's / unknown plan = 404. Only a *planned* plan can be completed (cancelled = 409). Repeating it changes nothing (`duplicate: true`, same date).
- A **new** review needs a completed plan of the signed-in user that contains the destination:
  - `api/trip-review.php` {trip, destination, rating, comment}: plan must be the caller's (404), completed (403), contain the destination (404); destination must exist; rating 1-5; written review required (<=1000 chars, no `<` `>`). Create-only: if the user already reviewed that destination (same plan, repeat submit, or another completed plan with it) -> 409, nothing changes (checked inside the reviews file lock).
  - `api/review-save.php` (the destination popup) now applies the same gate for a new review (403). Editing a review you already have is unchanged.
- The reviewer id always comes from the PHP session; ids/status sent by the browser are only looked up, never trusted.
- `api/trip-history.php` returns only the caller's plans. Review state is read live from `data/reviews.json`.
- A completed plan's destinations cannot be swapped while it stays completed (set it back to Planned first).

## Changed / new files
Changed: `includes/trips.php`, `includes/reviews.php`, `api/review-save.php`, `dashboard.html`, `js/dashboard.js`, `js/trips.js`, `js/reviews.js`, `css/dashboard.css`, `tools/selftest.php`, `README.txt`.
New: `api/trip-complete.php`, `api/trip-history.php`, `api/trip-review.php`, `js/trip-history.js`, `TRIP-HISTORY.md`.

## Behaviour notes
- Completion is the owner's own statement (no date check, no proof). The plan editor's Status field can also set it; that stamps the same `completedAt`.
- Deleting a completed plan removes its history entry and review eligibility; reviews already posted stay.
- The destination popup shows "Reviews come from completed trips" instead of the form for visitors who are not eligible.
- Completion is not written to the admin Activity log (reviews still are).

## Tests
`php tools/selftest.php` (section 7b adapted; new section 7d). `node tools/planner-selftest.js` unchanged.
