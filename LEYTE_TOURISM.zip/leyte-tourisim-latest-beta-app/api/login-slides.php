<?php
// Public: the slideshow shown on login.html, register.html and forgot-password.html (photo, title, place, description).
// "custom" is false until an admin saves a change; the pages then keep the slideshow built into their HTML.
require __DIR__ . '/../includes/bootstrap.php';
header('Cache-Control: no-store');
api_handle(fn() => ['custom' => is_file(SLIDE_FILE), 'slides' => array_map('slide_view', slide_read())]);
