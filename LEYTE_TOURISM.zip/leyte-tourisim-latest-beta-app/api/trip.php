<?php
// MY TRIP PLANS: one saved plan in full (the itinerary receipt): {id: "TP-20261025-A1B2C3"}. 404 unless it is the signed-in visitor's own.
require __DIR__ . '/../includes/bootstrap.php';
header('Cache-Control: no-store');
api_handle(function (array $in) {
    $user = auth_require();
    session_write_close();
    return ['trip' => trip_public(trip_get(trim(str_in($in, 'id')), $user['id']))];
});
