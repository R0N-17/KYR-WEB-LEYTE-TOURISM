<?php
// SCRUM-20: ratings and reviews of ONE destination: {destination: "<id>"} -> summary (average, count, stars), reviews (newest first) and the viewer's own review.
// Reading is open to every visitor (like the destination list); "mine" is filled in only when someone is signed in.
require __DIR__ . '/../includes/bootstrap.php';
header('Cache-Control: no-store');
api_handle(function (array $in) {
    $dest = rev_destination_id($in);
    $me = auth_current();
    session_write_close();
    return rev_view($dest, $me['id'] ?? null);
});
