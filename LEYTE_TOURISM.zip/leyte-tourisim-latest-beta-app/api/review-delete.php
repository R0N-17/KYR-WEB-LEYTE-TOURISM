<?php
// SCRUM-20: removes the signed-in visitor's own review of a destination: {destination}. Nobody can delete another visitor's review here.
require __DIR__ . '/../includes/bootstrap.php';
api_handle(function (array $in) {
    $user = auth_require();
    $dest = rev_destination_id($in);
    rev_delete_mine($dest, $user['id']);
    return rev_view($dest, $user['id']);
});
