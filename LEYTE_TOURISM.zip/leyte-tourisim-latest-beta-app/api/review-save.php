<?php
// SCRUM-20: post or edit the signed-in visitor's review of a destination: {destination, rating (1-5), comment (optional)}.
// A NEW review needs a completed trip that includes the destination (403 otherwise). One review per visitor per destination: sending again edits it. The reply is the refreshed reviews view, so the popup redraws from it.
require __DIR__ . '/../includes/bootstrap.php';
api_handle(function (array $in) {
    $user = auth_require();
    $dest = rev_destination_id($in);
    $rating = rev_clean_rating($in);
    $comment = rev_clean_comment($in);
    // Completed-trip rule: a NEW review needs a completed trip of this visitor that includes the destination. Editing a review the visitor already
    // has stays allowed (it was written before, or from a trip they have since changed). The check is made here, on the server, from the stored plans.
    $mineAlready = isset(rev_mine_map($user['id'])[$dest]);
    $tripId = $mineAlready ? null : trip_completed_with($user['id'], $dest);
    if (!$mineAlready && $tripId === null)
        throw new ApiError('You can review a destination after you mark a trip that includes it as completed.', 403);
    $rec = rev_upsert($dest, $user['id'], $rating, $comment, $tripId);
    act_log($user['id'], 'review', $dest);   // SCRUM-22
    return rev_view($dest, $user['id']) + ['saved' => $rec['id']];
});
