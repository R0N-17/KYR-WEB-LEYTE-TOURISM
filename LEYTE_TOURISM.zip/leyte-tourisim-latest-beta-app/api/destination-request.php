<?php
// PUBLIC: a business owner sends a destination for review. No account needed. The values go through dest_clean() (the same validation as the
// admin "Add destination") and are stored as a PENDING request, separate from the live destinations. Returns only a reference number.
require __DIR__ . '/../includes/bootstrap.php';
api_handle(function (array $in) {
    return ['ref' => req_submit($in)['ref'], 'message' => 'Your request was sent for review.'];
});
