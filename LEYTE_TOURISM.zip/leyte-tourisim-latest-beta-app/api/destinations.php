<?php
// SCRUM-16: the public list of destinations. The dashboard and the sign-up questionnaire load their places from here
// (it replaces the PLACES array that used to be written in js/data.js). No login needed: this is public tourism information.
require __DIR__ . '/../includes/bootstrap.php';
header('Cache-Control: no-store');   // always the current list, so a replaced photo's new URL reaches every page load
require __DIR__ . '/../includes/weather.php';   // weather_valid_coords(): only usable coordinates are sent
api_handle(function () {
    $ratings = rev_summaries();   // SCRUM-20: one read of the reviews file for the whole list
    return ['places' => array_map(fn($d) => dest_public($d, $ratings), array_values(dest_all()))];
});
