<?php
// SPRINT 3 (trip history): the signed-in visitor marks one of THEIR OWN planned trips as completed: {id: "TP-20261025-A1B2C3"}.
// Only the owner's plan is touched (anyone else's, or one that does not exist, is the same 404). Repeating the request is harmless:
// the plan is already completed, nothing changes, and "duplicate": true comes back. Opening a destination or a map never calls this.
require __DIR__ . '/../includes/bootstrap.php';
api_handle(function (array $in) {
    $user = auth_require();
    [$trip, $already] = trip_complete(trim(str_in($in, 'id')), $user['id']);
    return ['trip' => trip_public($trip), 'duplicate' => $already];
});
