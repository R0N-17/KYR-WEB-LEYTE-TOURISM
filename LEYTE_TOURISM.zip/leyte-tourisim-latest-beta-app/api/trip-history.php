<?php
// SPRINT 3 (trip history): the signed-in visitor's own trip history: {} -> completed (their COMPLETED plans, each with its destinations and
// a Reviewed / Not Reviewed state per destination) and incomplete (their planned and cancelled plans). Nobody else's trips can come back from here.
require __DIR__ . '/../includes/bootstrap.php';
header('Cache-Control: no-store');
api_handle(function () {
    $user = auth_require();
    session_write_close();
    return trip_history($user['id']);
});
