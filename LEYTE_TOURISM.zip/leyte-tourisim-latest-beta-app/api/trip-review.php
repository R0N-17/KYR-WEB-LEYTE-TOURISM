<?php
// SPRINT 3 (trip history): review a destination from a COMPLETED trip: {trip: "TP-...", destination: "<id>", rating (1-5), comment (optional)}.
// The server decides everything that matters: the reviewer is the signed-in account (a user id sent by the browser is ignored), the trip must be
// theirs (otherwise 404, same as a trip that does not exist), it must be completed, and the destination must be one of its stops.
// One review per visitor per destination (the existing review system). From a trip the review is CREATE-ONLY: if the visitor already reviewed that
// destination (same plan, a second submit, or another completed plan with it) the answer is 409 and nothing changes. Editing is done from the destination page.
require __DIR__ . '/../includes/bootstrap.php';
api_handle(function (array $in) {
    $user = auth_require();
    $tripId = trim(str_in($in, 'trip'));
    $dest = rev_destination_id($in);                 // must be a real destination (404 if it was removed)
    trip_review_check($tripId, $user['id'], $dest);  // owner, completed, and part of that trip
    $rating = rev_clean_rating($in);
    $comment = rev_clean_comment($in);
    if ($comment === '') throw new ApiError('Write a short review of your visit.', 422);   // from a trip the written review is required (the popup form keeps it optional)
    $rec = rev_upsert($dest, $user['id'], $rating, $comment, $tripId, true);
    if ($rec === null) throw new ApiError('You have already reviewed this destination. You can edit your review on the destination page.', 409);
    act_log($user['id'], 'review', $dest);
    $view = rev_view($dest, $user['id']);
    return ['saved' => $rec['id'], 'summary' => $view['summary'], 'mine' => $view['mine']];
});
