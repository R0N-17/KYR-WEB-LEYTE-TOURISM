<?php
// MY TRIP PLANS: save a plan (no "id") or save changes to one of the visitor's own plans ("id").
// Both planners (manual route, automatic one-day trip) send the same body: title, date, departure, start, stops[], returnLegMin/Km, returnTime, notes,
// status, weather, source, and for a NEW plan a "token" (made by the browser for one save attempt, so a repeated submit returns the first copy).
// The server validates everything, re-checks every distance and time against the estimate, and snapshots each destination.
require __DIR__ . '/../includes/bootstrap.php';
api_handle(function (array $in) {
    $user = auth_require();
    $id = $in['id'] ?? null;
    if ($id !== null && $id !== '') {
        if (!is_string($id) || !preg_match('/^TP-\d{8}-[A-F0-9]{6}$/', $id)) throw new ApiError('That trip plan was not found.', 404);
        return ['trip' => trip_public(trip_update($id, $user['id'], $in)), 'duplicate' => false];
    }
    $clean = trip_clean($in);
    [$trip, $dup] = trip_create($user['id'], str_in($in, 'token'), $clean);
    if (!$dup) act_log($user['id'], 'trip_save', null);
    return ['trip' => trip_public($trip), 'duplicate' => $dup];
});
