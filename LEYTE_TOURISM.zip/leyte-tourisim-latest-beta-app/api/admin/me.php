<?php
// SCRUM-16: who is the signed-in admin? Every admin page calls this first. 401 = not signed in, 403 = not an admin.
// pending_requests: how many business destination requests wait for review (shown as a badge in the admin menu).
require __DIR__ . '/../../includes/bootstrap.php';
api_handle(fn() => ['admin' => admin_public(auth_require_admin()) + ['pending_requests' => req_count_pending()]]);
