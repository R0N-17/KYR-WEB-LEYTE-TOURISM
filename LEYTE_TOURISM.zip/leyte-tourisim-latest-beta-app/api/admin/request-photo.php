<?php
// Admin only: shows the photo of a request (the file lives in data/request-photos/, which is not web-accessible). GET ?id=<request id>.
require __DIR__ . '/../../includes/bootstrap.php';
header_remove('Content-Type');
try {
    auth_require_admin();
    $id = is_string($_GET['id'] ?? null) ? $_GET['id'] : '';
    $r = req_all()[$id] ?? null;
    $path = $r ? req_photo_path($r) : null;
    if ($path === null) { http_response_code(404); header('Content-Type: text/plain'); exit('No photo.'); }
    $ext = strtolower(pathinfo($path, PATHINFO_EXTENSION));
    $mime = array_search($ext === 'jpeg' ? 'jpg' : $ext, IMG_TYPES, true) ?: 'application/octet-stream';
    header('Content-Type: ' . $mime);
    header('Content-Security-Policy: default-src \'none\'; sandbox');
    header('Cache-Control: private, max-age=3600');
    readfile($path);
} catch (ApiError $e) {
    http_response_code($e->status); header('Content-Type: text/plain'); echo $e->getMessage();
}
