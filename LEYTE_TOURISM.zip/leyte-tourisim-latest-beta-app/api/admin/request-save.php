<?php
// Admin: correct a pending request without approving it. Body = the same fields the Add destination form sends, plus "id" (the request).
require __DIR__ . '/../../includes/bootstrap.php';
api_handle(function (array $in) {
    auth_require_admin();
    $r = req_save_edit(str_in($in, 'id'), $in);
    return ['request' => req_admin_view($r), 'message' => 'Your corrections to "' . $r['dest']['name'] . '" were saved. It is still pending.'];
});
