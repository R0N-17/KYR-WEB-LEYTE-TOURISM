<?php
// Admin: reject a pending request. Body: { id, reason? }. Nothing is added to the live directory.
require __DIR__ . '/../../includes/bootstrap.php';
api_handle(function (array $in) {
    $admin = auth_require_admin();
    $r = req_reject(str_in($in, 'id'), str_in($in, 'reason'), $admin);
    return ['request' => req_admin_view($r), 'message' => 'The request for "' . ($r['dest']['name'] ?? '') . '" was rejected.'];
});
