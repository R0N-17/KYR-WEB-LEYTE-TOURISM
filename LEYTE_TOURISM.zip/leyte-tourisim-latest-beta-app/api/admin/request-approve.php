<?php
// Admin: approve a pending request. Body = the same fields the Add destination form sends (the admin may have corrected them), plus "id".
// The destination is added to the live directory with dest_insert(), exactly like Add destination. 409 if the name is already taken: the request stays pending.
require __DIR__ . '/../../includes/bootstrap.php';
api_handle(function (array $in) {
    $admin = auth_require_admin();
    [$r, $rec] = req_approve(str_in($in, 'id'), $in, $admin);
    return ['request' => req_admin_view($r), 'destination' => dest_admin_view($rec), 'message' => '"' . $rec['name'] . '" was approved and is now on the public website.'];
});
