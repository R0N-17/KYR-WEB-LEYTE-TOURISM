<?php
// Admin: business destination requests (newest first) with how many there are per status. Body: { status?: pending|approved|rejected, q?: text }.
require __DIR__ . '/../../includes/bootstrap.php';
api_handle(function (array $in) {
    auth_require_admin();
    $all = array_values(req_all());
    $counts = ['pending' => 0, 'approved' => 0, 'rejected' => 0];
    foreach ($all as $r) { $s = $r['status'] ?? 'pending'; if (isset($counts[$s])) $counts[$s]++; }
    $status = str_in($in, 'status');
    $q = mb_strtolower(trim(str_in($in, 'q')));
    $list = array_filter($all, function ($r) use ($status, $q) {
        if ($status !== '' && ($r['status'] ?? '') !== $status) return false;
        if ($q === '') return true;
        $hay = mb_strtolower(($r['dest']['name'] ?? '') . ' ' . ($r['dest']['town'] ?? '') . ' ' . ($r['contact']['name'] ?? '') . ' ' . ($r['contact']['email'] ?? '') . ' ' . ($r['ref'] ?? ''));
        return str_contains($hay, $q);
    });
    usort($list, fn($a, $b) => strcmp((string)($b['submitted'] ?? ''), (string)($a['submitted'] ?? '')));
    return ['requests' => array_map('req_admin_view', $list), 'counts' => $counts];
});
