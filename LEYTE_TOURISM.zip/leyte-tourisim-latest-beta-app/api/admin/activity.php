<?php
// SCRUM-22 (admin): what visitors do. Per destination: opens, favourites, reviews, average rating, trip plans that include it, plus the newest events.
// Counts only; no review text, trip contents or emails. Each part is read separately, so one damaged file never hides the others.
require __DIR__ . '/../../includes/bootstrap.php';
api_handle(function () {
    auth_require_admin();
    $dests = dest_all();
    $users = db_all();
    $events = act_read();

    $views = []; $favs = []; $revN = []; $revSum = []; $plans = [];
    foreach ($events as $e) if ($e['type'] === 'view' && !empty($e['dest'])) $views[$e['dest']] = ($views[$e['dest']] ?? 0) + 1;
    foreach ($users as $u) foreach (array_unique(array_filter((array)($u['favourites'] ?? []), 'is_string')) as $id) $favs[$id] = ($favs[$id] ?? 0) + 1;
    $notes = [];
    try { foreach (rev_read_raw() as $r) { $d = (string)$r['dest']; $revN[$d] = ($revN[$d] ?? 0) + 1; $revSum[$d] = ($revSum[$d] ?? 0) + (int)$r['rating']; } }
    catch (Throwable $e) { $notes[] = 'Reviews could not be read.'; }
    try { foreach (trip_read_raw() as $t) foreach ((array)($t['stops'] ?? []) as $s) { $d = (string)($s['destId'] ?? ''); if ($d !== '') $plans[$d] = ($plans[$d] ?? 0) + 1; } }
    catch (Throwable $e) { $notes[] = 'Trip plans could not be read.'; }

    $rows = [];
    foreach ($dests as $d) {
        $id = (string)$d['id'];
        $rows[] = ['id' => $id, 'name' => (string)$d['name'], 'town' => (string)($d['town'] ?? ''), 'views' => $views[$id] ?? 0, 'favourites' => $favs[$id] ?? 0,
                   'reviews' => $revN[$id] ?? 0, 'avg' => isset($revN[$id]) ? round($revSum[$id] / $revN[$id], 1) : null, 'plans' => $plans[$id] ?? 0];
    }
    usort($rows, fn($a, $b) => [$b['views'], $b['favourites'], $b['reviews'], $b['plans']] <=> [$a['views'], $a['favourites'], $a['reviews'], $a['plans']] ?: strcmp($a['name'], $b['name']));

    $nameOf = fn($id) => isset($dests[$id]) ? (string)$dests[$id]['name'] : null;
    $feed = [];
    foreach (array_slice(array_reverse($events), 0, 60) as $e) {
        $u = $users[$e['uid']] ?? null;
        $feed[] = ['t' => $e['t'], 'type' => $e['type'], 'who' => $u ? trim(($u['first_name'] ?? '') . ' ' . ($u['last_name'] ?? '')) : 'Former visitor',
                   'dest' => !empty($e['dest']) ? ($nameOf($e['dest']) ?? 'Deleted destination') : null];
    }
    $visitors = count(array_filter($users, fn($u) => ($u['role'] ?? 'user') !== 'admin'));
    return ['activity' => ['destinations' => $rows, 'recent' => $feed, 'eventsKept' => count($events), 'eventsMax' => ACT_MAX, 'visitors' => $visitors, 'notes' => $notes]];
});
