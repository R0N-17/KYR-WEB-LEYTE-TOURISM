<?php
// MY TRIP PLANS: the signed-in visitor's saved plans, as list cards (no full itineraries). Upcoming dates first.
require __DIR__ . '/../includes/bootstrap.php';
header('Cache-Control: no-store');
api_handle(function () {
    $user = auth_require();
    session_write_close();
    return ['trips' => trip_list($user['id']), 'max' => TRIP_MAX_PER_USER];
});
