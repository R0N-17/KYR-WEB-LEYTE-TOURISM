<?php
// SCRUM-21: add or remove a destination from the signed-in visitor's favourites: {destination: "<id>", on: true|false}.
// "on" is an explicit state (not a toggle), so a repeated or retried request can never flip it the wrong way.
// Favourites are stored on the account (users.txt, "favourites": destination ids, newest first), so they follow the visitor to any device.
require __DIR__ . '/../includes/bootstrap.php';
api_handle(function (array $in) {
    $user = auth_require();
    $id = trim(str_in($in, 'destination'));
    if ($id === '' || !preg_match('/^[A-Za-z0-9_-]{1,40}$/', $id)) throw new ApiError('Choose a destination.', 422);
    $on = $in['on'] ?? null;
    if (!is_bool($on)) throw new ApiError('Say whether to add or remove this favourite.', 422);
    if ($on && !dest_find($id)) throw new ApiError('That destination no longer exists. Refresh the page.', 404);

    $changed = false;
    $res = db_modify($user['id'], function (array $u) use ($id, $on, &$changed) {
        $favs = array_values(array_filter((array)($u['favourites'] ?? []), 'is_string'));
        $has = in_array($id, $favs, true);
        if ($on && !$has) {
            if (count($favs) >= FAV_MAX) throw new ApiError('You can save up to ' . FAV_MAX . ' favourites. Remove one first.', 422);
            array_unshift($favs, $id);
            $changed = true;
        } elseif (!$on && $has) {
            $favs = array_values(array_diff($favs, [$id]));
            $changed = true;
        }
        return ['favourites' => $favs];
    });
    if ($res === null) throw new ApiError('Please log in again.', 401);
    if ($changed) act_log($user['id'], $on ? 'favourite_add' : 'favourite_remove', $id);
    return ['favourites' => $res['favourites']];
});
