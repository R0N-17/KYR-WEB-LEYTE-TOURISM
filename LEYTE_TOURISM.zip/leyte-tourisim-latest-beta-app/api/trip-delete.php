<?php
// MY TRIP PLANS: delete one of the visitor's own plans: {id}. 404 for anything that is not theirs.
require __DIR__ . '/../includes/bootstrap.php';
api_handle(function (array $in) {
    $user = auth_require();
    trip_delete(trim(str_in($in, 'id')), $user['id']);
    return ['deleted' => true];
});
