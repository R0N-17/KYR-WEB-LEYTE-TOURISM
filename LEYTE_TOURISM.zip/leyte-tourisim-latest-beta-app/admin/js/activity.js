/* Admin Activity page (SCRUM-22). Everything shown comes from api/admin/activity.php: counts per destination and the newest events. Nothing is estimated here. */
(async function () {
  const admin = await Admin.guard('activity');
  if (!admin) return;
  const $ = id => document.getElementById(id), esc = Admin.esc;

  const res = await Admin.api('activity.php');
  if (!res.ok) {
    const e = $('actError'); e.textContent = res.message || 'Could not load the activity.'; e.classList.remove('d-none');
    $('actTable').querySelector('tbody').innerHTML = ''; $('actFeed').innerHTML = '';
    return;
  }
  const a = res.activity;
  if (a.notes && a.notes.length) { const n = $('actNotes'); n.textContent = a.notes.join(' ') + ' The numbers for those columns may be incomplete.'; n.classList.remove('d-none'); }

  const sum = k => a.destinations.reduce((t, d) => t + d[k], 0);
  const stat = (icon, label, num) => `<div class="col-6 col-xl-3"><div class="ad-card ad-stat"><span class="ico"><i class="bi ${icon}" aria-hidden="true"></i></span><div><div class="lbl">${label}</div><div class="num">${num}</div></div></div></div>`;
  $('actStats').innerHTML = stat('bi-people', 'Visitor accounts', a.visitors) + stat('bi-eye', 'Destination opens logged', sum('views')) + stat('bi-heart', 'Favourites saved', sum('favourites')) + stat('bi-journal-check', 'Destinations in trip plans', sum('plans'));

  $('actDestNote').textContent = 'Opens are counted from the newest ' + a.eventsMax + ' events; the other columns are current totals.';
  $('actTable').querySelector('tbody').innerHTML = a.destinations.length ? a.destinations.map(d => `<tr>
      <td><span class="fw-semibold d-block">${esc(d.name)}</span><span class="small text-secondary">${esc(d.town)}</span></td>
      <td class="text-end">${d.views}</td><td class="text-end">${d.favourites}</td><td class="text-end">${d.reviews}</td>
      <td class="text-end">${d.avg === null ? '<span class="text-secondary">–</span>' : d.avg.toFixed(1)}</td><td class="text-end">${d.plans}</td></tr>`).join('')
    : '<tr><td colspan="6" class="p-3 text-secondary">No destinations yet.</td></tr>';

  const WHAT = { view: ['bi-eye', 'opened'], favourite_add: ['bi-heart-fill', 'added to favourites'], favourite_remove: ['bi-heart', 'removed from favourites'], review: ['bi-star', 'posted a review of'], trip_save: ['bi-journal-check', 'saved a trip plan'] };
  $('actFeedNote').textContent = a.recent.length ? 'Newest first' : '';
  $('actFeed').innerHTML = a.recent.length ? a.recent.map(e => {
    const [icon, text] = WHAT[e.type] || ['bi-dot', e.type];
    return `<li><div class="d-flex align-items-center gap-3 px-3 py-2"><span class="ad-thumb flex-shrink-0" aria-hidden="true"><i class="bi ${icon}"></i></span>
      <span><span class="t d-block"><b>${esc(e.who || 'A visitor')}</b> ${esc(text)}${e.dest ? ' <b>' + esc(e.dest) + '</b>' : ''}</span><span class="s">${esc(Admin.fmtDateTime(e.t))}</span></span></div></li>`;
  }).join('') : '<li class="p-3 text-secondary small">No activity yet. It appears here as visitors open destinations, save favourites, post reviews and save trip plans.</li>';
})();
