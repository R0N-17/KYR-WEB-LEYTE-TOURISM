/* Admin > Business requests (admin/requests.html).
   The review form is the SAME form as Add destination (js/dest-form.js), filled with the values the owner sent. The administrator can
   correct anything, then Save corrections, Approve and publish (dest_insert on the server, the same call Add destination uses) or Reject. */
(async function () {
  const admin = await Admin.guard('requests');
  if (!admin) return;
  await Admin.loadCats();

  const $ = id => document.getElementById(id), esc = Admin.esc;
  let items = [], counts = {}, current = null, searchTimer = null, busy = false;

  const formModal = new bootstrap.Modal($('formModal'));
  const rejectModal = new bootstrap.Modal($('rejectModal'));
  const form = $('destForm');

  DestForm.mount($('destFields'), { admin: true });
  DestForm.renderCats(ADMIN_CATS);
  const closeNewCat = DestForm.bindNewCategory(form, Admin);
  const showFormError = msg => { const b = $('formError'); if (!msg) { b.classList.add('d-none'); return; } b.textContent = msg; b.classList.remove('d-none'); b.scrollIntoView({ block: 'nearest', behavior: 'smooth' }); };
  const photoUi = DestForm.photo(() => current && current.destination.image ? '../' + current.destination.image : null, showFormError);

  const STATUS = { pending: ['warn', 'Pending'], approved: ['ok', 'Approved'], rejected: ['muted', 'Rejected'] };
  const badge = s => `<span class="ad-badge ${(STATUS[s] || STATUS.pending)[0]}">${esc((STATUS[s] || STATUS.pending)[1])}</span>`;

  /* ---------- list ---------- */
  async function load() {
    const res = await Admin.api('requests.php', { status: $('statusFilter').value, q: $('searchBox').value });
    const err = $('listError');
    if (!res.ok) { err.textContent = res.message || 'Could not load the requests.'; err.classList.remove('d-none'); return; }
    err.classList.add('d-none');
    items = res.requests; counts = res.counts;
    const total = counts.pending + counts.approved + counts.rejected;
    $('countNote').textContent = total ? `${counts.pending} pending · ${counts.approved} approved · ${counts.rejected} rejected` : '';
    render();
  }
  const thumb = d => d.image ? `<img class="ad-thumb" src="../${esc(d.image)}" alt="" loading="lazy">` : `<span class="ad-thumb" aria-hidden="true"><i class="bi bi-image"></i></span>`;

  function render() {
    if (!items.length) {
      const f = $('statusFilter').value, q = $('searchBox').value.trim();
      $('rows').innerHTML = `<tr><td colspan="6"><div class="ad-empty"><i class="bi bi-inbox" aria-hidden="true"></i>${
        q || (f && f !== 'pending') ? '<div class="t">No matching requests</div>Try a different search or status.'
        : '<div class="t">No pending requests</div>New requests from business owners appear here.'}</div></td></tr>`;
      return;
    }
    $('rows').innerHTML = items.map(r => { const d = r.destination; return `<tr>
      <td><div class="d-flex align-items-center gap-3">${thumb(d)}<div class="min-w-0"><div class="ad-name">${esc(d.name)}</div><div class="ad-sub">${esc(d.town)} · ${esc(r.ref)}</div></div></div></td>
      <td data-label="Submitted by"><div>${esc(r.contact.name)}</div><div class="ad-sub">${esc(r.contact.email)}</div></td>
      <td data-label="Categories">${(d.cats || []).map(c => `<span class="ad-chip">${esc(ADMIN_CATS[c] || c)}</span>`).join('')}</td>
      <td data-label="Sent" class="small text-secondary" title="${esc(Admin.fmtDateTime(r.submitted))}">${esc(Admin.fmtDate(r.submitted))}</td>
      <td data-label="Status">${badge(r.status)}${r.nameTaken ? ' <span class="ad-badge warn" title="A live destination already has this name">Name in use</span>' : ''}</td>
      <td class="ad-actions"><button type="button" class="btn btn-outline-primary" data-id="${esc(r.id)}" aria-label="${r.status === 'pending' ? 'Review' : 'View'} ${esc(d.name)}"><i class="bi bi-${r.status === 'pending' ? 'clipboard-check' : 'eye'}" aria-hidden="true"></i><span class="ms-1">${r.status === 'pending' ? 'Review' : 'View'}</span></button></td></tr>`; }).join('');
  }
  $('rows').addEventListener('click', e => { const b = e.target.closest('button[data-id]'); const r = b && items.find(x => x.id === b.dataset.id); if (r) openReview(r); });
  $('searchBox').addEventListener('input', () => { clearTimeout(searchTimer); searchTimer = setTimeout(load, 250); });
  $('statusFilter').addEventListener('change', load);

  /* ---------- review ---------- */
  function openReview(r) {
    current = r;
    form.reset(); closeNewCat(); form.classList.remove('was-validated'); showFormError('');
    const d = r.destination, pending = r.status === 'pending';
    DestForm.renderCats(ADMIN_CATS);
    DestForm.fill(form, d);
    $('formTitle').textContent = (pending ? 'Review request: ' : 'Request: ') + d.name;
    $('formDesc').textContent = pending ? 'These are the values the owner sent, in the Add destination form. Correct anything that needs it, then approve. Fields marked with * are required.'
                                        : 'This request was already decided. The values below are what was sent.';
    $('reqInfo').innerHTML = `<div class="row g-2 small">
        <div class="col-md-4"><div class="text-secondary">Reference</div><strong>${esc(r.ref)}</strong> ${badge(r.status)}</div>
        <div class="col-md-4"><div class="text-secondary">Submitted by</div>${esc(r.contact.name)}<br><a href="mailto:${esc(r.contact.email)}">${esc(r.contact.email)}</a>${r.contact.phone ? '<br>' + esc(r.contact.phone) : ''}</div>
        <div class="col-md-4"><div class="text-secondary">Sent</div>${esc(Admin.fmtDateTime(r.submitted))}${r.reviewedAt ? `<br><span class="text-secondary">Decided ${esc(Admin.fmtDateTime(r.reviewedAt))}${r.reviewedBy ? ' by ' + esc(r.reviewedBy) : ''}</span>` : ''}</div>
        ${r.reason ? `<div class="col-12"><div class="text-secondary">Reason given</div>${esc(r.reason)}</div>` : ''}
        ${r.status === 'approved' && r.destinationId ? `<div class="col-12"><a href="destinations.html?q=${encodeURIComponent(d.name)}">See it in Destinations</a></div>` : ''}
        ${r.nameTaken ? '<div class="col-12"><div class="alert alert-warning py-2 mb-0">A live destination already has this name. Change the name below, or reject this request.</div></div>' : ''}
      </div>`;
    $('fRemovePhoto').checked = false;
    $('photoLabel').textContent = d.image ? 'Replace the photo' : 'Upload a photo';
    $('removeWrap').classList.toggle('d-none', !d.image || !pending);
    photoUi.set(d.image ? '../' + d.image : null, 'saved');
    $('destSet').disabled = !pending;
    $('reviewFoot').querySelectorAll('#rejectBtn, #correctBtn, #approveBtn').forEach(b => b.classList.toggle('d-none', !pending));
    $('wxText').textContent = 'Fetched automatically from OpenWeather for these coordinates once the destination is published.';
    DestForm.pin.lock(!pending);
    formModal.show();
    $('formModal').addEventListener('shown.bs.modal', DestForm.pin.refresh, { once: true });   // map needs its final size, then shows the submitted pin
  }

  // Same body the Add destination form sends, plus the request id. Returns null (and shows why) if the form is not valid.
  async function body() {
    const problem = DestForm.check(form);
    if (problem) { showFormError(problem); return null; }
    const b = { id: current.id, ...DestForm.collect(form) };
    try { Object.assign(b, await DestForm.photoPayload()); } catch (e) { showFormError('The photo could not be read. Choose it again.'); return null; }
    return b;
  }
  async function act(btn, text, endpoint, getBody) {
    if (busy) return;
    showFormError('');
    const b = await getBody(); if (!b) return;
    busy = true; Admin.loading(btn, true, text);
    const res = await Admin.api(endpoint, b);
    busy = false; Admin.loading(btn, false);
    if (!res.ok) { showFormError(res.message || 'Could not save. Try again.'); if (res.status === 404 || res.status === 409 && /already (approved|rejected)/.test(res.message || '')) load(); return; }
    Admin.toast('success', res.message);
    return res;
  }
  form.addEventListener('submit', async e => {
    e.preventDefault();
    const res = await act($('approveBtn'), 'Approving…', 'request-approve.php', body);
    if (res) { formModal.hide(); load(); }
  });
  $('correctBtn').addEventListener('click', async function () {
    const res = await act(this, 'Saving…', 'request-save.php', body);
    if (res) { current = res.request; await load(); openReview(res.request); }
  });

  /* ---------- reject ---------- */
  $('rejectBtn').addEventListener('click', () => { $('rejectError').classList.add('d-none'); $('rejectReason').value = ''; formModal.hide(); $('formModal').addEventListener('hidden.bs.modal', () => rejectModal.show(), { once: true }); });
  $('rejectModal').addEventListener('hidden.bs.modal', () => { if (!rejected) openReview(current); rejected = false; });
  let rejected = false;
  $('confirmReject').addEventListener('click', async function () {
    if (busy) return;
    busy = true; Admin.loading(this, true, 'Rejecting…');
    const res = await Admin.api('request-reject.php', { id: current.id, reason: $('rejectReason').value });
    busy = false; Admin.loading(this, false);
    if (!res.ok) { const b = $('rejectError'); b.textContent = res.message || 'Could not reject. Try again.'; b.classList.remove('d-none'); return; }
    rejected = true; rejectModal.hide(); Admin.toast('success', res.message); load();
  });

  const params = new URLSearchParams(location.search);
  if (params.get('q')) $('searchBox').value = params.get('q');
  await load();
})();
