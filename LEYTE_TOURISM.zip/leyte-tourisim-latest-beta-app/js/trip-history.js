/* SPRINT 3: completed-trip History Log and destination reviews from a completed trip.
   Loaded after js/trips.js. Uses: api(), notifySuccess/notifyDanger, setLoading, escapeHtml, PLACES, onReviewsChanged (dashboard.js), Trips.refresh (trips.js).
   Server side: api/trip-history.php, api/trip-complete.php, api/trip-review.php (includes/trips.php, includes/reviews.php).
   This file only SHOWS what the server says and builds requests. Who may review what is decided on the server (the buttons here are a convenience, not the rule). */
const TripHistory = (() => {
  const $ = id => document.getElementById(id);
  const esc = s => escapeHtml(s);
  const MAX = 1000;                                    // same limit as the server (REV_COMMENT_MAX)
  const LABELS = ['', 'Poor', 'Fair', 'Good', 'Very good', 'Excellent'];
  let data = null, error = '', loading = false, token = 0;
  const completing = new Set();                        // plans whose "Mark as completed" is in flight: a second click is ignored
  let rv = null;                                       // the review form: {trip, dest, name, town, rating, comment, busy}

  const fmtDate = iso => { const d = new Date(iso); return isNaN(d) ? '' : d.toLocaleDateString(undefined, { year: 'numeric', month: 'short', day: 'numeric' }); };
  const fmtDay = s => { const m = /^(\d{4})-(\d{2})-(\d{2})$/.exec(s || ''); return m ? new Date(+m[1], +m[2] - 1, +m[3]).toLocaleDateString(undefined, { year: 'numeric', month: 'short', day: 'numeric' }) : (s || ''); };
  const badge = (st, text, icon) => `<span class="trip-status trip-${esc(st)}"><i class="bi ${icon}"></i>${text}</span>`;
  const stars = n => `<span class="rv-stars th-stars" role="img" aria-label="${n} out of 5 stars">${[1, 2, 3, 4, 5].map(i => `<i class="bi ${n >= i ? 'bi-star-fill' : 'bi-star'}"></i>`).join('')}</span>`;
  const msg = (icon, title, text, extra) => `<div class="empty-state"><i class="bi ${icon}"></i><p class="fw-semibold mb-1">${esc(title)}</p><p class="small text-secondary mb-${extra ? 3 : 0}">${esc(text)}</p>${extra || ''}</div>`;

  /* ---------- the list ---------- */
  async function load() {
    const mine = ++token;
    loading = true; error = ''; render();
    const res = await api('trip-history.php');
    if (mine !== token) return;                        // a newer load is running
    loading = false;
    if (!res.ok) { error = res.message || "Couldn't load your trip history."; data = null; }
    else data = res;
    render();
  }

  function destRow(trip, d) {
    let action;
    if (d.reviewed) action = `<span class="th-reviewed"><i class="bi bi-check-circle-fill"></i>Reviewed</span>${d.review ? stars(d.review.rating) : ''}`;
    else if (!d.available) action = `<span class="small text-secondary">No longer listed</span>`;
    else action = `<span class="th-notrev">Not Reviewed</span><button type="button" class="btn btn-sm btn-primary" data-th-review="${esc(trip.id)}" data-th-dest="${esc(d.destId)}"><i class="bi bi-star me-1"></i>Leave a Review</button>`;
    return `<li class="th-dest"><div class="th-dest-main"><div class="fw-semibold">${esc(d.name)}</div><div class="small text-secondary">${esc(d.town)}${d.town ? ' · ' : ''}ID ${esc(d.destId)}</div></div><div class="th-dest-act">${action}</div></li>`;
  }
  function completedCard(t) {
    const n = t.destinations.length, done = t.destinations.filter(d => d.reviewed).length;
    return `<article class="th-card"><div class="d-flex flex-wrap justify-content-between align-items-start gap-2 mb-2">
        <div><h4 class="h6 fw-bold mb-1"><button type="button" class="trip-title-link" data-trip-open="${esc(t.id)}">${esc(t.title)}</button></h4>
          <div class="small text-secondary">Completed ${esc(fmtDate(t.completedAt))} · trip date ${esc(fmtDay(t.date))} · ref ${esc(t.id)}</div></div>
        ${badge('completed', 'Completed', 'bi-check-circle')}</div>
      <ul class="th-dests">${t.destinations.map(d => destRow(t, d)).join('')}</ul>
      <div class="d-flex flex-wrap justify-content-between align-items-center gap-2 mt-2"><span class="small text-secondary">${done} of ${n} destination${n === 1 ? '' : 's'} reviewed</span>
        <button type="button" class="btn btn-sm btn-outline-secondary" data-trip-open="${esc(t.id)}"><i class="bi bi-receipt me-1"></i>View plan details</button></div></article>`;
  }
  function incompleteCard(t) {
    const planned = t.status === 'planned';
    return `<article class="th-card th-card-plain"><div class="d-flex flex-wrap justify-content-between align-items-start gap-2 mb-2">
        <div><h4 class="h6 fw-bold mb-1"><button type="button" class="trip-title-link" data-trip-open="${esc(t.id)}">${esc(t.title)}</button></h4>
          <div class="small text-secondary">Planned for ${esc(fmtDay(t.date))} · ${t.stopCount} destination${t.stopCount === 1 ? '' : 's'}: ${esc(t.stopNames.join(', '))}${t.stopCount > t.stopNames.length ? '…' : ''}</div></div>
        ${planned ? badge('planned', 'Planned', 'bi-calendar-event') : badge('cancelled', 'Cancelled', 'bi-x-circle')}</div>
      <div class="d-flex flex-wrap gap-2">${planned ? `<button type="button" class="btn btn-sm btn-success" data-trip-complete="${esc(t.id)}"><i class="bi bi-check2-circle me-1"></i>Mark as completed</button>` : ''}
        <button type="button" class="btn btn-sm btn-outline-secondary" data-trip-open="${esc(t.id)}"><i class="bi bi-receipt me-1"></i>View plan</button></div></article>`;
  }

  function render() {
    const el = $('tripHistoryBody');
    if (!el) return;
    if (loading && !data) { el.innerHTML = `<div class="empty-state"><span class="spinner-border spinner-border-sm mb-2" aria-hidden="true"></span><p class="small text-secondary mb-0">Loading your trips…</p></div>`; return; }
    if (error) { el.innerHTML = msg('bi-wifi-off', "Couldn't load your trip history", error, '<button type="button" class="btn btn-outline-secondary btn-sm" data-th-retry>Try again</button>'); return; }
    if (!data) { el.innerHTML = ''; return; }
    if (!data.completed.length && !data.incomplete.length) {
      el.innerHTML = msg('bi-signpost-split', 'No trips yet', 'Save a trip plan, then mark it completed after you go. Completed trips appear here, and you can review their places.', '<a href="#planner/trip" class="btn btn-primary btn-sm" data-view="planner/trip">Plan a trip</a>');
      return;
    }
    const done = data.completed.length
      ? data.completed.map(completedCard).join('')
      : msg('bi-check2-circle', 'No completed trips yet', 'Mark a planned trip as completed after you go, and it will show up here with a Leave a Review button for each place.');
    const todo = data.incomplete.length
      ? data.incomplete.map(incompleteCard).join('')
      : `<p class="small text-secondary mb-0">No planned trips waiting.</p>`;
    el.innerHTML = `<h3 class="th-group">Completed trips <span class="th-count">${data.completed.length}</span></h3><div class="th-list">${done}</div>
      <h3 class="th-group mt-4">Planned and other trips <span class="th-count">${data.incomplete.length}</span></h3>
      <p class="small text-secondary">These are not completed, so their destinations cannot be reviewed yet.</p><div class="th-list">${todo}</div>`;
  }

  /* ---------- mark a planned trip as completed ---------- */
  async function complete(id, btn) {
    if (completing.has(id)) return;                    // double click: ignored here, and harmless on the server too
    completing.add(id); setLoading(btn, true, 'Saving…');
    const res = await api('trip-complete.php', { id });
    completing.delete(id);
    if (!res.ok) { setLoading(btn, false); notifyDanger("Couldn't mark the trip as completed", res.message || 'Try again.'); return; }
    notifySuccess(res.duplicate ? 'Already completed' : 'Trip marked as completed', res.trip.title + ' is in your History Log. You can now review its places.');
    if (typeof Trips !== 'undefined') Trips.refresh();
    load();
  }

  /* ---------- the review form ---------- */
  function setError(text) { const e = $('trvError'); e.textContent = text || ''; e.classList.toggle('d-none', !text); }
  function drawStars() {
    $('trvStars').innerHTML = [1, 2, 3, 4, 5].map(n => `<button type="button" class="rv-pick ${rv.rating >= n ? 'on' : ''}" data-trv-star="${n}" role="radio" aria-checked="${rv.rating === n}" aria-label="${n} star${n === 1 ? '' : 's'}"><i class="bi ${rv.rating >= n ? 'bi-star-fill' : 'bi-star'}"></i></button>`).join('');
    $('trvLabel').textContent = LABELS[rv.rating] || 'Choose a rating';
  }
  function openReview(tripId, destId) {
    const t = data && data.completed.find(x => x.id === tripId), d = t && t.destinations.find(x => x.destId === destId);
    if (!d || d.reviewed || !d.available) return;
    rv = { trip: tripId, dest: destId, name: d.name, town: d.town, rating: 0, comment: '', busy: false };
    $('trvName').textContent = d.name; $('trvTown').textContent = d.town || '';
    $('trvComment').value = ''; $('trvCount').textContent = `0 / ${MAX}`; setError('');
    $('trvSubmit').disabled = false; drawStars();
    bootstrap.Modal.getOrCreateInstance($('tripReviewModal')).show();
  }
  async function submitReview() {
    if (!rv || rv.busy) return;
    rv.comment = $('trvComment').value;
    if (!rv.rating) return setError('Choose a star rating from 1 to 5.');
    if (!rv.comment.trim()) return setError('Write a short review of your visit.');
    if (/[<>]/.test(rv.comment)) return setError("The review can't contain the characters < or >.");
    if (rv.comment.length > MAX) return setError(`Keep your review to ${MAX} characters or fewer.`);
    rv.busy = true; setError('');
    const btn = $('trvSubmit'); setLoading(btn, true, 'Submitting…');
    const sent = rv;
    // The browser says WHICH trip and destination; the server decides whether this account may review it. No user id is sent.
    const res = await api('trip-review.php', { trip: sent.trip, destination: sent.dest, rating: sent.rating, comment: sent.comment });
    sent.busy = false; setLoading(btn, false);
    if (!res.ok) {
      setError(res.message || "Couldn't submit your review. Try again.");   // the typed text stays in the box
      if (res.status === 409 || /already reviewed/i.test(res.message || '')) load();
      return;
    }
    rv = null;
    bootstrap.Modal.getInstance($('tripReviewModal')).hide();
    const p = (typeof PLACES !== 'undefined') && PLACES.find(x => x.id === sent.dest);   // keep the cards' "★ 4.5 (12)" in step
    if (p && res.summary) { p.ratingAvg = res.summary.avg; p.ratingCount = res.summary.count; if (typeof onReviewsChanged === 'function') onReviewsChanged(); }
    notifySuccess('Review submitted', `Thanks for reviewing ${sent.name}.`);
    load();
  }

  /* ---------- wiring ---------- */
  document.addEventListener('click', e => {
    let el;
    if ((el = e.target.closest('[data-trip-complete]'))) { complete(el.dataset.tripComplete, el); return; }
    if ((el = e.target.closest('[data-th-review]'))) { openReview(el.dataset.thReview, el.dataset.thDest); return; }
    if (e.target.closest('[data-th-retry]')) { load(); return; }
    if ((el = e.target.closest('[data-trv-star]'))) { rv.comment = $('trvComment').value; rv.rating = +el.dataset.trvStar; setError(''); drawStars(); const b = $('trvStars').querySelector(`[data-trv-star="${rv.rating}"]`); if (b) b.focus(); }
  });
  $('trvComment').addEventListener('input', e => { $('trvCount').textContent = `${e.target.value.length} / ${MAX}`; });
  $('trvForm').addEventListener('submit', e => { e.preventDefault(); submitReview(); });

  return { onShow: load };
})();

// Landed directly on #history (a refresh or a bookmark): dashboard.js showed the section, now fill it.
if (location.hash.slice(1).split('/')[0] === 'history') TripHistory.onShow();
