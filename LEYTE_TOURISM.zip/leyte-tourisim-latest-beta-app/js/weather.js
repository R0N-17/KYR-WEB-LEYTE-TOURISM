/* Live weather from OpenWeather (through api/weather.php, so the API key stays on the server).
   Load after common.js and data.js, before dashboard.js. */
const Weather = (() => {
  let data = null, updated = 0, stale = false, error = '', loading = false;
  const esc = s => String(s).replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));

  // OpenWeather condition code -> simple group
  function group(id) {
    if (id >= 200 && id < 300) return 'thunder';
    if (id >= 300 && id < 400) return 'drizzle';
    if (id >= 500 && id < 600) return 'rain';
    if (id >= 700 && id < 800) return 'mist';
    if (id === 800) return 'clear';
    if (id === 801 || id === 802) return 'partly';
    return 'cloudy';
  }
  function icon(id, night) {
    switch (group(id)) {
      case 'thunder': return 'bi-cloud-lightning-rain';
      case 'drizzle': return 'bi-cloud-drizzle';
      case 'rain':    return id >= 502 ? 'bi-cloud-rain-heavy' : 'bi-cloud-rain';
      case 'mist':    return 'bi-cloud-fog2';
      case 'clear':   return night ? 'bi-moon-stars' : 'bi-sun';
      case 'partly':  return night ? 'bi-cloud-moon' : 'bi-cloud-sun';
      default:        return 'bi-clouds';
    }
  }
  const isWet = g => g === 'thunder' || g === 'rain';

  // A short, place-aware tip built from the live reading.
  function tip(w, place) {
    const g = w.group, outdoors = place && place.cats.some(isOutdoorCat);   // "outdoor" is a flag on each category (admin console)
    const beach = place && place.cats.some(isSeaCat);
    if (g === 'thunder') return 'Thunderstorm nearby. Postpone boat trips and hikes, and stay indoors if you can.';
    if (g === 'rain')    return outdoors ? 'Rain now. Trails and boat rides can be slippery or unsafe; consider a museum or church instead.' : 'Rainy right now. Bring an umbrella.';
    if (g === 'drizzle') return 'Light drizzle. Bring a rain jacket.';
    if (beach && w.windKph >= 35) return 'Windy. The sea may be rough, so check with boat operators before going.';
    if (w.feelsC >= 38)  return 'Feels very hot. Go early or late in the day and bring water and sun protection.';
    if (g === 'clear' && !w.night) return beach ? 'Great beach weather. Bring sunscreen and plenty of water.' : 'Clear skies and good visibility.';
    if (w.tempC <= 25 && outdoors) return 'Cool air. A light jacket is a good idea.';
    return 'Comfortable conditions for a visit.';
  }

  // A reading older than this is never presented as current weather.
  const MAX_AGE_S = 3 * 3600;
  const age = r => Math.max(0, Math.floor(Date.now() / 1000) - (r.observed || updated || 0));

  // Everything the UI needs for one place (null when there is no usable reading).
  // Old readings (see MAX_AGE_S) are treated as missing, unless the caller asks for them with { allowOld: true }
  // and then shows them as old (the details popup does).
  function info(name, opts) {
    const r = data && data[name];
    if (!r) return null;
    const old = age(r) > MAX_AGE_S;
    if (old && !(opts && opts.allowOld)) return null;
    const place = (typeof PLACES !== 'undefined') && PLACES.find(p => p.name === name);
    const w = { ...r, group: group(r.id), old };
    w.icon = icon(r.id, r.night);
    w.wet = isWet(w.group) || (place && place.cats.some(isSeaCat) && r.windKph >= 40);
    w.tip = tip(w, place);
    return w;
  }

  function stamp() {
    if (!updated) return '';
    const t = new Date(updated * 1000).toLocaleTimeString(undefined, { hour: 'numeric', minute: '2-digit' });
    return `Live from OpenWeather · updated ${t}${stale ? ' (temporarily showing older readings)' : ''}`;
  }

  async function load() {
    loading = true;
    try {
      const res = await api('weather.php');
      // ok + notice = some readings could be served but a refresh failed; the notice says why (shown if no usable reading is left).
      if (res.ok) { data = res.weather; updated = res.updated; stale = !!res.stale; error = res.notice || ''; }
      // The server could not be reached at all: say so in plain words (api() words that for the person setting the site up).
      else error = res.offline ? "Can't reach the weather service right now. Check your connection and try again." : (res.message || 'Weather unavailable.');
      return !!res.ok;
    } finally { loading = false; }
  }

  // SCRUM-18: the advisory for one destination (good / caution / avoid / unknown) from its live reading. The rules live in js/planner.js so they can be tested on their own.
  // No usable reading (still loading, unavailable, too old) gives the "unknown" advisory, never a guess.
  function advisory(name) {
    const place = (typeof PLACES !== 'undefined') && PLACES.find(p => p.name === name);
    return Planner.advisory(info(name), place || null, { isOutdoorCat, isSeaCat });
  }

  return { load, info, advisory, stamp, esc, updatedAt: () => updated, get live() { return !!data; }, get error() { return error; }, get loading() { return loading; } };
})();
