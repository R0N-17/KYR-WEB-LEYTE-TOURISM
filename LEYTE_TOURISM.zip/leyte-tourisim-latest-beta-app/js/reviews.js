/* SCRUM-20: ratings and reviews of a destination (shown at the bottom of the destination popup).
   Needs js/common.js (api) and js/data.js (PLACES, escHtml). It talks to api/reviews.php, api/review-save.php and api/review-delete.php.
   Every review text is escaped before it is drawn, and shown with its line breaks. */
const Reviews = (() => {
  const MAX = 1000;                       // same limit as the server (REV_COMMENT_MAX)
  let place = null, token = 0;            // the destination being shown; token drops answers that arrive after the popup moved on
  let view = null;                        // last server answer: {summary, reviews, mine}
  let draft = { rating: 0, comment: '' }; // what the visitor has typed but not posted
  let confirmDelete = false, busy = false, error = '', loadError = '';
  const box = () => document.getElementById('dmReviews');

  // Five stars for a value from 0 to 5 (half stars for averages).
  function stars(value, extra) {
    const v = Number(value) || 0;
    let out = '';
    for (let i = 1; i <= 5; i++) out += `<i class="bi ${v >= i - 0.25 ? 'bi-star-fill' : v >= i - 0.75 ? 'bi-star-half' : 'bi-star'}"></i>`;
    return `<span class="rv-stars ${extra || ''}" role="img" aria-label="${v.toFixed(1)} out of 5 stars">${out}</span>`;
  }
  // Small "★ 4.5 (12)" label for cards. Nothing at all for a place with no reviews.
  function chip(p) {
    const n = Number(p && p.ratingCount) || 0;
    if (!n || !Number.isFinite(Number(p.ratingAvg))) return '';
    return `<span class="rating-chip" title="${Number(p.ratingAvg).toFixed(1)} out of 5, from ${n} review${n === 1 ? '' : 's'}"><i class="bi bi-star-fill"></i>${Number(p.ratingAvg).toFixed(1)}<small>(${n})</small></span>`;
  }
  // Rating line for destination cards: "★ 4.8 (24)", or a quiet "☆ No ratings yet". Reads only what the server sent (ratingAvg / ratingCount,
  // worked out from the saved reviews in includes/reviews.php); nothing is calculated or invented here.
  function rating(p) {
    const n = Number(p && p.ratingCount) || 0, avg = Number(p && p.ratingAvg);
    if (!n || !Number.isFinite(avg) || p.ratingAvg === null) return `<span class="rating-line is-empty" title="No reviews yet"><i class="bi bi-star" aria-hidden="true"></i>No ratings yet</span>`;
    return `<span class="rating-line" title="${avg.toFixed(1)} out of 5, from ${n} review${n === 1 ? '' : 's'}" aria-label="Rated ${avg.toFixed(1)} out of 5 from ${n} review${n === 1 ? '' : 's'}"><i class="bi bi-star-fill" aria-hidden="true"></i><strong>${avg.toFixed(1)}</strong><small>(${n})</small></span>`;
  }
  const fmtDate = iso => { const d = new Date(iso); return isNaN(d) ? '' : d.toLocaleDateString(undefined, { year: 'numeric', month: 'short', day: 'numeric' }); };

  function summaryHtml(s) {
    if (!s.count) return `<div class="rv-summary rv-summary-empty"><i class="bi bi-chat-square-heart"></i><div><strong>No reviews yet</strong><div class="small">Be the first to rate this place after you visit.</div></div></div>`;
    const bars = [5, 4, 3, 2, 1].map(n => {
      const c = (s.dist && s.dist[n]) || 0, pct = Math.round(c / s.count * 100);
      return `<div class="rv-bar"><span>${n}<i class="bi bi-star-fill"></i></span><div class="rv-track"><div style="width:${pct}%"></div></div><span class="rv-n">${c}</span></div>`;
    }).join('');
    return `<div class="rv-summary"><div class="rv-score"><div class="rv-big">${Number(s.avg).toFixed(1)}</div>${stars(s.avg)}<div class="small">${s.count} review${s.count === 1 ? '' : 's'}</div></div><div class="rv-bars">${bars}</div></div>`;
  }

  // Not eligible: a NEW review needs a completed trip that includes this place (the server enforces it; this just says so instead of showing a form that would be refused).
  function lockedHtml() {
    return `<div class="rv-summary rv-summary-empty"><i class="bi bi-signpost-split"></i><div><strong>Reviews come from completed trips</strong><div class="small">Plan a trip that includes this place and mark it completed. Then you can review it from your <a href="#history" data-view="history" data-bs-dismiss="modal">History Log</a>.</div></div></div>`;
  }

  function formHtml() {
    const mine = view.mine;
    if (!mine && !view.canReview) return lockedHtml();
    const pick = [1, 2, 3, 4, 5].map(n => `<button type="button" class="rv-pick ${draft.rating >= n ? 'on' : ''}" data-rv-star="${n}" role="radio" aria-checked="${draft.rating === n}" aria-label="${n} star${n === 1 ? '' : 's'}"><i class="bi ${draft.rating >= n ? 'bi-star-fill' : 'bi-star'}"></i></button>`).join('');
    const labels = ['', 'Poor', 'Fair', 'Good', 'Very good', 'Excellent'];
    return `<form class="rv-form" id="rvForm" novalidate>
      <h4 class="rv-sub">${mine ? 'Your review' : 'Rate this destination'}</h4>
      <div class="rv-pickrow"><div class="rv-picks" role="radiogroup" aria-label="Your rating">${pick}</div><span class="rv-picklabel" id="rvPickLabel">${labels[draft.rating] || 'Choose a rating'}</span></div>
      <textarea class="form-control rv-text-in" id="rvComment" rows="3" maxlength="${MAX}" placeholder="Share what you liked, or tips for other visitors (optional)" aria-label="Your review">${escHtml(draft.comment)}</textarea>
      <div class="rv-foot"><span class="small rv-count" id="rvCount">${draft.comment.length} / ${MAX}</span><div class="rv-actions">
        ${mine ? (confirmDelete
          ? `<span class="small me-1">Delete your review?</span><button type="button" class="btn btn-sm btn-danger" data-rv-action="delete-yes" ${busy ? 'disabled' : ''}>Yes, delete</button><button type="button" class="btn btn-sm btn-outline-secondary" data-rv-action="delete-no">Keep it</button>`
          : `<button type="button" class="btn btn-sm btn-outline-danger" data-rv-action="delete" ${busy ? 'disabled' : ''}><i class="bi bi-trash3 me-1"></i>Delete</button>`) : ''}
        ${confirmDelete ? '' : `<button type="submit" class="btn btn-sm btn-primary" ${busy ? 'disabled' : ''}>${busy ? 'Saving…' : mine ? 'Update review' : 'Post review'}</button>`}
      </div></div>
      <div class="rv-error ${error ? '' : 'd-none'}" role="alert" id="rvError">${escHtml(error)}</div>
    </form>`;
  }

  function listHtml() {
    const list = view.reviews;
    if (!list.length) return '';
    const more = view.summary.count > list.length ? `<p class="small rv-more">Showing the newest ${list.length} of ${view.summary.count} reviews.</p>` : '';
    return `<ul class="rv-list">${list.map(r => `<li class="rv-item ${r.mine ? 'is-mine' : ''}">
      <div class="rv-itemhead"><strong>${escHtml(r.author)}</strong>${r.mine ? '<span class="rv-you">You</span>' : ''}${stars(r.rating, 'rv-stars-sm')}<span class="rv-date">${escHtml(fmtDate(r.date))}${r.edited ? ' · edited' : ''}</span></div>
      ${r.comment ? `<p class="rv-text">${escHtml(r.comment)}</p>` : ''}</li>`).join('')}</ul>${more}`;
  }

  function render() {
    const el = box();
    if (!el) return;
    if (loadError) { el.innerHTML = `<h3 class="dm-h">Ratings &amp; reviews</h3><div class="rv-state"><i class="bi bi-wifi-off"></i><div><strong>Couldn't load the reviews</strong><div class="small">${escHtml(loadError)}</div></div><button type="button" class="btn btn-sm btn-outline-secondary ms-auto" data-rv-action="retry">Try again</button></div>`; return; }
    if (!view) { el.innerHTML = `<h3 class="dm-h">Ratings &amp; reviews</h3><div class="rv-state"><span class="spinner-border spinner-border-sm" aria-hidden="true"></span><span>Loading reviews…</span></div>`; return; }
    el.innerHTML = `<h3 class="dm-h">Ratings &amp; reviews</h3>${summaryHtml(view.summary)}${formHtml()}${listHtml()}`;
  }

  // Keeps the cards (which show "★ 4.5 (12)") in step with what was just saved: the place in PLACES gets the new numbers, then the page redraws.
  function syncPlace() {
    if (!place || !view) return;
    const p = PLACES.find(x => x.id === place.id);
    if (p) { p.ratingAvg = view.summary.avg; p.ratingCount = view.summary.count; }
    if (typeof onReviewsChanged === 'function') onReviewsChanged();
  }

  async function load(p) {
    place = p; view = null; loadError = ''; error = ''; confirmDelete = false; busy = false;
    draft = { rating: 0, comment: '' };
    const mine = ++token;
    render();
    const res = await api('reviews.php', { destination: p.id });
    if (mine !== token) return;   // another destination was opened meanwhile
    if (!res.ok) { loadError = res.message || 'Could not load the reviews.'; render(); return; }
    view = res;
    if (res.mine) draft = { rating: res.mine.rating, comment: res.mine.comment || '' };
    render();
    syncPlace();                  // the popup knows the exact numbers, so the card behind it can too
  }

  async function submit() {
    if (busy || !place || !view) return;
    const text = (document.getElementById('rvComment') || {}).value || '';
    draft.comment = text;
    error = '';
    if (!draft.rating) { error = 'Choose a star rating first.'; render(); return; }
    if (text.length > MAX) { error = `Keep your review to ${MAX} characters or fewer.`; render(); return; }
    busy = true; render();
    const mine = token;
    const res = await api('review-save.php', { destination: place.id, rating: draft.rating, comment: text });
    if (mine !== token) return;
    busy = false;
    if (!res.ok) { error = res.message || 'Could not save your review.'; render(); return; }
    const wasEdit = !!view.mine;
    view = res; draft = { rating: res.mine.rating, comment: res.mine.comment || '' };
    render(); syncPlace();
    if (typeof notifySuccess === 'function') notifySuccess(wasEdit ? 'Review updated' : 'Review posted', `Thanks for rating ${place.name}.`);
  }

  async function remove() {
    if (busy || !place) return;
    busy = true; error = ''; render();
    const mine = token;
    const res = await api('review-delete.php', { destination: place.id });
    if (mine !== token) return;
    busy = false; confirmDelete = false;
    if (!res.ok) { error = res.message || 'Could not delete your review.'; render(); return; }
    view = res; draft = { rating: 0, comment: '' };
    render(); syncPlace();
    if (typeof notifyDanger === 'function') notifyDanger('Review deleted', 'Your review was removed.');
  }

  // One set of listeners on the container, so redrawing the HTML never loses them.
  function bind() {
    const el = box();
    if (!el || el.dataset.bound) return;
    el.dataset.bound = '1';
    el.addEventListener('click', e => {
      const star = e.target.closest('[data-rv-star]');
      if (star) { draft.comment = (document.getElementById('rvComment') || {}).value || draft.comment; draft.rating = +star.dataset.rvStar; error = ''; render(); const b = el.querySelector(`[data-rv-star="${draft.rating}"]`); if (b) b.focus(); return; }
      const act = e.target.closest('[data-rv-action]');
      if (!act) return;
      draft.comment = (document.getElementById('rvComment') || {}).value ?? draft.comment;
      if (act.dataset.rvAction === 'delete') { confirmDelete = true; render(); }
      else if (act.dataset.rvAction === 'delete-no') { confirmDelete = false; render(); }
      else if (act.dataset.rvAction === 'delete-yes') remove();
      else if (act.dataset.rvAction === 'retry' && place) load(place);
    });
    el.addEventListener('input', e => {
      if (e.target.id !== 'rvComment') return;
      draft.comment = e.target.value;
      const c = document.getElementById('rvCount');
      if (c) c.textContent = `${e.target.value.length} / ${MAX}`;
    });
    el.addEventListener('submit', e => { e.preventDefault(); submit(); });
  }

  return { load, chip, rating, stars, bind };
})();
