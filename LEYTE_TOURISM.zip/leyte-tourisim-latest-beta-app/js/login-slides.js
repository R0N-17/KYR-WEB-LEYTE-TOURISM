/* Login, register and forgot-password pages: shows the slideshow the admin set up in Settings.
   Until an admin saves a change, the slideshow written in each page's HTML stays as it is. If the server can't be reached, it stays too. */
(async function () {
  const carousel = document.getElementById('placeCarousel');
  if (!carousel) return;
  let res;
  try {
    const r = await fetch('api/login-slides.php', { method: 'POST', headers: { 'Content-Type': 'application/json' }, credentials: 'same-origin', body: '{}' });
    res = await r.json();
  } catch (e) { return; }
  if (!res || !res.ok || !res.custom || !Array.isArray(res.slides) || !res.slides.length) return;

  const inner = carousel.querySelector('.carousel-inner'), dots = carousel.querySelector('.carousel-indicators');
  const art = [...inner.querySelectorAll('.carousel-item')].map(i => i.querySelector('.slide-art'));   // the 4 drawn scenes, reused for slides without a photo
  const el = (tag, cls, text) => { const n = document.createElement(tag); if (cls) n.className = cls; if (text) n.textContent = text; return n; };

  inner.textContent = ''; dots.textContent = '';
  res.slides.forEach((s, i) => {
    const item = el('div', 'carousel-item' + (i === 0 ? ' active' : ''));
    if (s.image) {
      const img = el('img', 'slide-photo'); img.src = s.image; img.alt = ''; item.appendChild(img);
    } else if (s.builtin !== null && art[s.builtin]) {
      item.appendChild(art[s.builtin]);
    } else {
      const a = el('div', 'slide-art'); a.style.background = 'linear-gradient(160deg,#3A2388,#150C34)'; item.appendChild(a);
    }
    const cap = el('div', 'slide-caption');
    cap.appendChild(el('strong', '', s.title));
    if (s.place) cap.appendChild(el('span', '', s.place));
    if (s.text) cap.appendChild(el('small', '', s.text));
    item.appendChild(cap);
    inner.appendChild(item);

    const b = el('button'); b.type = 'button'; b.dataset.bsTarget = '#placeCarousel'; b.dataset.bsSlideTo = String(i); b.setAttribute('aria-label', s.title);
    if (i === 0) { b.className = 'active'; b.setAttribute('aria-current', 'true'); }
    dots.appendChild(b);
  });
  dots.classList.toggle('d-none', res.slides.length < 2);

  if (window.bootstrap) {   // restart the carousel on the new slides
    const old = bootstrap.Carousel.getInstance(carousel); if (old) old.dispose();
    new bootstrap.Carousel(carousel, { ride: 'carousel', interval: 5500, pause: 'hover' });
  }
})();
