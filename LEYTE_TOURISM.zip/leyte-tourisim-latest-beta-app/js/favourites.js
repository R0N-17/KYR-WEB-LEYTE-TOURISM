/* SCRUM-21: favourite destinations (the heart on cards and in the destination popup, and the "Your favorites" list on the History Log page).
   Saved on the account through api/favourites.php (explicit on/off, so a retry can never flip it), so they follow the visitor to any device.
   Loaded BEFORE dashboard.js on purpose: its click handler must run first so a heart tap does not also open the card behind it. */
const Favs = (() => {
  let ids = [];                 // destination ids, newest first
  const pending = new Set();    // ids with a request in flight: further taps on the same heart are ignored until it answers
  const has = id => ids.includes(id);

  // The heart button. data-fav = destination id, data-name = for the screen-reader label.
  function btn(p, cls) {
    const on = has(p.id);
    return `<button type="button" class="fav-btn ${cls || ''} ${on ? 'on' : ''}" data-fav="${escHtml(p.id)}" data-name="${escHtml(p.name)}" aria-pressed="${on}" aria-label="${on ? 'Remove ' : 'Add '}${escHtml(p.name)} ${on ? 'from' : 'to'} favourites"><i class="bi ${on ? 'bi-heart-fill' : 'bi-heart'}"></i></button>`;
  }
  function paint(b) {
    const on = has(b.dataset.fav);
    b.classList.toggle('on', on);
    b.setAttribute('aria-pressed', on);
    b.setAttribute('aria-label', `${on ? 'Remove' : 'Add'} ${b.dataset.name} ${on ? 'from' : 'to'} favourites`);
    const i = b.querySelector('i'); if (i) i.className = 'bi ' + (on ? 'bi-heart-fill' : 'bi-heart');
  }
  function sync() {
    document.querySelectorAll('[data-fav]').forEach(paint);
    if (typeof renderFavList === 'function') renderFavList();
  }
  function load(list) { ids = Array.isArray(list) ? list.filter(x => typeof x === 'string') : []; sync(); }

  async function set(id, on) {
    if (pending.has(id)) return;
    const before = ids.slice();
    ids = on ? [id, ...ids.filter(x => x !== id)] : ids.filter(x => x !== id);   // shown at once; rolled back if the server says no
    pending.add(id); sync();
    const res = await api('favourites.php', { destination: id, on });
    pending.delete(id);
    if (!res.ok) {
      ids = before; sync();
      if (typeof notifyDanger === 'function') notifyDanger("Couldn't update your favourites", res.message || 'Try again.');
      return;
    }
    ids = res.favourites;   // the server's list is the truth (e.g. an older device had changed it)
    sync();
    const p = typeof PLACES !== 'undefined' && PLACES.find(x => x.id === id);
    if (typeof notifySuccess === 'function' && p) notifySuccess(on ? 'Added to favourites' : 'Removed from favourites', p.name);
  }

  document.addEventListener('click', e => {
    const b = e.target.closest('[data-fav]');
    if (!b) return;
    e.preventDefault(); e.stopImmediatePropagation();   // do not also open the card / popup behind the heart
    set(b.dataset.fav, !has(b.dataset.fav));
  });
  document.addEventListener('keydown', e => {   // Enter / Space on a heart must not open the card it sits on
    if ((e.key === 'Enter' || e.key === ' ') && e.target.closest && e.target.closest('[data-fav]')) e.stopImmediatePropagation();
  });

  return { btn, load, has, ids: () => ids.slice(), sync };
})();
