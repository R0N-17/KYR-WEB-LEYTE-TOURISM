/* SCRUM-17 (route planning), SCRUM-18 (weather advisory on the route) and SCRUM-19 (automatic one-day trip): the "Trip Planner" screen.
   Loaded LAST, after dashboard.js, because it uses its globals: PLACES, CATS, BUDGETS, savedPrefs, Weather, Reviews, placeThumb, escapeHtml.
   The calculations are in js/planner.js. Everything shown here is an ESTIMATE and says so; Google Maps (opened in a new tab, no API key) gives real directions. */
const PlannerUI = (() => {
  const $ = id => document.getElementById(id);
  const esc = s => escapeHtml(s);
  const P = Planner;
  let inited = false, tab = 'route';
  let touched = { trip: false };          // once the visitor changes interests or budget, preferences no longer overwrite them
  let lastTrip = null;                    // {plan, opts, date} of the generated day on screen, so "Review and save" can turn it into a trip plan
  let lastRoute = null;                   // {from, to} of the route on screen, so its weather box can update when the live weather arrives
  let locating = false;

  const placesWithCoords = () => PLACES.filter(P.hasCoords).sort((a, b) => a.name.localeCompare(b.name));
  const todayStr = () => { const d = new Date(); return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`; };
  const dowOf = str => { const m = /^(\d{4})-(\d{2})-(\d{2})$/.exec(str || ''); return m ? new Date(+m[1], +m[2] - 1, +m[3]).getDay() : new Date().getDay(); };
  const nowMinutes = () => { const d = new Date(); return d.getHours() * 60 + d.getMinutes(); };
  const km = n => `${n.toFixed(1).replace(/\.0$/, '')} km`;

  /* ---------- "My location" (browser geolocation; asked only when the visitor picks it) ---------- */
  function locate() {
    return new Promise(resolve => {
      if (!navigator.geolocation) return resolve({ error: "This browser can't share your location. Pick a starting point from the list." });
      navigator.geolocation.getCurrentPosition(
        pos => {
          const pt = { name: 'Your location', lat: pos.coords.latitude, lng: pos.coords.longitude };
          resolve(P.hasCoords(pt) ? { point: pt } : { error: 'Your location looks to be outside Leyte, so a route from there is not shown. Pick a starting point from the list.' });
        },
        err => resolve({ error: err && err.code === 1 ? 'Location access was blocked. Allow it in your browser, or pick a starting point from the list.' : "Couldn't get your location. Pick a starting point from the list." }),
        { timeout: 10000, maximumAge: 60000 });
    });
  }

  // 'sp:tacloban' | 'd:<destination id>' | 'gps'  ->  {name, lat, lng, place?} or {error}
  async function resolvePoint(value) {
    if (value === 'gps') { locating = true; const r = await locate(); locating = false; return r; }
    if (value.startsWith('sp:')) { const sp = P.START_POINTS.find(s => 'sp:' + s.id === value); return sp ? { point: sp } : { error: 'Choose a starting point.' }; }
    if (value.startsWith('d:')) { const pl = PLACES.find(p => 'd:' + p.id === value); return pl && P.hasCoords(pl) ? { point: { name: pl.name, lat: pl.lat, lng: pl.lng, place: pl } } : { error: 'That destination has no usable map location.' }; }
    return { error: 'Choose a starting point.' };
  }

  /* ---------- Form options ---------- */
  function fillSelects() {
    const dests = placesWithCoords();
    const destOpts = dests.map(p => `<option value="d:${esc(p.id)}">${esc(p.name)} (${esc(p.town)})</option>`).join('');
    const startOpts = P.START_POINTS.map(s => `<option value="sp:${s.id}">${esc(s.name)}</option>`).join('') + '<option value="gps">My current location</option>';
    const keep = (sel, html, fallback) => { const el = $(sel), old = el.value; el.innerHTML = html; if ([...el.options].some(o => o.value === old)) el.value = old; else if (fallback !== undefined) el.value = fallback; };
    keep('routeFrom', `<optgroup label="Starting points">${startOpts}</optgroup>${dests.length ? `<optgroup label="Destinations">${destOpts}</optgroup>` : ''}`, 'sp:tacloban');
    keep('routeTo', `<option value="">Choose a destination…</option>${destOpts}`, '');
    keep('tripStart', startOpts, 'sp:tacloban');
    // Interests and budget start from the saved preferences, until the visitor changes them here.
    const cats = $('tripCats'), selected = touched.trip ? [...cats.querySelectorAll('input:checked')].map(i => i.value) : (savedPrefs.cats || []);
    cats.innerHTML = CATS.map(([key, icon, text]) => `<input class="btn-check" type="checkbox" id="tripCat-${esc(key)}" value="${esc(key)}" ${selected.includes(key) ? 'checked' : ''}>
      <label class="cat-pill" for="tripCat-${esc(key)}"><i class="bi ${esc(icon)}"></i><span>${esc(text)}</span></label>`).join('');
    const bud = $('tripBudget'), oldBud = bud.value;
    bud.innerHTML = BUDGETS.map(([v, , title]) => `<option value="${v}">${esc(title)}</option>`).join('');
    bud.value = touched.trip && oldBud ? oldBud : (savedPrefs.budget || 'any');
    const d = $('tripDate'); d.min = todayStr(); if (!d.value || d.value < d.min) d.value = d.min;
  }

  /* ---------- Weather advisory markup (SCRUM-18) ---------- */
  function advisoryHtml(a, title) {
    const reasons = (a.reasons || []).map(r => `<li>${esc(r)}</li>`).join('');
    const stamp = Weather.live && a.level !== 'unknown' ? Weather.stamp() : '';
    return `<div class="adv-box adv-${a.level}" role="status"><div class="adv-head"><i class="bi ${a.icon}"></i><div><div class="adv-title">${esc(title || 'Weather advisory')}</div><strong>${esc(a.label)}</strong></div></div>
      ${reasons ? `<ul class="adv-reasons">${reasons}</ul>` : ''}${a.advice ? `<p class="adv-advice">${esc(a.advice)}</p>` : ''}${stamp ? `<p class="adv-stamp">${esc(stamp)}. Current conditions only, not a forecast.</p>` : ''}</div>`;
  }
  function advisoryBadge(a) { return `<span class="adv-badge adv-${a.level}" title="${esc((a.reasons || []).join(' '))}"><i class="bi ${a.icon}"></i>${esc(a.label)}</span>`; }

  /* ---------- Sketch map ---------- */
  function sketchMap(from, to) {
    const pts = placesWithCoords(), all = [...pts, from, to];
    const lats = all.map(p => p.lat), lngs = all.map(p => p.lng);
    const minLat = Math.min(...lats), maxLat = Math.max(...lats), minLng = Math.min(...lngs), maxLng = Math.max(...lngs);
    const k = Math.cos(((minLat + maxLat) / 2) * Math.PI / 180), W = 340, H = 250, m = 30;
    const w = Math.max(0.01, (maxLng - minLng) * k), h = Math.max(0.01, maxLat - minLat);
    const s = Math.min((W - 2 * m) / w, (H - 2 * m) / h);
    const ox = (W - w * s) / 2, oy = (H - h * s) / 2;
    const X = p => ox + (p.lng - minLng) * k * s, Y = p => oy + (maxLat - p.lat) * s;
    const label = (p, cls) => { const x = X(p), y = Y(p), right = x > W * 0.6; const t = String(p.name).length > 24 ? String(p.name).slice(0, 23) + '…' : p.name; return `<text class="map-label ${cls}" x="${(right ? x - 9 : x + 9).toFixed(1)}" y="${(y + 4).toFixed(1)}" text-anchor="${right ? 'end' : 'start'}">${esc(t)}</text>`; };
    const same = Math.abs(X(from) - X(to)) < 2 && Math.abs(Y(from) - Y(to)) < 2;
    return `<svg class="route-map" viewBox="0 0 ${W} ${H}" role="img" aria-label="Sketch map from ${esc(from.name)} to ${esc(to.name)}">
      <rect class="map-bg" x="0" y="0" width="${W}" height="${H}" rx="14"></rect>
      ${pts.map(p => `<circle class="map-dot" cx="${X(p).toFixed(1)}" cy="${Y(p).toFixed(1)}" r="3"></circle>`).join('')}
      ${same ? '' : `<line class="map-line" x1="${X(from).toFixed(1)}" y1="${Y(from).toFixed(1)}" x2="${X(to).toFixed(1)}" y2="${Y(to).toFixed(1)}"></line>`}
      <circle class="map-from" cx="${X(from).toFixed(1)}" cy="${Y(from).toFixed(1)}" r="6"></circle><circle class="map-to" cx="${X(to).toFixed(1)}" cy="${Y(to).toFixed(1)}" r="6"></circle>
      ${label(from, 'map-label-from')}${same ? '' : label(to, 'map-label-to')}</svg>`;
  }

  /* ---------- SCRUM-17: point to point ---------- */
  function routeMessage(icon, title, text) {
    $('routeResult').innerHTML = `<div class="empty-state"><i class="bi ${icon}"></i><p class="fw-semibold mb-1">${esc(title)}</p><p class="small text-secondary mb-0">${esc(text)}</p></div>`;
  }

  // Is the destination open when the visitor would get there? Based on the opening hours text; a text we can't read says nothing.
  function openingNote(place, minutesAway) {
    const h = place && P.parseHours(place.hours);
    if (!h) return '';
    const now = new Date(), arrive = now.getHours() * 60 + now.getMinutes() + minutesAway;
    if (h.closedDays.includes(now.getDay())) return `<div class="route-note route-warn"><i class="bi bi-calendar-x"></i>${esc(place.name)} is closed today (hours: ${esc(place.hours)}).</div>`;
    if (arrive >= 1440) return '';
    if (arrive > h.close) return `<div class="route-note route-warn"><i class="bi bi-clock-history"></i>If you leave now you would arrive about ${P.fmtTime(arrive)}, after closing time (${P.fmtTime(h.close)}).</div>`;
    if (arrive < h.open) return `<div class="route-note"><i class="bi bi-clock"></i>It opens at ${P.fmtTime(h.open)}. If you leave now you would arrive early.</div>`;
    return `<div class="route-note route-ok"><i class="bi bi-clock"></i>Open when you would arrive (hours: ${esc(place.hours)}).</div>`;
  }

  function renderRoute(from, to) {
    lastRoute = { from, to };
    const r = P.route(from, to);
    if (!r) return routeMessage('bi-geo-alt', 'No route to show', 'One of the places has no usable map location.');
    const place = to.place || null;
    const arrive = nowMinutes() + r.minutes;
    const adv = place ? Weather.advisory(place.name) : null;
    $('routeResult').innerHTML = `<div class="plan-card">
      <div class="plan-head"><div><div class="small text-secondary">From</div><strong>${esc(from.name)}</strong></div><i class="bi bi-arrow-right"></i><div><div class="small text-secondary">To</div><strong>${esc(to.name)}</strong>${place ? `<div class="small text-secondary">${esc(place.town)}</div>` : ''}</div></div>
      ${r.sameSpot ? `<div class="route-note"><i class="bi bi-geo-alt"></i>These two places are at the same spot.</div>` : `
      <div class="stat-row">
        <div class="stat-tile"><i class="bi bi-signpost-split"></i><strong>${km(r.roadKm)}</strong><span>est. road distance</span><small>${km(r.straightKm)} in a straight line</small></div>
        <div class="stat-tile"><i class="bi bi-clock"></i><strong>${P.fmtDuration(r.minutes)}</strong><span>est. travel time</span><small>${r.boat ? 'includes a boat crossing' : 'by road'}</small></div>
        <div class="stat-tile"><i class="bi bi-flag"></i><strong>${arrive < 1440 ? P.fmtTime(arrive) : 'Tomorrow'}</strong><span>if you leave now</span><small>${P.fmtTime(nowMinutes())} now</small></div>
      </div>`}
      ${r.boat ? `<div class="route-note route-warn"><i class="bi bi-water"></i>This trip needs a boat crossing. Boat times are rough estimates, so confirm the schedule and the sea conditions with the boat operators.</div>` : ''}
      ${r.sameSpot ? '' : openingNote(place, r.minutes)}
      ${adv ? advisoryHtml(adv, `Weather advisory for ${to.name}`) : ''}
      ${place && place.getThere ? `<div class="route-directions"><h4 class="rv-sub">Getting there</h4><p class="mb-0">${esc(place.getThere)}</p></div>` : ''}
      <div class="route-map-wrap">${sketchMap(from, to)}<p class="small text-secondary mb-0">Sketch map for orientation, not for navigation.</p></div>
      <div class="d-flex flex-wrap gap-2 mt-3">
        ${place ? `<button type="button" class="btn btn-primary" data-trip-new="route"><i class="bi bi-journal-plus me-1"></i>Save as trip plan</button>` : ''}
        <a class="btn btn-outline-primary" href="${esc(r.mapsUrl)}" target="_blank" rel="noopener noreferrer"><i class="bi bi-map me-1"></i>Open in Google Maps</a>
        ${place ? `<button type="button" class="btn btn-outline-secondary" data-place="${esc(place.name)}"><i class="bi bi-info-circle me-1"></i>View destination details</button>` : ''}
      </div>
      <p class="small text-secondary mt-3 mb-0">Distance and time are estimates from the straight-line distance (roads ${Math.round((P.ROAD_FACTOR - 1) * 100)}% longer, about ${P.AVG_KPH} km/h). Google Maps shows the real route and live traffic.</p>
    </div>`;
  }

  async function planRoute() {
    const toVal = $('routeTo').value;
    if (!toVal) return routeMessage('bi-geo-alt', 'Choose a destination', 'Pick where you want to go.');
    const btn = $('routeGo');
    btn.disabled = true;
    if ($('routeFrom').value === 'gps') routeMessage('bi-crosshair', 'Finding your location…', 'Allow location access if your browser asks.');
    const [f, t] = [await resolvePoint($('routeFrom').value), await resolvePoint(toVal)];
    btn.disabled = false;
    if (f.error) return routeMessage('bi-geo-alt-fill', "Couldn't use that starting point", f.error);
    if (t.error) return routeMessage('bi-geo-alt-fill', "Couldn't use that destination", t.error);
    if (f.point.place && t.point.place && f.point.place.id === t.point.place.id) return routeMessage('bi-arrow-left-right', 'Pick two different places', 'The starting point and the destination are the same.');
    renderRoute(f.point, t.point);
  }

  /* ---------- SCRUM-19: one-day trip ---------- */
  function tripMessage(icon, title, text, extra) {
    $('tripResult').innerHTML = `<div class="empty-state"><i class="bi ${icon}"></i><p class="fw-semibold mb-1">${esc(title)}</p><p class="small text-secondary mb-0">${esc(text)}</p>${extra || ''}</div>`;
  }
  const feeText = p => p.fee || (p.feeAmt ? `₱${p.feeAmt} entrance fee` : 'Free');

  function renderTrip(plan, weatherLine) {
    const S = plan.summary;
    const items = plan.items.map(it => {
      switch (it.type) {
        case 'depart': return `<li class="tl-end"><i class="bi bi-house-door"></i><div>Leave <strong>${esc(it.place.name)}</strong> at <strong>${P.fmtTime(it.at)}</strong></div></li>`;
        case 'return': return `<li class="tl-end"><i class="bi bi-flag"></i><div>Back at <strong>${esc(it.place.name)}</strong> about <strong>${P.fmtTime(it.at)}</strong></div></li>`;
        case 'lunch':  return `<li class="tl-lunch"><i class="bi bi-cup-hot"></i><div>Lunch break · ${it.minutes} min <span class="text-secondary">(${P.fmtTime(it.at)})</span></div></li>`;
        case 'travel': return `<li class="tl-leg"><i class="bi ${it.boat ? 'bi-water' : 'bi-car-front'}"></i><div>${P.fmtDuration(it.minutes)} · about ${km(it.km)}${it.boat ? ' · includes a boat crossing' : ''}<span class="text-secondary"> to ${esc(it.to.name)}</span></div></li>`;
        case 'visit': {
          const p = it.place, n = plan.stops.indexOf(it) + 1;
          const showAdv = it.adv && it.adv.level !== 'unknown';
          return `<li class="tl-stop"><span class="tl-num">${n}</span><div class="tl-card">
            <div class="tl-top">${placeThumb(p, 'sm')}<div class="min-w-0"><button type="button" class="tl-name" data-place="${esc(p.name)}">${esc(p.name)}</button><div class="small text-secondary"><i class="bi bi-geo-alt me-1"></i>${esc(p.town)} ${Reviews.chip(p)}</div></div></div>
            <div class="tl-times"><span><i class="bi bi-clock me-1"></i>Arrive <strong>${P.fmtTime(it.arrive)}</strong></span><span>Stay about <strong>${P.fmtDuration(it.end - it.begin)}</strong></span><span>Leave <strong>${P.fmtTime(it.end)}</strong></span></div>
            ${it.wait > 0 ? `<div class="route-note"><i class="bi bi-hourglass-split"></i>Opens at ${P.fmtTime(it.begin)}. Wait about ${P.fmtDuration(it.wait)}.</div>` : ''}
            <div class="small tl-meta"><span><i class="bi bi-cash-coin me-1"></i>${esc(feeText(p))}</span>${it.hours ? `<span><i class="bi bi-door-open me-1"></i>${esc(it.hours)}</span>` : ''}</div>
            ${showAdv ? `<div class="mt-2">${advisoryBadge(it.adv)}${it.adv.level !== 'good' ? `<span class="small ms-2">${esc(it.adv.reasons[0] || '')}</span>` : ''}</div>` : ''}
          </div></li>`; }
      }
      return '';
    }).join('');
    const skipped = plan.skipped.length ? `<details class="tl-skipped"><summary>Left out of this plan (${plan.skipped.length})</summary><ul>${plan.skipped.map(s => `<li><strong>${esc(s.name)}</strong> <span class="text-secondary">· ${esc(s.reason)}</span></li>`).join('')}</ul></details>` : '';
    const notes = [weatherLine, ...plan.notes].filter(Boolean).map(n => `<li>${esc(n)}</li>`).join('');
    $('tripResult').innerHTML = `<div class="plan-card">
      <div class="stat-row">
        <div class="stat-tile"><i class="bi bi-geo-alt"></i><strong>${S.stops}</strong><span>stop${S.stops === 1 ? '' : 's'}</span></div>
        <div class="stat-tile"><i class="bi bi-car-front"></i><strong>${P.fmtDuration(S.travelMin)}</strong><span>est. travel</span><small>about ${km(S.km)}</small></div>
        <div class="stat-tile"><i class="bi bi-cash-coin"></i><strong>${S.fee ? '₱' + S.fee : 'Free'}</strong><span>entrance fees</span><small>per person</small></div>
        <div class="stat-tile"><i class="bi bi-flag"></i><strong>${P.fmtTime(S.returnTime)}</strong><span>back by</span></div>
      </div>
      <ol class="tl">${items}</ol>
      ${notes ? `<ul class="plan-notes">${notes}</ul>` : ''}
      ${skipped}
      <div class="d-flex flex-wrap gap-2 mt-3"><button type="button" class="btn btn-primary" data-trip-new="daytrip"><i class="bi bi-journal-plus me-1"></i>Review and save as trip plan</button>
        <a class="btn btn-outline-primary" href="${esc(plan.mapsUrl)}" target="_blank" rel="noopener noreferrer"><i class="bi bi-map me-1"></i>Open whole trip in Google Maps</a></div>
      <p class="small text-secondary mt-2 mb-0">Nothing is saved until you press “Review and save”. There you can reorder or remove stops and change how long you stay.</p>
      <p class="small text-secondary mt-3 mb-0">Times are estimates (about ${P.AVG_KPH} km/h on roads ${Math.round((P.ROAD_FACTOR - 1) * 100)}% longer than a straight line). Visit lengths are typical, and opening hours come from the destination details. Google Maps shows live traffic.</p>
    </div>`;
  }

  async function planTrip() {
    const btn = $('tripGo');
    const startT = P.parseClock($('tripStartTime').value), endT = P.parseClock($('tripEndTime').value);
    if (startT === null || endT === null) return tripMessage('bi-clock', 'Choose start and end times', 'Both times are needed.');
    if (!$('tripDate').value || $('tripDate').value < todayStr()) return tripMessage('bi-calendar-x', 'Choose today or a later date', 'A trip cannot be planned for a day that has passed.');
    btn.disabled = true;
    if ($('tripStart').value === 'gps') tripMessage('bi-crosshair', 'Finding your location…', 'Allow location access if your browser asks.');
    const s = await resolvePoint($('tripStart').value);
    btn.disabled = false;
    if (s.error) return tripMessage('bi-geo-alt-fill', "Couldn't use that starting point", s.error);

    const date = $('tripDate').value, isToday = date === todayStr();
    // Weather is only used for today: OpenWeather's free plan gives current conditions, not a forecast.
    const useWeather = isToday && Weather.live;
    let weatherLine = '';
    if (!isToday) weatherLine = 'Live weather only applies to today, so it was not used for this date. Check the forecast before you go.';
    else if (!Weather.live) weatherLine = "Live weather isn't available right now, so the plan was made without it. Check the weather before you leave.";
    else weatherLine = 'Planned with live weather. It shows current conditions, not a forecast.';

    const opts = { start: s.point, startTime: startT, endTime: endT, budget: $('tripBudget').value, dow: dowOf(date), lunch: $('tripLunch').checked,
      cats: [...$('tripCats').querySelectorAll('input:checked')].map(i => i.value) };
    const plan = P.planDayTrip(PLACES, opts, useWeather ? { advisoryFor: p => Weather.advisory(p.name) } : {});
    if (!plan.ok) {
      const left = plan.skipped.length ? `<details class="tl-skipped mt-3 text-start"><summary>Why places were left out (${plan.skipped.length})</summary><ul>${plan.skipped.map(x => `<li><strong>${esc(x.name)}</strong> <span class="text-secondary">· ${esc(x.reason)}</span></li>`).join('')}</ul></details>` : '';
      return tripMessage('bi-calendar2-x', 'No trip to suggest', plan.reason, left);
    }
    lastTrip = { plan, opts, date };
    renderTrip(plan, weatherLine);
    $('tripResult').scrollIntoView({ behavior: 'smooth', block: 'start' });
  }

  /* ---------- Tabs, wiring ---------- */
  function setTab(t) {
    tab = t === 'trip' ? 'trip' : 'route';
    document.querySelectorAll('[data-ptab]').forEach(b => { const on = b.dataset.ptab === tab; b.classList.toggle('active', on); b.setAttribute('aria-selected', on); });
    $('ptab-route').classList.toggle('d-none', tab !== 'route');
    $('ptab-trip').classList.toggle('d-none', tab !== 'trip');
  }

  function init() {
    if (inited) return;
    inited = true;
    document.querySelectorAll('[data-ptab]').forEach(b => b.addEventListener('click', () => { setTab(b.dataset.ptab); history.replaceState(null, '', '#planner/' + tab); }));
    $('routeForm').addEventListener('submit', e => { e.preventDefault(); planRoute(); });
    $('tripForm').addEventListener('submit', e => { e.preventDefault(); planTrip(); });
    $('routeSwap').addEventListener('click', () => {      // swap From and To (only when both are destinations)
      const f = $('routeFrom'), t = $('routeTo'), a = f.value, b = t.value;
      if (!b) return;
      if (![...f.options].some(o => o.value === b) || ![...t.options].some(o => o.value === a)) { routeMessage('bi-arrow-left-right', "Can't swap these", 'Only a destination can be the end of a route. Pick a destination as the starting point to swap.'); return; }
      f.value = b; t.value = a; planRoute();
    });
    $('tripCats').addEventListener('change', () => { touched.trip = true; });
    $('tripBudget').addEventListener('change', () => { touched.trip = true; });
    $('tripPrefs').addEventListener('click', () => { touched.trip = false; fillSelects(); notifySuccess('Using your saved preferences', 'Interests and budget were reset to what you saved.'); });
  }

  return {
    // Called by dashboard.js when the planner opens, and when destinations or categories were reloaded.
    onShow(t) { init(); fillSelects(); setTab(t || tab); },
    refresh() { if (inited) fillSelects(); },
    // "Plan a route here" in the destination popup: open the planner with this destination chosen, and show the route at once.
    routeTo(place) { init(); fillSelects(); setTab('route'); const v = 'd:' + place.id; if ([...$('routeTo').options].some(o => o.value === v)) { $('routeTo').value = v; planRoute(); } else routeMessage('bi-geo-alt', 'No map location', `${place.name} has no usable map location yet, so a route cannot be shown.`); },
    getLastRoute: () => lastRoute,
    getLastTrip: () => lastTrip,
    // Live weather just arrived: update the weather box of a route that is already on screen.
    onWeather() { if (inited && lastRoute && !$('ptab-route').classList.contains('d-none') && !locating) renderRoute(lastRoute.from, lastRoute.to); }
  };
})();

// Landed directly on #planner (a shared link or a refresh): dashboard.js showed the section, now fill it.
(function () { const h = location.hash.slice(1); if (h === 'planner' || h.startsWith('planner/')) PlannerUI.onShow(h.split('/')[1]); })();
