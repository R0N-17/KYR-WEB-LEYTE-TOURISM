/* SCRUM-17 / SCRUM-18 / SCRUM-19: route planning, weather advisory and the automatic one-day trip planner.
   PURE LOGIC ONLY: no DOM, no network, no globals from the other scripts, so it can be tested in Node (tools/planner-selftest.js).
   The screens live in js/planner-ui.js.

   IMPORTANT, and the screens say it too: distances and travel times are ESTIMATES. The straight-line distance between two coordinates
   is multiplied by a road factor and divided by an average speed. No routing service and no API key is used. For real turn-by-turn
   directions and live traffic the screens open the same two places in Google Maps (directionsUrl). */
(function (root) {
  'use strict';

  /* ---------- Assumptions (change here, everything follows) ---------- */
  const ROAD_FACTOR = 1.4;     // roads wind: the road is about 40% longer than the straight line
  const AVG_KPH = 40;          // average over provincial roads and towns, including slowdowns
  const MIN_LEG_MIN = 5;       // no trip between two places takes less than this
  const BOAT_EXTRA_MIN = 60;   // an island destination needs a boat crossing each way (extra to the road time)
  const LUNCH_MIN = 45;
  const LUNCH_FROM = 11 * 60 + 30;   // lunch is taken at the first chance after this time ...
  const MAX_STOPS = 5;
  // Leyte island and its nearby islands. A destination outside this box has a typing mistake in its coordinates, so it is never planned or mapped.
  const LEYTE = { minLat: 9.5, maxLat: 11.9, minLng: 123.9, maxLng: 125.5 };

  // Starting points that are not destinations. (Tacloban City is also what the dashboard weather badge uses.)
  const START_POINTS = [
    { id: 'tacloban', name: 'Tacloban City (city center)', lat: 11.2444, lng: 125.0048 },
    { id: 'palo',     name: 'Palo (town center)',          lat: 11.1578, lng: 124.9916 },
    { id: 'ormoc',    name: 'Ormoc City (city center)',    lat: 11.0064, lng: 124.6075 },
    { id: 'baybay',   name: 'Baybay City (city center)',   lat: 10.6786, lng: 124.8000 }
  ];

  /* ---------- Geometry and travel time ---------- */
  const num = v => (typeof v === 'number' && Number.isFinite(v)) ? v : null;
  function inLeyte(lat, lng) {
    lat = num(lat); lng = num(lng);
    return lat !== null && lng !== null && lat >= LEYTE.minLat && lat <= LEYTE.maxLat && lng >= LEYTE.minLng && lng <= LEYTE.maxLng;
  }
  const hasCoords = p => !!p && inLeyte(p.lat, p.lng);

  function haversineKm(a, b) {
    const R = 6371, rad = d => d * Math.PI / 180;
    const dLat = rad(b.lat - a.lat), dLng = rad(b.lng - a.lng);
    const h = Math.sin(dLat / 2) ** 2 + Math.cos(rad(a.lat)) * Math.cos(rad(b.lat)) * Math.sin(dLng / 2) ** 2;
    return 2 * R * Math.asin(Math.min(1, Math.sqrt(h)));
  }

  // Island destinations (e.g. "Kalanggaman Island", "Cuatro Islas") need a boat. Judged from the name only: it is a hint, not a fact about a boat schedule.
  const needsBoat = p => !!p && /\b(island|islands|islas|isla)\b/i.test(String(p.name || ''));

  // Estimated road trip between two points: {straightKm, roadKm, minutes, boat}. `boatEnds` = how many boat crossings are added (0, 1 or 2).
  function travel(a, b, boatEnds) {
    const straightKm = haversineKm(a, b);
    const roadKm = straightKm * ROAD_FACTOR;
    let minutes = Math.max(MIN_LEG_MIN, Math.ceil((roadKm / AVG_KPH) * 60 / 5) * 5);   // rounded up to 5 minutes
    const boat = (boatEnds || 0) > 0;
    if (boat) minutes += BOAT_EXTRA_MIN * boatEnds;
    return { straightKm: round1(straightKm), roadKm: round1(roadKm), minutes, boat };
  }
  const round1 = n => Math.round(n * 10) / 10;

  // Google Maps directions link. Opens in the visitor's own Google Maps: no API key, and it shows real roads and live traffic.
  function ll(p) { return `${p.lat},${p.lng}`; }
  function directionsUrl(from, to, waypoints) {
    const q = new URLSearchParams({ api: '1', origin: ll(from), destination: ll(to), travelmode: 'driving' });
    if (waypoints && waypoints.length) q.set('waypoints', waypoints.map(ll).join('|'));
    return 'https://www.google.com/maps/dir/?' + q.toString();
  }

  // Point to point (SCRUM-17). `from` / `to` = {name, lat, lng}.
  function route(from, to) {
    if (!hasCoords(from) || !hasCoords(to)) return null;
    const t = travel(from, to, (needsBoat(from) ? 1 : 0) + (needsBoat(to) ? 1 : 0));   // a boat crossing at either end
    return { ...t, from, to, mapsUrl: directionsUrl(from, to), sameSpot: t.straightKm < 0.2 };
  }

  /* ---------- Clock helpers (minutes after midnight) ---------- */
  function fmtTime(min) {
    min = Math.round(min);
    const day = Math.floor(min / 1440); min = ((min % 1440) + 1440) % 1440;
    const h24 = Math.floor(min / 60), m = min % 60, h = h24 % 12 === 0 ? 12 : h24 % 12;
    return `${h}:${String(m).padStart(2, '0')} ${h24 < 12 ? 'AM' : 'PM'}${day ? ' (+1 day)' : ''}`;
  }
  function fmtDuration(min) {
    min = Math.round(min);
    if (min < 60) return `${min} min`;
    const h = Math.floor(min / 60), m = min % 60;
    return m ? `${h} h ${m} min` : `${h} h`;
  }
  function parseClock(str) {   // "08:30" (an <input type=time> value) -> 510, anything else -> null
    const m = /^(\d{1,2}):(\d{2})$/.exec(String(str || '').trim());
    if (!m) return null;
    const h = +m[1], mi = +m[2];
    return h < 24 && mi < 60 ? h * 60 + mi : null;
  }

  /* ---------- Opening hours (free text written by the admin) ---------- */
  const DAY_NAMES = ['sun', 'mon', 'tue', 'wed', 'thu', 'fri', 'sat'];
  // Understands "6:00 AM – 5:00 PM", "Open 24 hours" and "..., closed Mondays". Anything else returns null = unknown, which never blocks a stop.
  function parseHours(text) {
    const s = String(text || '');
    if (!s.trim()) return null;
    const closedDays = [];
    const cm = /closed\s+(?:on\s+)?((?:(?:mon|tue|wed|thu|fri|sat|sun)[a-z]*(?:\s*(?:,|and|&)\s*)?)+)/i.exec(s);
    if (cm) (cm[1].match(/(mon|tue|wed|thu|fri|sat|sun)/gi) || []).forEach(d => closedDays.push(DAY_NAMES.indexOf(d.toLowerCase())));
    if (/open\s*24\s*(hours|hrs)|24\s*\/\s*7|24\s*hours/i.test(s)) return { open: 0, close: 1440, closedDays };
    const t = /(\d{1,2})(?::(\d{2}))?\s*(am|pm)\s*(?:–|—|-|to)\s*(\d{1,2})(?::(\d{2}))?\s*(am|pm)/i.exec(s);
    if (!t) return closedDays.length ? { open: 0, close: 1440, closedDays } : null;
    const conv = (h, m, ap) => ((+h % 12) + (/pm/i.test(ap) ? 12 : 0)) * 60 + (m ? +m : 0);
    const open = conv(t[1], t[2], t[3]), close = conv(t[4], t[5], t[6]);
    if (close <= open) return { open: 0, close: 1440, closedDays };   // an overnight range is not understood: treat as unknown-but-open
    return { open, close, closedDays };
  }

  /* ---------- Weather advisory (SCRUM-18) ---------- */
  // `w` = one live reading as built by js/weather.js info(): {group, id, tempC, feelsC, windKph, rainMm, desc, wet, old}. null/undefined = no usable reading.
  // `place` = the destination (its categories decide whether it is outdoors or by the sea). `h` = {isOutdoorCat, isSeaCat} from js/data.js.
  // Returns {level: 'good'|'caution'|'avoid'|'unknown', label, icon, reasons: [text], advice}.
  // These are the rules a visitor can rely on, in plain words. The data is current conditions only (OpenWeather's free plan has no forecast), and the screens say so.
  const LEVELS = {
    good:    { label: 'Good to go',     icon: 'bi-check-circle-fill' },
    caution: { label: 'Be careful',     icon: 'bi-exclamation-triangle-fill' },
    avoid:   { label: 'Not advised now', icon: 'bi-x-octagon-fill' },
    unknown: { label: 'No live weather', icon: 'bi-cloud-slash' }
  };
  function advisory(w, place, h) {
    h = h || {};
    const isOut = h.isOutdoorCat || (() => false), isSea = h.isSeaCat || (() => false);
    const cats = (place && place.cats) || [];
    const outdoors = cats.some(isOut), sea = cats.some(isSea);
    const make = (level, reasons, advice) => ({ level, ...LEVELS[level], reasons, advice: advice || '' });
    if (!w) return make('unknown', ['There is no recent live reading for this place.'], 'Check the weather before you leave.');

    const avoid = [], caution = [];
    const g = w.group, wind = Number(w.windKph) || 0, feels = Number(w.feelsC), rain = Number(w.rainMm) || 0, id = Number(w.id) || 0;
    if (g === 'thunder') (outdoors || sea ? avoid : caution).push('Thunderstorm nearby.');
    if (g === 'rain') {
      if (id >= 502 || rain >= 7.5) (outdoors || sea ? avoid : caution).push('Heavy rain.');
      else (outdoors || sea ? caution : []).push('Raining now.');
    }
    if (g === 'drizzle' && outdoors) caution.push('Light drizzle.');
    if (sea) {
      if (wind >= 40) avoid.push(`Strong wind (${Math.round(wind)} km/h): the sea is likely rough.`);
      else if (wind >= 30) caution.push(`Windy (${Math.round(wind)} km/h): the sea may be choppy.`);
    } else if (wind >= 60) caution.push(`Very strong wind (${Math.round(wind)} km/h).`);
    if (Number.isFinite(feels) && feels >= 38) caution.push(`Feels very hot (${Math.round(feels)}°C).`);

    if (avoid.length) return make('avoid', avoid.concat(caution), sea && wind >= 40 ? 'Boat crossings may be cancelled. Ask the boat operators before going.' : 'Postpone the visit, or pick an indoor place instead.');
    if (caution.length) return make('caution', caution, 'Go prepared: rain gear, water and sun protection as needed, and allow extra time.');
    const ok = [];
    if (w.desc) ok.push(`${w.desc}, ${w.tempC}°C.`);
    return make('good', ok, 'Conditions look fine for a visit.');
  }

  /* ---------- Day trip planner (SCRUM-19) ---------- */
  const FEE_LIMIT = { free: 0, '50': 50, '100': 100, any: Infinity };   // same ceilings as the preferences (js/data.js BUDGET_LIMIT)

  // How long people typically stay. "stay" is legacy data on older records: half day = 90 min, full day = 3 h; both = 2 h; nothing = 90 min.
  // A place that is overnight-only cannot be part of a one-day trip (returns null).
  function visitMinutes(p) {
    const s = Array.isArray(p.stay) ? p.stay : [];
    if (!s.length) return 90;
    const half = s.includes('half'), full = s.includes('full'), over = s.includes('overnight');
    if (half && full) return 120;
    if (half) return 90;
    if (full) return 180;
    return over ? null : 90;
  }

  function slotOf(min) { return min < 12 * 60 ? 'morning' : min < 17 * 60 ? 'afternoon' : 'evening'; }

  // opts: {start:{name,lat,lng}, startTime, endTime (minutes), budget ('free'|'50'|'100'|'any'), cats:[keys], dow (0-6), lunch (bool)}
  // ctx:  {advisoryFor(place) -> advisory(), }  (optional: without it no weather is considered)
  function planDayTrip(places, opts, ctx) {
    ctx = ctx || {};
    const start = opts.start, startT = opts.startTime, endT = opts.endTime;
    const out = { ok: false, reason: '', items: [], stops: [], skipped: [], notes: [], summary: null, mapsUrl: '' };
    if (!hasCoords(start)) { out.reason = 'Choose a starting point.'; return out; }
    if (!(startT >= 0) || !(endT > startT)) { out.reason = 'The end time must be after the start time.'; return out; }
    if (endT - startT < 60) { out.reason = 'Give the trip at least one hour.'; return out; }
    const limit = FEE_LIMIT[opts.budget] ?? Infinity;
    const wantCats = Array.isArray(opts.cats) ? opts.cats : [];
    const dow = Number.isInteger(opts.dow) ? opts.dow : new Date().getDay();
    const lunch = opts.lunch !== false;

    /* 1. Who is even a candidate, and why the rest are left out (the screen lists the reasons) */
    const cands = [];
    for (const p of places) {
      const skip = r => out.skipped.push({ name: p.name, reason: r });
      if (!hasCoords(p)) { skip('No usable map location'); continue; }
      const visit = visitMinutes(p);
      if (visit === null) { skip('Needs an overnight stay'); continue; }
      if (wantCats.length && !(p.cats || []).some(c => wantCats.includes(c))) continue;   // not an interest: not listed as skipped, it was never wanted
      if ((Number(p.feeAmt) || 0) > limit) { skip('Over your budget'); continue; }
      const hrs = parseHours(p.hours);
      if (hrs && hrs.closedDays.includes(dow)) { skip('Closed on this day'); continue; }
      const adv = ctx.advisoryFor ? ctx.advisoryFor(p) : null;
      if (adv && adv.level === 'avoid') { skip('Weather: ' + (adv.reasons[0] || 'not advised right now')); continue; }
      const rating = Number(p.ratingCount) > 0 && Number.isFinite(Number(p.ratingAvg)) ? Number(p.ratingAvg) : null;
      // Score: every place starts equal; matching interests, good visitor ratings (trusted more with more reviews) and good weather raise it, bad weather lowers it.
      let score = 10;
      score += (p.cats || []).filter(c => wantCats.includes(c)).length * 2;
      if (rating !== null) score += (rating - 3) * 2 * Math.min(Number(p.ratingCount), 5) / 5;
      if (adv && adv.level === 'caution') score -= 4;
      cands.push({ p, visit, hrs, adv, score, rating, boatEnds: needsBoat(p) ? 1 : 0 });
    }
    if (!cands.length) { out.reason = wantCats.length ? 'No destination fits your interests, budget and the conditions right now.' : 'No destination fits your budget and the conditions right now.'; return out; }

    /* 2. Time a given order of stops: returns the full schedule, or null if any stop cannot be done (closed, or home after the end time) */
    function schedule(order) {
      const items = [];
      let t = startT, pos = start, lunchDone = !lunch, travelMin = 0, km = 0, fee = 0;
      items.push({ type: 'depart', at: t, place: start });
      for (const c of order) {
        const takeLunch = !lunchDone && t >= LUNCH_FROM;
        if (takeLunch) { items.push({ type: 'lunch', at: t, minutes: LUNCH_MIN }); t += LUNCH_MIN; lunchDone = true; }
        const leg = travel(pos, c.p, (needsBoat(pos) ? 1 : 0) + c.boatEnds);   // leaving an island needs the boat too
        items.push({ type: 'travel', at: t, from: pos, to: c.p, minutes: leg.minutes, km: leg.roadKm, boat: leg.boat });
        t += leg.minutes; travelMin += leg.minutes; km += leg.roadKm;
        const arrive = t;
        let begin = arrive;
        if (c.hrs) begin = Math.max(arrive, c.hrs.open);   // wait for it to open
        const end = begin + c.visit;
        if (c.hrs && end > c.hrs.close) return null;       // would still be there after closing time
        items.push({ type: 'visit', place: c.p, arrive, begin, end, wait: begin - arrive, fee: Number(c.p.feeAmt) || 0, adv: c.adv, rating: c.rating, hours: c.p.hours || '', slot: slotOf(begin) });
        t = end; pos = c.p; fee += Number(c.p.feeAmt) || 0;
      }
      const back = travel(pos, start, needsBoat(pos) ? 1 : 0);
      // Past noon with no lunch yet and time to spare: eat before the drive home (near the last stop), rather than skipping lunch.
      if (!lunchDone && t >= 12 * 60 && t + LUNCH_MIN + back.minutes <= endT) { items.push({ type: 'lunch', at: t, minutes: LUNCH_MIN, beforeReturn: true }); t += LUNCH_MIN; lunchDone = true; }
      items.push({ type: 'travel', at: t, from: pos, to: start, minutes: back.minutes, km: back.roadKm, boat: back.boat, isReturn: true });
      t += back.minutes; travelMin += back.minutes; km += back.roadKm;
      if (t > endT) return null;
      items.push({ type: 'return', at: t, place: start });
      return { items, endAt: t, travelMin, km: round1(km), fee };
    }

    /* 3. Build the best set of stops. For every possible first stop, keep adding the stop with the most value per extra minute that still fits. Best total value wins. */
    let best = null;
    for (const first of cands) {
      let order = [first], cur = schedule(order);
      if (!cur) continue;
      while (order.length < MAX_STOPS) {
        let pick = null;
        for (const c of cands) {
          if (order.includes(c)) continue;
          const s = schedule(order.concat(c));
          if (!s) continue;
          const ratio = c.score / Math.max(15, s.endAt - cur.endAt);
          if (!pick || ratio > pick.ratio) pick = { c, s, ratio };
        }
        if (!pick) break;
        order = order.concat(pick.c); cur = pick.s;
      }
      const value = order.reduce((a, c) => a + c.score, 0);
      if (!best || value > best.value + 1e-9 || (Math.abs(value - best.value) <= 1e-9 && cur.endAt < best.sched.endAt)) best = { order, sched: cur, value };
    }
    if (!best) { out.reason = 'Nothing fits between those times. Try an earlier start, a later end, or a different starting point.'; return out; }

    /* 4. The same stops in the quickest order (at most 5! = 120 orders) */
    let bestOrder = best.order, bestSched = best.sched;
    (function permute(arr, k) {
      if (k === arr.length) {
        const s = schedule(arr);
        if (s && s.endAt < bestSched.endAt) { bestSched = s; bestOrder = arr.slice(); }
        return;
      }
      for (let i = k; i < arr.length; i++) { [arr[k], arr[i]] = [arr[i], arr[k]]; permute(arr, k + 1); [arr[k], arr[i]] = [arr[i], arr[k]]; }
    })(bestOrder.slice(), 0);

    out.ok = true;
    out.items = bestSched.items;
    out.stops = bestSched.items.filter(i => i.type === 'visit');
    const used = new Set(bestOrder.map(c => c.p.name));
    cands.filter(c => !used.has(c.p.name)).forEach(c => out.skipped.push({ name: c.p.name, reason: 'Did not fit in the day' }));
    out.summary = { stops: out.stops.length, startTime: startT, returnTime: bestSched.endAt, travelMin: bestSched.travelMin, km: bestSched.km, fee: bestSched.fee,
      lunch: out.items.some(i => i.type === 'lunch'), boat: out.items.some(i => i.boat) };
    out.mapsUrl = directionsUrl(start, start, bestOrder.map(c => c.p));   // round trip: starts and ends at the start point, stops in the middle
    if (out.items.some(i => i.type === 'visit' && i.adv && i.adv.level === 'caution')) out.notes.push('Some stops have weather cautions. See the notes on each stop.');
    if (!ctx.advisoryFor) out.notes.push('Live weather was not considered.');
    if (out.summary.boat) out.notes.push('This plan includes a boat crossing. Boat times are rough estimates, so confirm schedules with the operators.');
    if (out.items.some(i => i.type === 'visit' && i.wait > 0)) out.notes.push('You may arrive before a place opens; the plan waits until opening time.');
    return out;
  }

  /* ---------- Trip plans (Sprint 4): rebuild a timeline for ANY ordered list of stops ---------- */
  // Used by the trip-plan editor after the visitor reorders, removes or adds a stop or changes a visit length, and to turn a route or a generated day
  // into the same saved shape. Same rules as planDayTrip (estimated legs, lunch once, wait for opening time), but it never refuses: it reports
  // `warnings` instead (closed that day, closes before you leave, runs past midnight) and the editor decides whether the plan can be saved.
  // start = {name, lat, lng};  stops = [{place, visitMin}];  o = {startTime (minutes), lunch (bool, default true), dow (0-6, default today)}
  function buildItinerary(start, stops, o) {
    o = o || {};
    const dow = Number.isInteger(o.dow) ? o.dow : new Date().getDay();
    let t = o.startTime, pos = start, lunchDone = o.lunch === false;
    const out = { stops: [], warnings: [], travelMin: 0, km: 0, fee: 0, returnLunch: 0, ret: null, returnTime: 0, boat: false, fits: true };
    stops.forEach(s => {
      const p = s.place, warn = [];
      let lunchBefore = 0;
      if (!lunchDone && t >= LUNCH_FROM) { lunchBefore = LUNCH_MIN; t += lunchBefore; lunchDone = true; }
      const leg = travel(pos, p, (needsBoat(pos) ? 1 : 0) + (needsBoat(p) ? 1 : 0));
      t += leg.minutes;
      const arrive = t, hrs = parseHours(p.hours);
      let begin = arrive;
      if (hrs && hrs.closedDays.includes(dow)) warn.push('Closed on the day of your trip.');
      if (hrs) begin = Math.max(arrive, hrs.open);
      const end = begin + s.visitMin;
      if (hrs && end > hrs.close) warn.push(`Closes at ${fmtTime(hrs.close)}, so you would still be there.`);
      out.stops.push({ place: p, visitMin: s.visitMin, lunchBefore, legMin: leg.minutes, legKm: leg.roadKm, boat: leg.boat, arrive, begin, end, wait: begin - arrive, warn });
      out.travelMin += leg.minutes; out.km += leg.roadKm; out.fee += Number(p.feeAmt) || 0;
      if (leg.boat) out.boat = true;
      t = end; pos = p;
    });
    const back = travel(pos, start, needsBoat(pos) ? 1 : 0);
    if (!lunchDone && t >= 12 * 60) { out.returnLunch = LUNCH_MIN; t += LUNCH_MIN; }
    out.ret = { legMin: back.minutes, legKm: back.roadKm, boat: back.boat };
    out.travelMin += back.minutes; out.km = round1(out.km + back.roadKm);
    if (back.boat) out.boat = true;
    t += back.minutes;
    out.returnTime = t;
    if (t > 1440) { out.fits = false; out.warnings.push('This plan runs past midnight. Remove a stop, shorten a visit or leave earlier.'); }
    return out;
  }

  const api = { buildItinerary, LEYTE, START_POINTS, ROAD_FACTOR, AVG_KPH, MAX_STOPS, inLeyte, hasCoords, haversineKm, needsBoat, travel, route, directionsUrl,
    fmtTime, fmtDuration, parseClock, parseHours, advisory, visitMinutes, planDayTrip, LEVELS };
  if (typeof module !== 'undefined' && module.exports) module.exports = api;
  root.Planner = api;
})(typeof window !== 'undefined' ? window : globalThis);
