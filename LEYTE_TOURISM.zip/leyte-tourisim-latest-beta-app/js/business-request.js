/* Public Business Destination Request (business-request.html).
   The destination fields are NOT defined here: js/dest-form.js draws them (the same definition as the admin Add destination form),
   the categories come from the same server list (api/categories.php, data/categories.json), and api/destination-request.php validates them
   with the same dest_clean() as the admin save. Only the "Your details" block below is specific to this page. */
(function () {
  const $ = id => document.getElementById(id);
  const form = $('destForm');
  DestForm.mount($('destFields'), { admin: false });

  const showError = msg => {
    const box = $('formError');
    if (!msg) { box.classList.add('d-none'); return; }
    box.textContent = msg; box.classList.remove('d-none'); box.scrollIntoView({ block: 'nearest', behavior: 'smooth' });
  };
  const photoUi = DestForm.photo(() => null, showError);
  photoUi.set(null);

  async function api(endpoint, body) {
    let res;
    try { res = await fetch('api/' + endpoint, { method: 'POST', headers: { 'Content-Type': 'application/json' }, credentials: 'same-origin', body: JSON.stringify(body || {}) }); }
    catch (e) { return { ok: false, message: "Can't reach the server. Check your connection and try again." }; }
    try { const j = await res.json(); j.status = res.status; return j; }
    catch (e) { return { ok: false, message: 'The server did not answer correctly (HTTP ' + res.status + '). Please try again later.' }; }
  }

  // The same category list the rest of the site uses.
  (async function loadCats() {
    const res = await api('categories.php');
    if (!res.ok || !res.categories.length) { const b = $('loadError'); b.textContent = 'The category list could not be loaded, so the form cannot be sent yet. Reload the page to try again.'; b.classList.remove('d-none'); return; }
    DestForm.renderCats(Object.fromEntries(res.categories.map(c => [c.key, c.label])));
  })();

  let saving = false;
  form.addEventListener('submit', async e => {
    e.preventDefault();
    if (saving) return;
    showError('');
    const problem = DestForm.check(form);
    if (problem) { showError(problem); return; }

    const body = { ...DestForm.collect(form), contactName: $('cName').value, contactEmail: $('cEmail').value, contactPhone: $('cPhone').value, confirm: $('cConfirm').checked, website: $('cWebsite').value };
    const btn = $('saveBtn');
    saving = true; btn.disabled = true; btn.dataset.label = btn.textContent; btn.innerHTML = '<span class="spinner-border spinner-border-sm me-2" aria-hidden="true"></span>Sending…';
    const restore = () => { saving = false; btn.disabled = false; btn.textContent = btn.dataset.label; };
    try { Object.assign(body, await DestForm.photoPayload()); }
    catch (err) { restore(); showError('The photo could not be read. Choose it again.'); return; }

    const res = await api('destination-request.php', body);
    restore();
    if (!res.ok) { showError(res.message || 'Could not send the request. Try again.'); return; }
    $('doneRef').textContent = res.ref;
    $('formCard').classList.add('d-none'); $('doneBox').classList.remove('d-none'); $('doneBox').focus();
    window.scrollTo({ top: 0, behavior: 'smooth' });
  });

  $('againBtn').addEventListener('click', () => {
    form.reset(); DestForm.fill(form, null); form.classList.remove('was-validated'); photoUi.set(null);
    $('doneBox').classList.add('d-none'); $('formCard').classList.remove('d-none'); DestForm.pin.refresh(); $('fName').focus();
  });
})();
