/* MY TRIP PLANS (Sprint 4): save a route or a generated one-day trip, list the saved plans, edit them, and show each as a printable itinerary receipt.
   Loaded LAST (after planner-ui.js). Uses: Planner (js/planner.js), PlannerUI (last route / last trip), Weather, PLACES, api(), notify*, escapeHtml, placeThumb.
   Server side: api/trips.php, trip.php, trip-save.php, trip-delete.php (includes/trips.php). The server owns the rules: every plan belongs to one account and the
   server re-checks every distance and time, so this file only builds the request and shows the answer.
   Everything on screen about distance, time and weather is labelled for what it is: an ESTIMATE, and a SNAPSHOT of current conditions (never a forecast). */
const Trips = (() => {
  const $ = id => document.getElementById(id);
  const esc = s => escapeHtml(s);
  const P = Planner;
  const ID_RE = /^TP-\d{8}-[A-F0-9]{6}$/;
  const STATUS = { planned: ['Planned', 'bi-calendar-event'], completed: ['Completed', 'bi-check-circle'], cancelled: ['Cancelled', 'bi-x-circle'] };
  let list = null, listError = '', loadingList = false;   // the cards on "My trip plans"
  let current = null;                                     // the plan open in the receipt view
  let ed = null;                                          // the plan open in the editor
  let saving = false, pendingDelete = null;

  /* ---------- small helpers ---------- */
  const todayStr = () => { const d = new Date(); return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`; };
  const parseDay = s => { const m = /^(\d{4})-(\d{2})-(\d{2})$/.exec(s || ''); return m ? new Date(+m[1], +m[2] - 1, +m[3]) : null; };
  const dowOf = s => { const d = parseDay(s); return d ? d.getDay() : new Date().getDay(); };
  const fmtDay = (s, long) => { const d = parseDay(s); return d ? d.toLocaleDateString(undefined, long ? { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' } : { weekday: 'short', year: 'numeric', month: 'short', day: 'numeric' }) : s; };
  const fmtStamp = iso => { const d = new Date(iso); return isNaN(d) ? '' : d.toLocaleString(undefined, { year: 'numeric', month: 'short', day: 'numeric', hour: 'numeric', minute: '2-digit' }); };
  const fmtUnix = ts => ts ? new Date(ts * 1000).toLocaleString(undefined, { year: 'numeric', month: 'short', day: 'numeric', hour: 'numeric', minute: '2-digit' }) : '';
  const clockValue = min => `${String(Math.floor(min / 60)).padStart(2, '0')}:${String(min % 60).padStart(2, '0')}`;
  const km = n => `${Number(n).toFixed(1).replace(/\.0$/, '')} km`;
  const newToken = () => (window.crypto && crypto.randomUUID) ? crypto.randomUUID() : 'tk' + Math.random().toString(36).slice(2) + Date.now().toString(36) + Math.random().toString(36).slice(2);
  const statusBadge = st => { const [text, icon] = STATUS[st] || STATUS.planned; return `<span class="trip-status trip-${esc(st)}"><i class="bi ${icon}"></i>${text}</span>`; };
  const message = (icon, title, text, extra) => `<div class="empty-state"><i class="bi ${icon}"></i><p class="fw-semibold mb-1">${esc(title)}</p><p class="small text-secondary mb-${extra ? 3 : 0}">${esc(text)}</p>${extra || ''}</div>`;

  // A stop whose destination the admin has since removed still shows, from the snapshot saved with the plan.
  const placeOf = stop => PLACES.find(p => p.id === stop.destId) || { id: stop.destId, name: stop.name, town: stop.town, lat: stop.lat, lng: stop.lng, fee: stop.fee, feeAmt: stop.feeAmt, hours: stop.hours, cats: [], gone: true };

  /* ======================= My trip plans (the list) ======================= */
  async function loadList() {
    loadingList = true; listError = ''; renderList();
    const res = await api('trips.php');
    loadingList = false;
    if (!res.ok) { listError = res.message || "Couldn't load your trip plans."; list = null; }
    else list = res.trips;
    renderList();
  }

  function cardHtml(t) {
    const dur = t.returnTime !== null && t.returnTime !== undefined ? P.fmtDuration(t.returnTime - t.departure) : '';
    return `<div class="col-12 col-md-6 col-xl-4"><article class="trip-card h-100">
      <div class="d-flex justify-content-between align-items-start gap-2 mb-2">
        <h3 class="h6 fw-bold mb-0"><button type="button" class="trip-title-link" data-trip-open="${esc(t.id)}">${esc(t.title)}</button></h3>${statusBadge(t.status)}
      </div>
      <ul class="trip-facts">
        <li><i class="bi bi-calendar-event"></i><span><span class="text-secondary">Planned date</span> ${esc(fmtDay(t.date))}</span></li>
        <li><i class="bi bi-clock"></i><span><span class="text-secondary">Departure</span> ${P.fmtTime(t.departure)}</span></li>
        <li><i class="bi bi-house-door"></i><span><span class="text-secondary">From</span> ${esc(t.start)}</span></li>
        <li><i class="bi bi-geo-alt"></i><span>${t.stopCount} destination${t.stopCount === 1 ? '' : 's'}: ${esc(t.stopNames.join(', '))}${t.stopCount > t.stopNames.length ? '…' : ''}</span></li>
        ${t.status === 'completed' && t.completedAt ? `<li><i class="bi bi-check-circle"></i><span><span class="text-secondary">Completed</span> ${esc(fmtStamp(t.completedAt))}</span></li>` : ''}
        ${dur ? `<li><i class="bi bi-hourglass-split"></i><span><span class="text-secondary">Estimated duration</span> about ${dur}</span></li>` : ''}
      </ul>
      <div class="d-flex flex-wrap gap-2 mt-3">
        <button type="button" class="btn btn-sm btn-primary" data-trip-open="${esc(t.id)}"><i class="bi bi-receipt me-1"></i>View itinerary</button>
        ${t.status === 'planned' ? `<button type="button" class="btn btn-sm btn-success" data-trip-complete="${esc(t.id)}"><i class="bi bi-check2-circle me-1"></i>Mark as completed</button>` : ''}
        <button type="button" class="btn btn-sm btn-outline-secondary" data-trip-edit="${esc(t.id)}"><i class="bi bi-pencil me-1"></i>Edit</button>
        <button type="button" class="btn btn-sm btn-outline-danger" data-trip-delete="${esc(t.id)}" aria-label="Delete ${esc(t.title)}"><i class="bi bi-trash3"></i></button>
      </div></article></div>`;
  }

  function renderList() {
    const el = $('tripsList');
    if (loadingList && !list) { el.innerHTML = `<div class="empty-state"><span class="spinner-border spinner-border-sm mb-2" aria-hidden="true"></span><p class="small text-secondary mb-0">Loading your trip plans…</p></div>`; return; }
    if (listError) { el.innerHTML = message('bi-wifi-off', "Couldn't load your trip plans", listError, '<button type="button" class="btn btn-outline-secondary btn-sm" data-trips-retry>Try again</button>'); return; }
    if (!list) { el.innerHTML = ''; return; }
    if (!list.length) { el.innerHTML = message('bi-journal-plus', 'No trip plans yet', 'Plan a route or a one-day trip, then press “Save as trip plan” to keep it here.', '<a href="#planner/trip" class="btn btn-primary btn-sm" data-view="planner/trip">Plan a trip</a>'); return; }
    el.innerHTML = `<div class="row g-3">${list.map(cardHtml).join('')}</div>`;
  }

  /* ======================= The receipt ======================= */
  // Sketch of the route in order: start, then the stops 1, 2, 3 ..., and back. Orientation only (the real roads are in Google Maps).
  function pathSvg(start, stops) {
    const pts = [start, ...stops];
    const lats = pts.map(p => p.lat), lngs = pts.map(p => p.lng);
    const minLat = Math.min(...lats), maxLat = Math.max(...lats), minLng = Math.min(...lngs), maxLng = Math.max(...lngs);
    const k = Math.cos(((minLat + maxLat) / 2) * Math.PI / 180), W = 360, H = 250, m = 34;
    const w = Math.max(0.01, (maxLng - minLng) * k), h = Math.max(0.01, maxLat - minLat);
    const s = Math.min((W - 2 * m) / w, (H - 2 * m) / h), ox = (W - w * s) / 2, oy = (H - h * s) / 2;
    const X = p => (ox + (p.lng - minLng) * k * s).toFixed(1), Y = p => (oy + (maxLat - p.lat) * s).toFixed(1);
    const out = stops.map((p, i) => `${X(p)},${Y(p)}`);
    return `<svg class="route-map receipt-map" viewBox="0 0 ${W} ${H}" role="img" aria-label="Sketch of the route in order: start, ${stops.map((p, i) => `stop ${i + 1} ${esc(p.name)}`).join(', ')}, then back to the start">
      <rect class="map-bg" x="0" y="0" width="${W}" height="${H}" rx="14"></rect>
      <polyline class="map-line" fill="none" points="${X(start)},${Y(start)} ${out.join(' ')}"></polyline>
      <line class="map-line map-return" x1="${out[out.length - 1].split(',')[0]}" y1="${out[out.length - 1].split(',')[1]}" x2="${X(start)}" y2="${Y(start)}"></line>
      <circle class="map-from" cx="${X(start)}" cy="${Y(start)}" r="9"></circle><text class="map-num" x="${X(start)}" y="${(+Y(start) + 4).toFixed(1)}" text-anchor="middle">S</text>
      ${stops.map((p, i) => `<circle class="map-stop" cx="${X(p)}" cy="${Y(p)}" r="10"></circle><text class="map-num" x="${X(p)}" y="${(+Y(p) + 4).toFixed(1)}" text-anchor="middle">${i + 1}</text>`).join('')}</svg>`;
  }

  function weatherBlock(t) {
    const w = t.weather;
    if (!w || w.kind !== 'current' || !w.items || !w.items.length) {
      return `<p class="mb-1"><i class="bi bi-cloud-slash me-1"></i>Weather information was not available when this plan was saved.</p>${w && w.note ? `<p class="small mb-0">${esc(w.note)}</p>` : ''}`;
    }
    const saved = fmtUnix(w.observedAt) || 'when this plan was saved';
    const sameDay = w.observedAt && new Date(w.observedAt * 1000).toISOString().slice(0, 10) === t.date;
    return `<p class="small mb-2">Snapshot of <strong>current conditions</strong> retrieved ${esc(saved)}.${sameDay ? '' : ` It is <strong>not</strong> a forecast for ${esc(fmtDay(t.date))}.`} Conditions change, so check the weather again before you travel. Nothing here is a safety guarantee.</p>
      <ul class="rc-wx">${w.items.map(it => `<li><strong>${esc(it.name)}</strong><span class="adv-badge adv-${esc(it.level)}">${esc(it.label)}</span>${it.desc ? `<span class="small"> ${esc(it.desc)}${it.tempC !== null && it.tempC !== undefined ? ', ' + it.tempC + '°C' : ''}</span>` : ''}${(it.reasons || []).length && it.level !== 'good' ? `<div class="small">${esc(it.reasons.join(' '))}</div>` : ''}</li>`).join('')}</ul>`;
  }

  function receiptHtml(t) {
    const stops = t.stops.map(placeOf);
    const placesForMap = t.stops.map(s => ({ lat: s.lat, lng: s.lng, name: s.name }));
    const mapsUrl = P.directionsUrl(t.start, t.start, placesForMap);
    let prevEnd = t.departure;
    const rows = t.stops.map((s, i) => {
      const lunch = s.lunchBefore ? `<li class="rc-leg"><i class="bi bi-cup-hot"></i><div>Lunch break · ${s.lunchBefore} min <span class="text-secondary">(${P.fmtTime(prevEnd)})</span></div></li>` : '';
      const leg = `<li class="rc-leg"><i class="bi ${s.boat ? 'bi-water' : 'bi-car-front'}"></i><div>${P.fmtDuration(s.legMin)} · about ${km(s.legKm)} <span class="text-secondary">(estimate${s.boat ? ', includes a boat crossing' : ''})</span></div></li>`;
      const p = stops[i];
      const row = `${lunch}${leg}<li class="rc-stop"><span class="rc-num">${i + 1}</span><div class="rc-card">
        <div class="rc-name">${p.gone ? esc(s.name) : `<button type="button" class="tl-name" data-place="${esc(s.name)}">${esc(s.name)}</button>`}</div>
        <div class="small text-secondary">${esc(s.town)}${p.gone ? ' · no longer listed' : ''}</div>
        <div class="tl-times"><span>Arrive <strong>${P.fmtTime(s.arrive)}</strong></span><span>Visit <strong>${P.fmtDuration(s.visitMin)}</strong></span><span>Depart <strong>${P.fmtTime(s.end)}</strong></span></div>
        ${s.begin > s.arrive ? `<div class="small">Opens at ${P.fmtTime(s.begin)}, so the visit starts then (wait about ${P.fmtDuration(s.begin - s.arrive)}).</div>` : ''}
        <div class="small text-secondary">${esc(s.fee || (s.feeAmt ? '₱' + s.feeAmt : 'Free'))}${s.hours ? ' · ' + esc(s.hours) : ''} <span class="rc-snap">(as of ${esc(fmtDay(t.created.slice(0, 10)))})</span></div></div></li>`;
      prevEnd = s.end;
      return row;
    }).join('');
    const retLunch = t.returnLunch ? `<li class="rc-leg"><i class="bi bi-cup-hot"></i><div>Lunch break · ${t.returnLunch} min <span class="text-secondary">(${P.fmtTime(prevEnd)})</span></div></li>` : '';
    return `<article class="receipt-sheet" id="receipt">
      <header class="rc-head">
        <div class="rc-brand"><img src="images/logo-compass.svg" alt="" width="34" height="34"><div><strong>Leyte Tourism Guide</strong><div class="small text-secondary">Trip plan · itinerary</div></div></div>
        <div class="rc-ref"><div class="small text-secondary">Plan reference</div><div class="rc-refid">${esc(t.id)}</div>${statusBadge(t.status)}</div>
      </header>
      <h2 class="rc-title">${esc(t.title)}</h2>
      <p class="rc-disclaimer"><i class="bi bi-info-circle me-1"></i>This is a record of a trip you <strong>planned</strong>. It is not a booking or a confirmation, and it does not show that the trip took place.</p>
      <dl class="rc-meta">
        <div><dt>Plan created</dt><dd>${esc(fmtStamp(t.created))}</dd></div>
        <div><dt>Last updated</dt><dd>${esc(fmtStamp(t.updated))}${t.created === t.updated ? ' (not edited since)' : ''}</dd></div>
        ${t.status === 'completed' && t.completedAt ? `<div><dt>Marked completed</dt><dd>${esc(fmtStamp(t.completedAt))}</dd></div>` : ''}
        <div><dt>Planned travel date</dt><dd>${esc(fmtDay(t.date, true))}</dd></div>
        <div><dt>Departure</dt><dd>${P.fmtTime(t.departure)}</dd></div>
        <div><dt>Starting point</dt><dd>${esc(t.start.name)}</dd></div>
        <div><dt>Travel mode</dt><dd>Driving (estimated)</dd></div>
      </dl>
      <h3 class="rc-h">Itinerary</h3>
      <ol class="tl rc-tl">
        <li class="tl-end"><i class="bi bi-house-door"></i><div>Depart <strong>${esc(t.start.name)}</strong> at <strong>${P.fmtTime(t.departure)}</strong></div></li>
        ${rows}${retLunch}
        <li class="rc-leg"><i class="bi bi-car-front"></i><div>${P.fmtDuration(t.returnLegMin)} · about ${km(t.returnLegKm)} <span class="text-secondary">(estimate, return)</span></div></li>
        <li class="tl-end"><i class="bi bi-flag"></i><div>Back at <strong>${esc(t.start.name)}</strong> about <strong>${P.fmtTime(t.returnTime)}</strong></div></li>
      </ol>
      <div class="stat-row rc-totals">
        <div class="stat-tile"><strong>${P.fmtDuration(t.totals.travelMin)}</strong><span>estimated travel time</span></div>
        <div class="stat-tile"><strong>${km(t.totals.km)}</strong><span>estimated distance</span></div>
        <div class="stat-tile"><strong>${t.totals.fee ? '₱' + t.totals.fee : 'Free'}</strong><span>entrance fees, per person</span></div>
        <div class="stat-tile"><strong>${P.fmtDuration(t.returnTime - t.departure)}</strong><span>total, door to door</span></div>
      </div>
      <p class="small text-secondary rc-estimate"><strong>Estimates, not a routing service.</strong> Distance is the straight line between places x ${P.ROAD_FACTOR} at about ${P.AVG_KPH} km/h, plus 1 hour per boat crossing. Real roads and traffic will differ. Fees and hours are copied from when you saved the plan.</p>
      <div class="rc-two">
        <div><h3 class="rc-h">Route map</h3>${pathSvg(t.start, placesForMap)}
          <p class="small text-secondary mb-1">S = start; numbers = stops in order; dashed = return. A sketch for orientation.</p>
          <a class="btn btn-sm btn-outline-primary no-print" href="${esc(mapsUrl)}" target="_blank" rel="noopener noreferrer"><i class="bi bi-map me-1"></i>Open in Google Maps (live directions)</a>
          <p class="rc-print-only small mb-0">Google Maps: ${esc(mapsUrl)}</p></div>
        <div><h3 class="rc-h">Weather</h3>${weatherBlock(t)}</div>
      </div>
      <h3 class="rc-h">Notes</h3>
      <p class="rc-notes">${t.notes ? esc(t.notes) : '<span class="text-secondary">No notes.</span>'}</p>
      <footer class="rc-foot small text-secondary">Reference ${esc(t.id)} · Leyte Tourism Guide · Printed ${esc(new Date().toLocaleString())}</footer>
    </article>`;
  }

  async function openReceipt(id) {
    const body = $('receiptBody'), actions = $('receiptActions');
    current = null; actions.innerHTML = '';
    if (!ID_RE.test(id || '')) { body.innerHTML = message('bi-journal-x', 'Trip plan not found', 'This link is not a valid trip plan reference.', '<a href="#trips" class="btn btn-outline-secondary btn-sm" data-view="trips">Back to My trip plans</a>'); return; }
    body.innerHTML = `<div class="empty-state"><span class="spinner-border spinner-border-sm mb-2" aria-hidden="true"></span><p class="small text-secondary mb-0">Loading the itinerary…</p></div>`;
    const res = await api('trip.php', { id });
    if (!res.ok) {
      body.innerHTML = message(res.offline ? 'bi-wifi-off' : 'bi-journal-x', res.offline ? "Couldn't load the itinerary" : 'Trip plan not found', res.message || '', `<a href="#trips" class="btn btn-outline-secondary btn-sm me-2" data-view="trips">Back to My trip plans</a>${res.offline ? `<button type="button" class="btn btn-outline-secondary btn-sm" data-trip-open="${esc(id)}">Try again</button>` : ''}`);
      return;
    }
    current = res.trip;
    body.innerHTML = receiptHtml(current);
    actions.innerHTML = `${current.status === 'planned' ? `<button type="button" class="btn btn-sm btn-success" data-trip-complete="${esc(current.id)}"><i class="bi bi-check2-circle me-1"></i>Mark as completed</button>` : ''}
      ${current.status === 'completed' ? `<a href="#history" class="btn btn-sm btn-outline-primary" data-view="history"><i class="bi bi-star me-1"></i>History log &amp; reviews</a>` : ''}
      <button type="button" class="btn btn-sm btn-primary" data-trip-print><i class="bi bi-printer me-1"></i>Print / save as PDF</button>
      <button type="button" class="btn btn-sm btn-outline-secondary" data-trip-edit="${esc(current.id)}"><i class="bi bi-pencil me-1"></i>Edit</button>
      <button type="button" class="btn btn-sm btn-outline-secondary" data-trip-copy="${esc(current.id)}" title="Start a new plan from this one"><i class="bi bi-copy me-1"></i>Use as a new plan</button>
      <button type="button" class="btn btn-sm btn-outline-danger" data-trip-delete="${esc(current.id)}"><i class="bi bi-trash3 me-1"></i>Delete</button>`;
  }

  /* ======================= The editor (review, adjust, save) ======================= */
  function defaultDeparture() {
    const now = new Date();
    let m = Math.ceil((now.getHours() * 60 + now.getMinutes()) / 15) * 15, date = todayStr();
    if (m < 6 * 60) m = 8 * 60;
    if (m > 20 * 60) { const t = new Date(now.getTime() + 86400000); date = `${t.getFullYear()}-${String(t.getMonth() + 1).padStart(2, '0')}-${String(t.getDate()).padStart(2, '0')}`; m = 8 * 60; }
    return { date, departure: m };
  }
  const defaultVisit = p => P.visitMinutes(p) || 120;
  const cleanStart = pt => ({ name: String(pt.name || 'Starting point').slice(0, 80), lat: pt.lat, lng: pt.lng });
  const shortName = n => String(n).replace(/\s*\(.*\)\s*$/, '');

  function draftFromRoute() {
    const last = PlannerUI.getLastRoute();
    if (!last || !last.to || !last.to.place) return null;
    const d = defaultDeparture();
    return { id: null, source: 'route', title: `Trip to ${last.to.name}`.slice(0, 80), date: d.date, departure: d.departure, start: cleanStart(last.from),
      stops: [{ place: last.to.place, visitMin: defaultVisit(last.to.place) }], notes: '', status: 'planned', lunch: true, weather: undefined, refreshWeather: true };
  }
  function draftFromTrip() {
    const last = PlannerUI.getLastTrip();
    if (!last) return null;
    const { plan, opts, date } = last;
    return { id: null, source: 'daytrip', title: `Day trip from ${shortName(opts.start.name)}`.slice(0, 80), date, departure: opts.startTime, start: cleanStart(opts.start),
      stops: plan.stops.map(s => ({ place: s.place, visitMin: s.end - s.begin })), notes: '', status: 'planned', lunch: opts.lunch !== false, weather: undefined, refreshWeather: true };
  }
  function draftFromSaved(t, asCopy) {
    const today = todayStr();
    const start = cleanStart(t.start), stops = t.stops.map(s => ({ place: placeOf(s), visitMin: s.visitMin }));
    // Did this plan include a lunch break? Rebuild it with lunch ON: if that gives the saved return time, lunch was on (or never needed); if not, the visitor had turned it off.
    const probe = P.buildItinerary(start, stops, { startTime: t.departure, lunch: true, dow: dowOf(t.date) });
    return { id: asCopy ? null : t.id, source: asCopy ? 'custom' : (t.source || 'custom'), title: (asCopy ? `Copy of ${t.title}` : t.title).slice(0, 80), date: asCopy && t.date < today ? today : t.date,
      departure: t.departure, start, stops, notes: t.notes, status: asCopy ? 'planned' : t.status, lunch: probe.returnTime === t.returnTime, weather: t.weather };
  }

  function itin() { return P.buildItinerary(ed.start, ed.stops.map(s => ({ place: s.place, visitMin: s.visitMin })), { startTime: ed.departure, lunch: ed.lunch, dow: dowOf(ed.date) }); }

  function editorStops() {
    const it = itin();
    let prevEnd = ed.departure;
    const rows = it.stops.map((s, i) => {
      const lunch = s.lunchBefore ? `<div class="te-leg"><i class="bi bi-cup-hot"></i>Lunch break · ${s.lunchBefore} min (${P.fmtTime(prevEnd)})</div>` : '';
      const html = `${lunch}<div class="te-leg"><i class="bi ${s.boat ? 'bi-water' : 'bi-car-front'}"></i>${P.fmtDuration(s.legMin)} · about ${km(s.legKm)} (estimate${s.boat ? ', includes a boat crossing' : ''})</div>
        <div class="te-stop"><span class="tl-num te-num">${i + 1}</span>
          <div class="te-main"><div class="fw-semibold">${esc(s.place.name)}</div><div class="small text-secondary">${esc(s.place.town || '')} · arrive ${P.fmtTime(s.arrive)} · leave ${P.fmtTime(s.end)}${s.wait ? ` · opens ${P.fmtTime(s.begin)}` : ''}</div>
            ${s.warn.map(w => `<div class="small te-warn"><i class="bi bi-exclamation-triangle-fill"></i> ${esc(w)}</div>`).join('')}</div>
          <div class="te-ctl"><label class="visually-hidden" for="teVisit${i}">Time at ${esc(s.place.name)}</label>
            <select class="form-select form-select-sm" id="teVisit${i}" data-te-visit="${i}">${visitOptions(s.visitMin)}</select>
            <div class="btn-group btn-group-sm" role="group" aria-label="Move or remove ${esc(s.place.name)}">
              <button type="button" class="btn btn-outline-secondary" data-te-move="${i}" data-dir="-1" ${i === 0 ? 'disabled' : ''} aria-label="Move up"><i class="bi bi-arrow-up"></i></button>
              <button type="button" class="btn btn-outline-secondary" data-te-move="${i}" data-dir="1" ${i === it.stops.length - 1 ? 'disabled' : ''} aria-label="Move down"><i class="bi bi-arrow-down"></i></button>
              <button type="button" class="btn btn-outline-danger" data-te-remove="${i}" ${it.stops.length === 1 ? 'disabled title="A plan needs at least one stop"' : ''} aria-label="Remove"><i class="bi bi-x-lg"></i></button></div></div></div>`;
      prevEnd = s.end;
      return html;
    }).join('');
    const retLunch = it.returnLunch ? `<div class="te-leg"><i class="bi bi-cup-hot"></i>Lunch break · ${it.returnLunch} min (${P.fmtTime(prevEnd)})</div>` : '';
    $('teStops').innerHTML = `<div class="te-line"><i class="bi bi-house-door"></i>Depart ${esc(ed.start.name)} at ${P.fmtTime(ed.departure)}</div>${rows}${retLunch}
      <div class="te-leg"><i class="bi bi-car-front"></i>${P.fmtDuration(it.ret.legMin)} · about ${km(it.ret.legKm)} back (estimate)</div>`;
    $('teSummary').innerHTML = `<div class="stat-row mb-2">
        <div class="stat-tile"><strong>${P.fmtDuration(it.travelMin)}</strong><span>est. travel</span></div><div class="stat-tile"><strong>${km(it.km)}</strong><span>est. distance</span></div>
        <div class="stat-tile"><strong>${it.fee ? '₱' + it.fee : 'Free'}</strong><span>entrance fees</span></div><div class="stat-tile"><strong>${P.fmtTime(it.returnTime)}</strong><span>back home about</span></div></div>
      ${it.warnings.map(w => `<div class="route-note route-warn"><i class="bi bi-exclamation-triangle"></i>${esc(w)}</div>`).join('')}
      <p class="small text-secondary mb-0">Arrival times follow from the departure time, the order, and how long you stay at each stop. Distances and times are estimates.</p>`;
    // destinations that can still be added
    const used = new Set(ed.stops.map(s => s.place.id));
    const free = PLACES.filter(p => P.hasCoords(p) && !used.has(p.id)).sort((a, b) => a.name.localeCompare(b.name));
    $('teAddSel').innerHTML = `<option value="">Add a destination…</option>${free.map(p => `<option value="${esc(p.id)}">${esc(p.name)} (${esc(p.town)})</option>`).join('')}`;
    const full = ed.stops.length >= 8;
    $('teAdd').disabled = full || !free.length;
    $('teAddSel').disabled = full || !free.length;
    return it;
  }
  function visitOptions(cur) {
    let out = '';
    const vals = new Set([cur]);
    for (let m = 15; m <= 480; m += 15) vals.add(m);
    [...vals].sort((a, b) => a - b).forEach(m => { out += `<option value="${m}" ${m === cur ? 'selected' : ''}>${P.fmtDuration(m)}</option>`; });
    return out;
  }

  function showEditError(text) { const e = $('teError'); e.textContent = text || ''; e.classList.toggle('d-none', !text); }

  function openEditor(draft) {
    ed = { ...draft, token: newToken() };
    saving = false; showEditError('');
    const editing = !!ed.id;
    $('teHeading').textContent = editing ? 'Edit trip plan' : 'Review and save trip plan';
    $('teSave').querySelector('span').textContent = editing ? 'Save changes' : 'Save trip plan';
    $('teSave').disabled = false;
    $('teName').value = ed.title; $('teDate').value = ed.date; $('teDep').value = clockValue(ed.departure); $('teNotes').value = ed.notes || '';
    $('teDate').min = editing ? '' : todayStr();
    $('teLunch').checked = ed.lunch;
    $('teStart').textContent = ed.start.name;
    $('teStatusRow').classList.toggle('d-none', !editing); $('teStatus').value = ed.status;
    $('teWxRow').classList.toggle('d-none', !editing); $('teWx').checked = false;
    editorStops();
    bootstrap.Modal.getOrCreateInstance($('tripEditorModal')).show();
  }

  // The weather part of the saved plan. Only CURRENT conditions exist (OpenWeather's free plan is used for current readings), so:
  //  - travel date is today and live weather loaded  -> a snapshot of those conditions, stamped with the time they were read
  //  - any other case -> "unavailable", with the reason. Today's weather is never presented as a forecast for another day.
  function captureWeather() {
    if (!Weather.live) return { kind: 'unavailable', observedAt: null, note: 'Live weather could not be loaded when this plan was saved.', items: [] };
    const items = ed.stops.map(s => {
      const a = Weather.advisory(s.place.name), w = Weather.info(s.place.name);
      return { destId: s.place.id, name: s.place.name, level: a.level, label: a.label, reasons: (a.reasons || []).slice(0, 3), desc: w ? w.desc : '', tempC: w ? w.tempC : null };
    });
    const note = ed.date === todayStr() ? '' : `Saved for ${fmtDay(ed.date)}. These are today's conditions, not a forecast for your travel date.`;
    return { kind: 'current', observedAt: Weather.updatedAt() || null, note, items };
  }

  function readInputs() {
    ed.title = $('teName').value.trim(); ed.date = $('teDate').value; ed.notes = $('teNotes').value; ed.lunch = $('teLunch').checked;
    const dep = P.parseClock($('teDep').value); if (dep !== null) ed.departure = dep;
    if (!$('teStatusRow').classList.contains('d-none')) ed.status = $('teStatus').value;
    return dep !== null;
  }

  async function save() {
    if (saving) return;
    const depOk = readInputs();
    if (!ed.title) return showEditError('Enter a title for your trip.');
    if (!parseDay(ed.date)) return showEditError('Choose the date you plan to travel.');
    if (!depOk) return showEditError('Choose a departure time.');
    const it = itin();
    if (!it.fits) return showEditError(it.warnings[0]);
    const body = { title: ed.title, date: ed.date, departure: ed.departure, mode: 'driving', source: ed.source, status: ed.status, notes: ed.notes, start: ed.start,
      stops: it.stops.map(s => ({ destId: s.place.id, visitMin: s.visitMin, arrive: s.arrive, begin: s.begin, end: s.end, legMin: s.legMin, legKm: s.legKm, lunchBefore: s.lunchBefore, boat: s.boat })),
      returnLegMin: it.ret.legMin, returnLegKm: it.ret.legKm, returnLunch: it.returnLunch, returnTime: it.returnTime };
    if (ed.id) { body.id = ed.id; if ($('teWx').checked) body.weather = captureWeather(); }
    else { body.token = ed.token; body.weather = captureWeather(); }
    saving = true; showEditError('');
    const btn = $('teSave'); setLoading(btn, true, 'Saving…');
    const res = await api('trip-save.php', body);
    saving = false; setLoading(btn, false);
    if (!res.ok) { showEditError(res.message || "Couldn't save the trip plan. Try again."); return; }
    list = null;   // the list is reloaded the next time it is opened
    bootstrap.Modal.getInstance($('tripEditorModal')).hide();
    notifySuccess(res.duplicate ? 'Already saved' : (ed.id ? 'Trip plan updated' : 'Trip plan saved'), res.duplicate ? 'This plan had already been saved.' : res.trip.title);
    showView('trip/' + res.trip.id);
  }

  /* ======================= Delete ======================= */
  function askDelete(id, title, completed) { pendingDelete = id; $('tdName').textContent = title; $('tdNote').classList.toggle('d-none', !completed); $('tdError').classList.add('d-none'); bootstrap.Modal.getOrCreateInstance($('tripDeleteModal')).show(); }
  async function confirmDelete() {
    if (!pendingDelete) return;
    const btn = $('tdConfirm'); setLoading(btn, true, 'Deleting…');
    const res = await api('trip-delete.php', { id: pendingDelete });
    setLoading(btn, false);
    if (!res.ok) { const e = $('tdError'); e.textContent = res.message || "Couldn't delete the plan. Try again."; e.classList.remove('d-none'); return; }
    pendingDelete = null; list = null;
    bootstrap.Modal.getInstance($('tripDeleteModal')).hide();
    notifyDanger('Trip plan deleted', 'It was removed from your account.');
    showView('trips');
  }

  /* ======================= Wiring ======================= */
  async function openForEdit(id, copy) {
    let t = current && current.id === id ? current : null;
    if (!t) { const res = await api('trip.php', { id }); if (!res.ok) { notifyDanger("Couldn't open the plan", res.message || ''); return; } t = res.trip; }
    openEditor(draftFromSaved(t, copy));
  }

  document.addEventListener('click', e => {
    const t = e.target;
    let el;
    if ((el = t.closest('[data-trip-open]'))) { showView('trip/' + el.dataset.tripOpen); return; }
    if ((el = t.closest('[data-trip-edit]'))) { openForEdit(el.dataset.tripEdit, false); return; }
    if ((el = t.closest('[data-trip-copy]'))) { openForEdit(el.dataset.tripCopy, true); return; }
    if ((el = t.closest('[data-trip-delete]'))) {
      const id = el.dataset.tripDelete, known = (list || []).find(x => x.id === id) || (current && current.id === id ? current : null);
      askDelete(id, known ? known.title : 'this plan', !!(known && known.status === 'completed')); return;
    }
    if (t.closest('[data-trip-print]')) { window.print(); return; }
    if (t.closest('[data-trips-retry]')) { loadList(); return; }
    if ((el = t.closest('[data-trip-new]'))) {      // buttons on the planner results
      const draft = el.dataset.tripNew === 'route' ? draftFromRoute() : draftFromTrip();
      if (!draft) { notifyDanger('Nothing to save', 'Plan a route or a trip first.'); return; }
      openEditor(draft); return;
    }
    if ((el = t.closest('[data-te-move]'))) {
      readInputs();
      const i = +el.dataset.teMove, j = i + +el.dataset.dir;
      if (j >= 0 && j < ed.stops.length) { [ed.stops[i], ed.stops[j]] = [ed.stops[j], ed.stops[i]]; editorStops(); }
      return;
    }
    if ((el = t.closest('[data-te-remove]'))) { readInputs(); if (ed.stops.length > 1) { ed.stops.splice(+el.dataset.teRemove, 1); editorStops(); } return; }
  });
  document.addEventListener('change', e => {
    if (!ed) return;
    if (e.target.matches && e.target.matches('[data-te-visit]')) { readInputs(); ed.stops[+e.target.dataset.teVisit].visitMin = +e.target.value; editorStops(); }
    else if (e.target.id === 'teDep' || e.target.id === 'teDate' || e.target.id === 'teLunch') { readInputs(); editorStops(); }
  });
  $('teAdd').addEventListener('click', () => {
    const id = $('teAddSel').value, p = PLACES.find(x => x.id === id);
    if (!p || ed.stops.length >= 8) return;
    readInputs(); ed.stops.push({ place: p, visitMin: defaultVisit(p) }); editorStops();
  });
  $('teSave').addEventListener('click', save);
  $('teForm').addEventListener('submit', e => { e.preventDefault(); save(); });
  $('tdConfirm').addEventListener('click', confirmDelete);

  return {
    // Sprint 3: after a plan was marked completed elsewhere (History Log), redraw whichever of the list / receipt is on screen.
    refresh() {
      list = null;
      if (!$('view-trips').classList.contains('d-none')) loadList();
      else if (!$('view-trip').classList.contains('d-none') && current) openReceipt(current.id);
    },
    // Called by showView() in dashboard.js: name = 'trips' (the list) or 'trip' (one plan, sub = its reference)
    onShow(name, sub) {
      if (name === 'trips') loadList();
      else openReceipt(sub);
    }
  };
})();

// Landed directly on #trips or #trip/<reference> (a refresh or a bookmark): dashboard.js showed the section, now fill it.
(function () { const [n, s] = location.hash.slice(1).split('/'); if (n === 'trips' || n === 'trip') Trips.onShow(n, s); })();
