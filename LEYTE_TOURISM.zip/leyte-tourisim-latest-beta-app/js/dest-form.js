/* ONE definition of the destination form, used by BOTH:
     - admin/destinations.html  (Admin > Destinations > Add / Edit destination)
     - business-request.html    (public Business Destination Request)
     - admin/requests.html      (admin review of a request, before approval)
   The fields, labels, input types, order, limits, required marks and validation messages live only here. A change here changes every form.
   The server checks the same data again with dest_clean() in includes/destinations.php (the same function for admin saves and for requests).

   mount(box, {admin})  draws the sections.  admin:true adds the three things only an administrator has (see ADMIN-ONLY below).
   renderCats / fill / collect / check / photo()  are the helpers the pages share so none of them re-implements a field. */
const DestForm = (() => {
  const esc = s => String(s ?? '').replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
  const $ = id => document.getElementById(id);

  const TIMES = { morning: 'Morning', afternoon: 'Afternoon', evening: 'Evening' };   // keys match PREF_TIMES in includes/config.php
  const MAX_PHOTO = 3 * 1024 * 1024;
  const PHOTO_TYPES = ['image/jpeg', 'image/png', 'image/webp', 'image/avif'];

  /* ADMIN-ONLY (opts.admin): (1) "New category" shortcut (only an administrator may create categories),
     (2) the live-weather preview line. Everything else (fields, labels, help texts, order, limits) is identical in both modes. */
  function html(o) {
    const a = !!(o && o.admin);
    return `
        <section class="ad-fsec" aria-labelledby="secBasic">
          <div class="ad-fsec-head"><h3 id="secBasic">Basic information</h3><p>What visitors read first.</p></div>
          <div class="row g-3">
            <div class="col-md-6"><label class="form-label req" for="fName">Destination name</label><input class="form-control" id="fName" maxlength="100" placeholder="e.g. Kalanggaman Island" required>
              <div class="form-text">Renaming a destination keeps its photo.</div><div class="invalid-feedback">Enter the destination name.</div></div>
            <div class="col-md-6"><label class="form-label req" for="fBlurb">Short description</label><input class="form-control" id="fBlurb" maxlength="200" placeholder="One sentence shown on cards" required>
              <div class="form-text">Shown on cards, up to 200 characters.</div><div class="invalid-feedback">Enter a short description.</div></div>
            <div class="col-12"><label class="form-label req" for="fAbout">Full description</label><textarea class="form-control" id="fAbout" rows="4" maxlength="2000" placeholder="Tell visitors what makes this place worth a visit" required></textarea><div class="invalid-feedback">Enter the full description.</div></div>
          </div>
        </section>

        <section class="ad-fsec" aria-labelledby="secLoc">
          <div class="ad-fsec-head"><h3 id="secLoc">Location</h3><p>Where it is and how to get there. The pinned spot is also used to fetch live weather automatically.</p></div>
          <div class="row g-3">
            <div class="col-md-6"><label class="form-label req" for="fTown">Town or city</label><input class="form-control" id="fTown" maxlength="100" placeholder="e.g. Palompon" required><div class="invalid-feedback">Enter the town or city.</div></div>
            <div class="col-md-6"><label class="form-label req" for="fArea">Setting</label>
              <select class="form-select" id="fArea" required><option value="urban">Urban (city or town center)</option><option value="rural">Rural (countryside, islands, mountains)</option></select></div>
            <div class="col-12">
              <span class="form-label req d-block" id="pinLbl">Pin location</span>
              <div class="ad-pin" id="pinBox">
                <div class="ad-pin-map" id="pinMap" role="application" aria-labelledby="pinLbl" aria-describedby="pinHelp"></div>
                <div class="ad-pin-bar"><span class="ad-pin-state" id="pinState" aria-live="polite"></span>
                  <button type="button" class="btn btn-sm btn-outline-secondary" id="pinClear"><i class="bi bi-x-circle me-1" aria-hidden="true"></i>Remove pin</button></div>
              </div>
              <input type="hidden" id="fLat"><input type="hidden" id="fLng">
              <div class="form-text" id="pinHelp">Click or tap the map to drop the pin, then drag it to the exact spot. Zoom in for accuracy.</div>
              <div class="text-danger small d-none" id="pinError" role="alert">Pin the location on the map.</div>
            </div>
            <div class="col-12"><label class="form-label" for="fGetThere">How to get there</label><textarea class="form-control" id="fGetThere" rows="3" maxlength="500" placeholder="Directions, transport options, nearest port or terminal"></textarea></div>${a ? `
            <div class="col-12">
              <div class="ad-wx" id="wxPreview" aria-live="polite"><i class="bi bi-cloud-sun" aria-hidden="true"></i><div><div class="t">Live weather</div><div class="s" id="wxText">Fetched automatically from OpenWeather for these coordinates. You never type weather in by hand.</div></div></div>
            </div>` : ''}
          </div>
        </section>

        <section class="ad-fsec" aria-labelledby="secCat">
          <div class="ad-fsec-head"><h3 id="secCat">Categories</h3><p>These decide where the place shows up in filters and recommendations.</p></div>
          <span class="form-label req d-block" id="catLbl">Categories</span><div id="fCats" class="ad-checks" role="group" aria-labelledby="catLbl"></div><div class="form-text">Choose at least one.</div>${a ? `
          <button type="button" class="btn btn-sm btn-outline-secondary mt-2" id="newCatToggle" aria-expanded="false" aria-controls="newCatBox"><i class="bi bi-plus-lg me-1" aria-hidden="true"></i>New category</button>
          <div class="ad-newcat d-none" id="newCatBox">
            <div id="newCatError" class="alert alert-danger py-2 small d-none" role="alert"></div>
            <label class="form-label" for="nLabel">Category name</label>
            <input class="form-control mb-3" id="nLabel" maxlength="40" autocomplete="off" placeholder="e.g. Food &amp; markets">
            <span class="form-label d-block">Icon</span><div class="ad-icons mb-3" id="nIcons"></div>
            <div class="form-check mb-3"><input class="form-check-input" type="checkbox" id="nOutdoor"><label class="form-check-label" for="nOutdoor">Outdoor category <span class="text-secondary small">(rain and rough-sea warnings apply)</span></label></div>
            <button type="button" class="btn btn-ad btn-sm" id="nAdd">Add category</button>
            <button type="button" class="btn btn-link btn-sm" id="nCancel">Cancel</button>
          </div>` : ''}
        </section>

        <section class="ad-fsec" aria-labelledby="secVisit">
          <div class="ad-fsec-head"><h3 id="secVisit">Visitor information</h3><p>Fees, hours and what the place offers.</p></div>
          <div class="row g-3">
            <div class="col-md-4"><label class="form-label req" for="fFeeAmt">Entrance fee (₱)</label><input class="form-control" type="number" id="fFeeAmt" min="0" max="100000" step="1" placeholder="0" required>
              <div class="form-text">Use 0 for free. Used for budget matching.</div><div class="invalid-feedback">Enter the fee, or 0 for free.</div></div>
            <div class="col-md-8"><label class="form-label" for="fFee">Fee label shown to visitors</label><input class="form-control" id="fFee" maxlength="100" placeholder="₱150 environmental fee">
              <div class="form-text">Optional. Left empty, it becomes “Free” or “₱&lt;amount&gt; entrance fee”.</div></div>
            <div class="col-md-6"><label class="form-label req" for="fHours">Opening hours</label><input class="form-control" id="fHours" maxlength="100" placeholder="6:00 AM – 5:00 PM" required><div class="invalid-feedback">Enter the opening hours.</div></div>
            <div class="col-md-6"><label class="form-label" for="fBest">Best time to visit</label><input class="form-control" id="fBest" maxlength="500" placeholder="e.g. March to May"></div>
            <div class="col-12"><label class="form-label" for="fFacilities">Facilities</label><textarea class="form-control" id="fFacilities" rows="3" placeholder="One per line: Cottages&#10;Restrooms&#10;Parking"></textarea></div>
          </div>
        </section>

        <section class="ad-fsec" aria-labelledby="secGuide">
          <div class="ad-fsec-head"><h3 id="secGuide">Visiting guidance <span class="ad-opt">Optional</span></h3>
            <p>About the place itself, not about a visitor. Used to describe the best time to go. Leave empty if it doesn't apply.</p></div>
          <div class="row g-3">
            <div class="col-md-6"><span class="form-label d-block" id="timeLbl">Suggested time of day</span><div id="fTimes" class="ad-checks" role="group" aria-labelledby="timeLbl"></div><div class="form-text">When this place is usually best to visit.</div></div>
            <div class="col-md-6"><label class="form-label" for="fView">Sunrise or sunset spot</label>
              <select class="form-select" id="fView"><option value="">None</option><option value="sunrise">Good sunrise spot</option><option value="sunset">Good sunset spot</option></select></div>
          </div>
        </section>

        <section class="ad-fsec" aria-labelledby="secHi">
          <div class="ad-fsec-head"><h3 id="secHi">Destination details and tips</h3><p>Optional details that make the profile useful.</p></div>
          <div class="row g-3">
            <div class="col-md-6"><label class="form-label" for="fHighlights">Highlights</label><textarea class="form-control" id="fHighlights" rows="4" placeholder="One per line (up to 10)"></textarea></div>
            <div class="col-md-6"><label class="form-label" for="fTip">Travel tips</label><textarea class="form-control" id="fTip" rows="4" maxlength="500" placeholder="What to bring, what to know before going"></textarea></div>
          </div>
        </section>

        <section class="ad-fsec" aria-labelledby="secPhoto">
          <div class="ad-fsec-head"><h3 id="secPhoto">Photo</h3><p>One photo per destination. Replacing it updates every place the destination appears on the website.</p></div>
          <div class="row g-3 align-items-start">
            <div class="col-md-4">
              <div class="ad-photo-state" id="photoState"><i class="bi bi-image" aria-hidden="true"></i><span>No photo yet</span></div>
              <img class="ad-photo-prev d-none" id="photoPrev" alt="Photo preview">
              <div class="ad-photo-prev ad-photo-empty" id="photoNone"><span><i class="bi bi-image" aria-hidden="true"></i>No photo</span></div>
            </div>
            <div class="col-md-8">
              <span class="form-label d-block" id="photoLabel">Upload a photo</span>
              <label class="ad-drop position-relative" id="photoDrop" for="fPhoto">
                <i class="bi bi-cloud-arrow-up" aria-hidden="true"></i>
                <div class="t"><u>Choose a file</u> or drag it here</div>
                <div class="s">JPG, PNG, WebP or AVIF, up to 3 MB and 8000 px</div>
                <input type="file" id="fPhoto" accept="image/jpeg,image/png,image/webp,image/avif" aria-describedby="photoLabel photoName">
              </label>
              <div class="ad-fname d-none" id="photoName"></div>
              <div class="form-check mt-3 d-none" id="removeWrap"><input class="form-check-input" type="checkbox" id="fRemovePhoto"><label class="form-check-label" for="fRemovePhoto">Remove the current photo</label></div>
            </div>
          </div>
        </section>`;
  }

  function mount(box, opts) { box.innerHTML = html(opts); checks('fTimes', 'time', TIMES); pin.init(); }


  /* ---------- PIN LOCATION picker (Leaflet + OpenStreetMap, vendor/leaflet) ----------
     The ONE map picker for every form that uses this file. Latitude and longitude live in two hidden inputs (#fLat, #fLng) so fill()/collect()
     and the server (dest_clean) are unchanged; they are never shown as fields. Click/tap the map to place the pin, drag the pin to adjust.
     The map is built when the form is mounted and must be told when its container becomes visible (modal shown): call DestForm.pin.refresh(). */
  const pin = (() => {
    const LEYTE = [11.0, 124.95], LEYTE_ZOOM = 9, PIN_ZOOM = 15;
    let map = null, marker = null, locked = false;
    const num = v => (v === '' || v === null || v === undefined) ? NaN : Number(v);
    const validPair = (la, ln) => Number.isFinite(la) && Number.isFinite(ln) && Math.abs(la) <= 90 && Math.abs(ln) <= 180 && !(la === 0 && ln === 0);
    const has = () => validPair(num($('fLat').value), num($('fLng').value));

    function ui() {
      const on = has();
      $('pinState').innerHTML = on ? '<i class="bi bi-geo-alt-fill" aria-hidden="true"></i>Pin placed.' + (locked ? '' : ' Drag it to adjust.') : '<i class="bi bi-geo-alt" aria-hidden="true"></i>No pin yet. Click the map to place one.';
      $('pinState').classList.toggle('on', on);
      $('pinClear').classList.toggle('d-none', !on || locked);
      if (on) { $('pinError').classList.add('d-none'); $('pinBox').classList.remove('invalid'); }
    }
    function write(ll) { $('fLat').value = ll.lat.toFixed(6); $('fLng').value = ll.lng.toFixed(6); ui(); }
    function place(ll) {
      if (!marker) {
        marker = L.marker(ll, { draggable: !locked, keyboard: true, title: 'Pin location' }).addTo(map);
        marker.on('dragend', () => write(marker.getLatLng()));
      } else marker.setLatLng(ll);
    }
    function init() {
      marker = null; map = null;
      if (typeof L === 'undefined') { $('pinMap').innerHTML = '<div class="ad-pin-fail">The map could not be loaded. Reload the page to try again.</div>'; ui(); return; }
      map = L.map('pinMap', { center: LEYTE, zoom: LEYTE_ZOOM, scrollWheelZoom: true });
      L.tileLayer('https://tile.openstreetmap.org/{z}/{x}/{y}.png', { maxZoom: 19, attribution: '&copy; <a href="https://www.openstreetmap.org/copyright" target="_blank" rel="noopener">OpenStreetMap</a> contributors' }).addTo(map);
      map.on('click', e => { if (locked) return; place(e.latlng); write(e.latlng); });
      $('pinClear').addEventListener('click', () => { if (locked) return; if (marker) { map.removeLayer(marker); marker = null; } $('fLat').value = ''; $('fLng').value = ''; ui(); });
      ui();
    }
    // Shows the saved pin (or the empty Leyte view) for the current hidden values. Call after fill() and again once the container is visible.
    function sync() {
      if (!map) { ui(); return; }
      if (has()) { const ll = L.latLng(num($('fLat').value), num($('fLng').value)); place(ll); map.setView(ll, PIN_ZOOM); }
      else { if (marker) { map.removeLayer(marker); marker = null; } map.setView(LEYTE, LEYTE_ZOOM); }
      ui();
    }
    function refresh() { if (!map) return; map.invalidateSize(); sync(); }
    // Read-only (an already decided request): the pin shows but cannot be moved or removed.
    function lock(v) {
      locked = !!v;
      if (marker) { locked ? marker.dragging.disable() : marker.dragging.enable(); }
      $('pinBox').classList.toggle('locked', locked); ui();
    }
    function invalid() { $('pinError').classList.remove('d-none'); $('pinBox').classList.add('invalid'); }
    return { init, sync, refresh, lock, has, invalid };
  })();

  /* ---------- checkbox groups ---------- */
  function checks(box, name, map) {
    $(box).innerHTML = Object.entries(map).map(([k, label]) =>
      `<div class="form-check form-check-inline"><input class="form-check-input" type="checkbox" name="${name}" id="${name}-${k}" value="${esc(k)}"><label class="form-check-label" for="${name}-${k}">${esc(label)}</label></div>`).join('');
  }
  const renderCats = cats => checks('fCats', 'cats', cats);   // cats = { key: label } from the server (data/categories.json)
  const picked = (form, name) => [...form.querySelectorAll(`input[name="${name}"]:checked`)].map(i => i.value);
  const setPicked = (form, name, vals) => form.querySelectorAll(`input[name="${name}"]`).forEach(i => { i.checked = (vals || []).includes(i.value); });
  const lines = id => $(id).value.split('\n').map(s => s.trim()).filter(Boolean);

  /* ---------- values <-> form ---------- */
  // Puts a destination record (same shape the admin API returns) into the form. d = null clears it to the defaults.
  function fill(form, d) {
    const set = (id, v) => { $(id).value = v ?? ''; };
    set('fName', d && d.name); set('fTown', d && d.town); set('fArea', (d && d.area) || 'urban'); set('fView', d && d.view);
    set('fHours', d && d.hours); set('fFeeAmt', d ? d.feeAmt : ''); set('fFee', d && d.fee);
    set('fFacilities', d ? (d.facilities || []).join('\n') : ''); set('fBlurb', d && d.blurb); set('fAbout', d && d.about);
    set('fHighlights', d ? (d.highlights || []).join('\n') : ''); set('fBest', d && d.best); set('fGetThere', d && d.getThere); set('fTip', d && d.tip);
    set('fLat', d && d.lat); set('fLng', d && d.lng); pin.sync();
    setPicked(form, 'cats', d && d.cats); setPicked(form, 'time', d && d.time);
  }

  // The request body for the server: the same keys the admin save endpoint has always received.
  function collect(form) {
    const v = id => $(id).value;
    return {
      name: v('fName'), town: v('fTown'), area: v('fArea'), view: v('fView'), hours: v('fHours'),
      cats: picked(form, 'cats'), time: picked(form, 'time'),
      feeAmt: v('fFeeAmt'), fee: v('fFee'), facilities: lines('fFacilities'),
      blurb: v('fBlurb'), about: v('fAbout'), highlights: lines('fHighlights'),
      best: v('fBest'), getThere: v('fGetThere'), tip: v('fTip'),
      lat: v('fLat'), lng: v('fLng'),
    };   // no weather: it is fetched automatically from OpenWeather for the coordinates
  }

  // Browser-side check (the server checks again). Returns '' when fine, otherwise the message to show. Same messages as the admin form always had.
  function check(form) {
    if (!form.checkValidity()) { form.classList.add('was-validated'); form.querySelector(':invalid')?.focus(); return 'Fill in the required fields marked with *.'; }
    if (!pin.has()) { pin.invalid(); $('pinBox').scrollIntoView({ block: 'center', behavior: 'smooth' }); return 'Pin the location on the map before sending.'; }
    if (!picked(form, 'cats').length) return 'Choose at least one category.';
    return '';
  }

  /* ---------- photo: pick, check, preview, drag and drop ----------
     getSaved() -> URL of the photo already stored (or null). onError(msg) shows a message. Returns { set(url, state) }.
     state: 'none' | 'saved' (the photo stored with the destination/request) | 'new' (picked, not saved yet) */
  function photo(getSaved, onError) {
    function set(url, state) {
      state = url ? (state || 'saved') : 'none';
      $('photoPrev').classList.toggle('d-none', !url);
      $('photoNone').classList.toggle('d-none', !!url);
      if (url) $('photoPrev').src = url;
      const st = $('photoState');
      st.classList.toggle('new', state === 'new');
      st.innerHTML = state === 'new' ? '<i class="bi bi-eye" aria-hidden="true"></i><span>New photo, not saved yet</span>'
        : state === 'saved' ? '<i class="bi bi-check-circle" aria-hidden="true"></i><span>Current saved photo</span>'
        : '<i class="bi bi-image" aria-hidden="true"></i><span>No photo yet</span>';
      const nm = $('photoName'), f = $('fPhoto').files[0];
      nm.textContent = f && state === 'new' ? f.name : ''; nm.classList.toggle('d-none', !(f && state === 'new'));
    }
    // Photo picked: check it here for a quick message (the server checks again), then preview it.
    $('fPhoto').addEventListener('change', () => {
      const f = $('fPhoto').files[0];
      onError('');
      if (!f) { set(getSaved(), 'saved'); return; }
      if (!PHOTO_TYPES.includes(f.type)) { $('fPhoto').value = ''; set(getSaved(), 'saved'); onError('Only JPG, PNG, WebP or AVIF photos are allowed.'); return; }
      if (f.size > MAX_PHOTO) { $('fPhoto').value = ''; set(getSaved(), 'saved'); onError('That photo is larger than 3 MB. Choose a smaller one.'); return; }
      $('fRemovePhoto').checked = false;
      set(URL.createObjectURL(f), 'new');
    });
    // Drag a photo onto the drop zone: same checks as the file picker (it just fills the same input).
    const drop = $('photoDrop');
    ['dragenter', 'dragover'].forEach(ev => drop.addEventListener(ev, e => { e.preventDefault(); drop.classList.add('drag'); }));
    ['dragleave', 'drop'].forEach(ev => drop.addEventListener(ev, e => { e.preventDefault(); drop.classList.remove('drag'); }));
    drop.addEventListener('drop', e => {
      const f = e.dataTransfer && e.dataTransfer.files[0];
      if (!f) return;
      try { const dt = new DataTransfer(); dt.items.add(f); $('fPhoto').files = dt.files; } catch (err) { return; }
      $('fPhoto').dispatchEvent(new Event('change'));
    });
    return { set };
  }

  const toDataUrl = file => new Promise((ok, no) => { const r = new FileReader(); r.onload = () => ok(r.result); r.onerror = () => no(r.error); r.readAsDataURL(file); });
  // { photo: dataURL } when a file was picked, { remove_photo: true } when "remove" is ticked, otherwise {}. Throws if the file can't be read.
  async function photoPayload() {
    const file = $('fPhoto').files[0];
    if (file) return { photo: await toDataUrl(file) };
    if ($('fRemovePhoto').checked) return { remove_photo: true };
    return {};
  }

  /* ---------- ADMIN-ONLY: "+ New category" (admin pages only; needs the Admin helper from admin/js/admin.js) ----------
     Creates a category through the normal category endpoint, reloads the shared list, keeps what was ticked and ticks the new one.
     Returns closeNewCat(). onAdded() runs after the list was reloaded (e.g. to refresh a filter dropdown). */
  function bindNewCategory(form, Admin, onAdded) {
    const newBox = $('newCatBox'), newErr = $('newCatError');
    function closeNewCat() { newBox.classList.add('d-none'); newErr.classList.add('d-none'); $('nLabel').value = ''; $('nOutdoor').checked = false; $('newCatToggle').setAttribute('aria-expanded', 'false'); }
    $('newCatToggle').addEventListener('click', () => {
      const open = newBox.classList.contains('d-none');
      if (!open) { closeNewCat(); return; }
      Admin.iconGrid($('nIcons'), 'nIcon', null);
      newBox.classList.remove('d-none'); $('newCatToggle').setAttribute('aria-expanded', 'true'); $('nLabel').focus();
    });
    $('nCancel').addEventListener('click', closeNewCat);
    $('nLabel').addEventListener('keydown', e => { if (e.key === 'Enter') { e.preventDefault(); $('nAdd').click(); } });   // Enter must not submit the destination form
    $('nAdd').addEventListener('click', async function () {
      newErr.classList.add('d-none');
      const label = $('nLabel').value.trim();
      if (label.length < 2) { newErr.textContent = 'Enter a category name (at least two characters).'; newErr.classList.remove('d-none'); return; }
      Admin.loading(this, true, 'Adding…');
      const res = await Admin.api('category-save.php', { label, icon: (document.querySelector('input[name="nIcon"]:checked') || {}).value, outdoor: $('nOutdoor').checked });
      Admin.loading(this, false);
      if (!res.ok) { newErr.textContent = res.message || 'Could not add the category.'; newErr.classList.remove('d-none'); return; }
      const keep = picked(form, 'cats');                       // what the admin already ticked stays ticked
      await Admin.loadCats();
      renderCats(ADMIN_CATS);
      if (onAdded) onAdded();
      setPicked(form, 'cats', [...keep, res.category.key]);    // the new category is immediately available and selected
      closeNewCat();
      Admin.toast('success', res.message);
    });
    return closeNewCat;
  }

  return { bindNewCategory, pin, TIMES, MAX_PHOTO, PHOTO_TYPES, html, mount, renderCats, checks, picked, setPicked, fill, collect, check, photo, photoPayload, esc };
})();
