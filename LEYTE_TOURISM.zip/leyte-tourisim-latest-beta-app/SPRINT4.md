# Sprint 4: User Engagement (SCRUM-20, 21, 22) + My Trip Plans

Stack unchanged: PHP + JSON/text files, Bootstrap 5, PHP sessions, `api/` endpoints that take POST + JSON. No framework, no new dependency, no API key.

## What I could and could not confirm about the backlog
I had **only the Jira screenshot** (issue titles and the sprint description "favorites, ratings, history logs, and the admin tourism management panel"). There is no Jira export, no acceptance criteria, and no Sprint 4 text in the repository. So the acceptance criteria below are **my reading of the titles, not Jira's**. Please compare them with the real ones.

| Issue | Status |
|---|---|
| SCRUM-20 Submit Destination Ratings and Reviews | Built in Sprint 3 (see SPRINT3.md). Unchanged, except it now also writes an activity event. |
| SCRUM-21 Save Preferred Tourist Destinations to Favourites | **Built.** |
| SCRUM-22 Track User Activity and Destination History | **Built** (my interpretation, below). |
| *(new)* My Trip Plans / saved itinerary receipt | **Built.** Not in the backlog: it needs a Jira issue. A suggested one is at the end. |

## SCRUM-21 Favourites
- Heart button on every destination card, in the destination popup, and in the existing **"Your favorites"** column of the History Log page (which was already on the page, empty, waiting for this).
- Saved on the account (`favourites` list in `users.txt`), so it follows the visitor to any device. `api/favourites.php` takes an explicit `on: true|false` (not a toggle), so a retry or double tap can never flip it the wrong way. The browser updates at once and rolls back with an error message if the server refuses. Limit 100.
- A heart inside a card does not open the card (mouse or keyboard). A destination the admin later deletes is silently skipped in the list.

## SCRUM-22 Activity and destination history (my interpretation)
- User side: the History Log ("recently viewed") already existed and is unchanged.
- New: a short **activity log** (`data/activity.json`, newest 2000 events: account, action, destination, time) fed by opening a destination, adding/removing a favourite, posting a review and saving a trip plan. It holds no emails, review text or trip details. Logging can never break the app (errors go to the PHP log).
- New admin page **Admin > Activity** (`admin/activity.html`, `api/admin/activity.php`): per destination, opens / favourites / reviews / average rating / trip plans that include it, plus the newest 60 events with the visitor's name.
- The **privacy notice was updated** to say this honestly (administrators can see name + action). Deleting an account removes its activity.
- If your Jira criteria mean something different (e.g. an exportable log, filtering, or per-user histories for admins), tell me and I will adjust.

## My Trip Plans
**One shared store for both planners.** The route planner and the automatic one-day trip both end in the same editor and the same `trip-save` call.

Workflow: plan a route or generate a day -> **Save as trip plan / Review and save** -> the **editor** (title, date, departure, reorder, remove, add a stop, change visit length, lunch on/off, notes) recalculates the timeline live -> **Save** -> the receipt opens at `#trip/TP-YYYYMMDD-XXXXXX`. **Trip Plans** in the menu lists your plans (title, date, departure, start, number of destinations, estimated duration, status; loading, empty and error states) with View / Edit / Delete (with confirmation) and **Use as a new plan** on the receipt.

**The receipt** shows the app name, plan reference, title, status, *plan created* and *last updated* separately from the *planned travel date*, departure, start, ordered stops with arrive / visit / depart times, lunch, legs, totals, route sketch map, weather snapshot, notes, and prints cleanly (print CSS: only the receipt, black on white even in dark theme, one page for a short plan; "Print / save as PDF" uses the browser). It says plainly that it is a record of a plan, **not a booking, and not proof the trip happened**. Status (planned / completed / cancelled) is set by the visitor.

Data (`data/trips.json`, file-based like everything else): a parent record per plan with its ordered `stops`, owner `uid`, a snapshot of each destination (name, town, coordinates, fee, hours) copied at save time, route estimates, weather snapshot, notes, status, created/updated.

Server-enforced rules (`includes/trips.php`), not just hidden buttons:
- Every plan belongs to the signed-in account. Reading, editing or deleting someone else's plan, or a plan that does not exist, returns the **same 404**, so ids cannot be probed. The owner id and save token never leave the server.
- All input validated: title, date, times, 1-8 stops, no duplicate stop, status, mode, `<` `>` and control characters, lengths. 50 plans per account.
- **No invented numbers:** the server re-computes every leg from the stop coordinates and rejects a distance or time that does not match the estimate formula, a clock that cannot work (arriving before the drive could end), visits that do not add up, and plans past midnight.
- **No duplicates:** the browser makes one token per save attempt; a repeated submit returns the first plan. The Save button is also disabled while saving.
- A saved plan keeps its stops if the admin later edits or deletes the destination (snapshot). Account deletion removes its plans.

## Honest limits (read these)
1. **There is no routing service.** Your brief says to show only estimates "calculated by the routing service". The project has none and needs a paid or keyed service (Google Directions, Mapbox, a hosted OSRM) to have one. Distances and times are a **straight-line x 1.4 at 40 km/h estimate** (+1 h per boat crossing), labelled "estimate" everywhere, and the server verifies they follow that formula. "Open in Google Maps" gives real directions. Adding a routing service is a separate task (needs a key, kept server-side).
2. **Weather is a snapshot of current conditions, never a forecast.** The app only reads current conditions. For a future travel date the receipt says it is *not* a forecast for that date. I did not add a forecast: I could not verify what your OpenWeather plan allows and could not call it from here. If your key supports the 5-day forecast endpoint, that is a good next step.
3. **Supabase is NOT integrated** and I did not pretend otherwise. See `SUPABASE-MIGRATION.md` for what a migration needs and a draft schema. The saved plans already work across devices because they are stored on the server under the account, as long as the site runs on one server with a persistent writable `data/` folder.
4. The route "map" is a sketch for orientation (no map tiles); it is labelled as such.
5. Arrival times are calculated from departure, order and visit lengths. They cannot be typed in by hand.
6. Last save wins if the same plan is edited in two tabs at once.
7. History Log (recently viewed) and the new activity log are separate; the user-side History Log was not changed.

## Files
**New:** `includes/trips.php`, `includes/activity.php`, `api/favourites.php`, `api/trips.php`, `api/trip.php`, `api/trip-save.php`, `api/trip-delete.php`, `api/admin/activity.php`, `admin/activity.html`, `admin/js/activity.js`, `js/favourites.js`, `js/trips.js`, `SPRINT4.md`, `SUPABASE-MIGRATION.md`.
**Changed:** `includes/config.php` (constants), `includes/db.php` (`db_modify`, an atomic per-account update), `includes/auth.php` (favourites in the account payload), `includes/bootstrap.php`, `api/recent.php`, `api/review-save.php`, `api/delete.php` (hooks), `dashboard.html`, `js/dashboard.js`, `js/planner.js` (`buildItinerary`), `js/planner-ui.js`, `js/weather.js`, `css/dashboard.css`, `admin/js/admin.js` (nav), `privacy.html`, `tools/selftest.php`, `tools/planner-selftest.js`, `README.txt`, `.gitignore`.
**New data files (created on first use):** `data/trips.json`, `data/activity.json`.

## Tests: what was and was NOT run
**Run, all passing:**
- `node tools/planner-selftest.js`: 66 checks. New: rebuilt itineraries reproduce the generated plan exactly; every rebuilt plan passes a re-statement of the server's rules; reordering; midnight; closed days; boat; and the rule-checker is shown to catch a made-up distance.
- 81 browser checks (headless Chromium) for Sprint 4 and the 73 from Sprint 3 still pass: favourites (save, persist, keyboard, rollback on failure), save from a route and from a generated day, editor (reorder/remove/add/duration/validation/midnight), receipt content and labels, weather snapshot cases (clear/storm/none/future date), triple-click double submit makes one plan, a second browser profile sees the plan, another account gets 404 on read/edit/delete, edit, copy, delete with confirmation, bad references, empty/error/retry states, print emulation + a real PDF (text checked, one page), light/dark, 375 px phone, admin Activity page.
- A bracket-balance / duplicate-function check over every PHP file.

**NOT run: any PHP.** PHP is not installed where I worked. The browser tests ran against a Node stand-in for the API in which I re-implemented the server rules, so they test the browser code and my understanding of the rules, **not the PHP**. Before using this:
1. `php -l` on every new/changed PHP file.
2. `php tools/selftest.php` (now ~45 more checks: favourites, trip ownership 404s, validation refusals including tampered distances/times, duplicate token, snapshot kept after the destination is deleted, admin activity, no emails in activity).
3. Log in as two accounts and try to open one's `#trip/...` link from the other.
4. Open a receipt and use Print > Save as PDF in your own browser.

## Suggested Jira issue
**Title:** Save, view and print trip plans (My Trip Plans).
**Acceptance criteria:** (1) A signed-in user can save a planned route or a generated one-day itinerary as a trip plan. (2) Saved plans are listed in My Trip Plans with title, date, start, number of destinations, departure, estimated duration and status. (3) A plan opens as an itinerary receipt showing its reference, created and travel dates, ordered stops and times, estimates, weather snapshot and notes, and prints cleanly. (4) The user can edit, copy and delete their own plans. (5) Users cannot see or change other users' plans (enforced on the server). (6) Saved itineraries do not change when destination records change. (7) Estimates and weather snapshots are labelled; a saved plan is never presented as a booking or as proof of travel.
